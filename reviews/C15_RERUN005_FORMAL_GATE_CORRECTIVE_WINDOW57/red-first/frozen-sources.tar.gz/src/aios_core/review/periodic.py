"""Periodic evidence-grounded review for AIOS v3.0.

The scheduler is deterministic: it decides only *when* a review is due and which
recent world anchors are mechanically eligible for inspection. The resident model
decides what those anchors mean and may use the existing cognition capabilities to
revise/retract claims or write new calibration/strategy/self cognition.

No benchmark answer, user-growth label, or strategy conclusion is computed here.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Mapping, Sequence

from pydantic import BaseModel, ConfigDict, Field, FiniteFloat, model_validator

from aios_core.contracts.enums import (
    ErrorCode,
    MaintenanceClass,
    ObjectType,
    SourceClass,
    WakeSource,
    WakeState,
)
from aios_core.contracts.models import Dependency, OperationExperience, Wake
from aios_core.contracts.operations import OperationRequest
from aios_core.contracts.refs import ObjectRef, SourceRef
from aios_core.contracts.time import TemporalExtent, as_utc
from aios_core.policy.service import evaluation_due_at
from aios_core.query.search import WorldSearchIndex
from aios_core.storage.idempotency import canonical_json_dumps
from aios_core.storage.sqlite_store import SQLiteWorldStore, StoreError


REVIEW_KIND = "periodic_ai_growth_review"

_REAL_OPERATION_CASE_TYPES: frozenset[ObjectType] = frozenset({
    ObjectType.OBSERVATION,
    ObjectType.OUTCOME,
    ObjectType.COMMUNICATION_EXPERIENCE,
})

_REVIEWABLE_TYPES: tuple[ObjectType, ...] = (
    ObjectType.OBSERVATION,
    ObjectType.SUMMARY,
    ObjectType.CLAIM,
    ObjectType.GOAL,
    ObjectType.TASK,
    ObjectType.ACTION,
    ObjectType.OUTCOME,
    ObjectType.OPERATION_EXPERIENCE,
    ObjectType.COMMUNICATION_EXPERIENCE,
    ObjectType.PREDICTION,
)


def _stable_id(prefix: str, *parts: object) -> str:
    raw = canonical_json_dumps(list(parts))
    return f"{prefix}_{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:24]}"


def _parse_time(value: Any, field_name: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} is missing")
    return as_utc(datetime.fromisoformat(value.replace("Z", "+00:00")), field_name)


def _excerpt(payload: Mapping[str, Any]) -> str:
    object_type = str(payload.get("object_type") or "")
    if object_type == ObjectType.OBSERVATION.value:
        value = payload.get("value")
        return str(value)[:600]
    if object_type == ObjectType.SUMMARY.value:
        return str(payload.get("content") or "")[:600]
    if object_type == ObjectType.CLAIM.value:
        return str(payload.get("content") or "")[:600]
    if object_type == ObjectType.GOAL.value:
        return (
            f"{payload.get('goal_status')}: {payload.get('title')} | "
            f"{payload.get('description')}"
        )[:600]
    if object_type == ObjectType.TASK.value:
        return (
            f"{payload.get('task_state')}: {payload.get('title')} | "
            f"next={payload.get('next_step')}"
        )[:600]
    if object_type == ObjectType.ACTION.value:
        return (
            f"{payload.get('action_status')}: {payload.get('action_type')} | "
            f"expected={payload.get('expected_outcome')}"
        )[:600]
    if object_type == ObjectType.OUTCOME.value:
        return (
            f"{payload.get('outcome_state')} | {payload.get('payload')}"
        )[:600]
    if object_type == ObjectType.OPERATION_EXPERIENCE.value:
        return (
            f"{payload.get('problem_type')} | {payload.get('result_summary')} | "
            f"misses={payload.get('misses')}"
        )[:600]
    if object_type == ObjectType.COMMUNICATION_EXPERIENCE.value:
        return (
            f"{payload.get('scenario')} | style={payload.get('style')} | "
            f"reaction={payload.get('user_reaction')}"
        )[:600]
    if object_type == ObjectType.PREDICTION.value:
        return (
            f"{payload.get('verification_state')}: "
            f"{payload.get('expected_change')}"
        )[:600]
    if object_type == ObjectType.COGNITIVE_POLICY.value:
        return (
            f"{payload.get('policy_id')}={payload.get('current_value')} | "
            f"scope={payload.get('scope')} | evaluate={payload.get('evaluation_window')}"
        )[:600]
    return str(payload)[:600]


class ReviewSchedulePolicy(BaseModel):
    """Engineering scheduling parameters, not cognitive truth."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    interval_hours: FiniteFloat = Field(default=24.0, gt=0.0)
    lookback_hours: FiniteFloat = Field(default=72.0, gt=0.0)
    max_candidates: int = Field(default=80, ge=1, le=500)
    max_per_object_type: int = Field(default=20, ge=1, le=100)


class ReviewAnchor(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    object_ref: ObjectRef
    object_type: str
    recorded_at: datetime
    excerpt: str

    @model_validator(mode="after")
    def validate_anchor(self) -> "ReviewAnchor":
        if self.object_ref.revision is None:
            raise ValueError("review anchor must pin exact revision")
        as_utc(self.recorded_at, "recorded_at")
        return self


class PeriodicReviewRequest(BaseModel):
    """Compact, evidence-grounded input shown to the same resident model runtime."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    review_id: str = Field(min_length=1)
    subject_id: str = Field(min_length=1)
    wake_ref: ObjectRef
    window_start: datetime
    window_end: datetime
    anchors: tuple[ReviewAnchor, ...] = Field(min_length=1)
    instruction: str = (
        "Review the supplied world anchors and decide whether any previous AI "
        "understanding, strategy, calibration, self-understanding, goal handling, "
        "operation method, or due CognitivePolicy should be revised, confirmed, or "
        "rolled back. Use existing search/inspect tools "
        "when needed. Do not invent user growth, causal meaning, success, failure, "
        "or policy changes that are not supported by world evidence. Mechanical "
        "Wake outcomes may be used to review Resident-authored attention watches, "
        "but model silence or suppressed delivery is not itself evidence of user "
        "preference or real-world success."
    )

    @model_validator(mode="after")
    def validate_request(self) -> "PeriodicReviewRequest":
        if self.wake_ref.revision is None:
            raise ValueError("wake_ref must pin exact revision")
        start = as_utc(self.window_start, "window_start")
        end = as_utc(self.window_end, "window_end")
        if end < start:
            raise ValueError("window_end must not be before window_start")
        return self


class OperationExperienceRequest(BaseModel):
    """Model-authored experience grounded in real case refs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    problem_type: str = Field(min_length=1)
    method_path: tuple[str, ...] = Field(min_length=1)
    result_summary: str = Field(min_length=1)
    positive_case_refs: tuple[ObjectRef, ...] = ()
    negative_case_refs: tuple[ObjectRef, ...] = ()
    applicability: dict[str, Any] = Field(default_factory=dict)
    cost: dict[str, FiniteFloat] = Field(default_factory=dict)
    misses: tuple[str, ...] = ()
    experience_state: str = Field(default="candidate", min_length=1)

    @model_validator(mode="after")
    def validate_request(self) -> "OperationExperienceRequest":
        if not self.problem_type.strip() or not self.result_summary.strip():
            raise ValueError("problem_type/result_summary must not be blank")
        if any(not item.strip() for item in self.method_path):
            raise ValueError("method_path must not contain blank steps")
        if any(not item.strip() for item in self.misses):
            raise ValueError("misses must not contain blank values")
        refs = (*self.positive_case_refs, *self.negative_case_refs)
        if not refs:
            raise ValueError("operation experience requires at least one real case ref")
        if any(ref.revision is None for ref in refs):
            raise ValueError("operation experience case refs must pin exact revisions")
        positive_keys = {
            (ref.object_id, ref.revision) for ref in self.positive_case_refs
        }
        negative_keys = {
            (ref.object_id, ref.revision) for ref in self.negative_case_refs
        }
        if positive_keys.intersection(negative_keys):
            raise ValueError(
                "the same case ref cannot be both positive and negative"
            )
        return self


@dataclass(frozen=True, slots=True)
class ReviewWakeReceipt:
    wake_id: str
    revision: int
    state: str
    world_revision: int


@dataclass(frozen=True, slots=True)
class OperationExperienceReceipt:
    experience_id: str
    revision: int
    world_revision: int


class PeriodicReviewService:
    """Deterministic review scheduling + world-backed experience writeback."""

    def __init__(
        self,
        *,
        store: SQLiteWorldStore,
        index: WorldSearchIndex | None = None,
        subject_id: str = "user_1",
    ) -> None:
        if not isinstance(subject_id, str) or not subject_id.strip():
            raise ValueError("subject_id must not be blank")
        self.store = store
        self.index = index
        self.subject_id = subject_id.strip()

    def _catch_up(self) -> None:
        if self.index is not None:
            self.index.catch_up()

    def _review_wakes(self) -> tuple[Wake, ...]:
        wakes: list[Wake] = []
        for payload in self.store.list_payloads(
            object_type=ObjectType.WAKE,
            subject_id=self.subject_id,
        ):
            metadata = payload.get("metadata")
            if not isinstance(metadata, Mapping):
                continue
            if metadata.get("review_kind") != REVIEW_KIND:
                continue
            wakes.append(Wake.model_validate(payload))
        wakes.sort(
            key=lambda item: (
                as_utc(item.last_hit_at, "last_hit_at"),
                item.object_id,
                item.revision,
            )
        )
        return tuple(wakes)

    def _latest_marker(self) -> Wake | None:
        wakes = self._review_wakes()
        return wakes[-1] if wakes else None

    def _reviewed_refs_for_window(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> set[tuple[str, int]]:
        start = as_utc(window_start, "window_start").isoformat()
        end = as_utc(window_end, "window_end").isoformat()
        reviewed: set[tuple[str, int]] = set()
        for wake in self._review_wakes():
            if wake.wake_state is not WakeState.COMPLETED:
                continue
            metadata = wake.metadata
            if (
                metadata.get("window_start") != start
                or metadata.get("window_end") != end
            ):
                continue
            reviewed.update(
                (ref.object_id, int(ref.revision or 0))
                for ref in wake.evidence_refs
            )
        return reviewed

    def _attention_outcome_anchors(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
        limit: int,
    ) -> tuple[tuple[ReviewAnchor, ...], bool]:
        """Expose mechanical Wake outcomes so the Resident can learn attention policy."""

        if limit < 1:
            raise ValueError("attention outcome limit must be >= 1")
        start = as_utc(window_start, "window_start")
        end = as_utc(window_end, "window_end")

        anchors: list[ReviewAnchor] = []
        for payload in self.store.list_payloads(
            object_type=ObjectType.WAKE,
            subject_id=self.subject_id,
        ):
            wake = Wake.model_validate(payload)
            if wake.wake_state not in {
                WakeState.COMPLETED,
                WakeState.SUPPRESSED,
                WakeState.CANCELLED,
            }:
                continue
            metadata = wake.metadata
            attention_class = str(metadata.get("attention_class") or "")
            if attention_class not in {
                "interrupt",
                "background",
                "review_queue",
            }:
                continue
            if metadata.get("review_kind") == REVIEW_KIND:
                continue
            recorded = _parse_time(payload.get("recorded_at"), "recorded_at")
            if recorded <= start or recorded > end:
                continue

            excerpt = (
                f"attention={attention_class} | source={wake.wake_source.value} | "
                f"state={wake.wake_state.value} | priority={wake.priority} | "
                f"hits={wake.hit_count} | "
                f"termination={metadata.get('termination_reason')} | "
                f"rounds={metadata.get('model_rounds')} | "
                f"delivery={metadata.get('delivery_allowed')} | "
                f"step0={metadata.get('step0_state')} | "
                f"capabilities={metadata.get('capability_names')}"
            )[:600]
            anchors.append(
                ReviewAnchor(
                    object_ref=ObjectRef(
                        object_id=wake.object_id,
                        revision=wake.revision,
                    ),
                    object_type=ObjectType.WAKE.value,
                    recorded_at=recorded,
                    excerpt=excerpt,
                )
            )

        anchors.sort(
            key=lambda item: (
                item.recorded_at,
                item.object_ref.object_id,
                int(item.object_ref.revision or 0),
            )
        )
        selected = tuple(anchors[-limit:])
        return selected, len(selected) < len(anchors)

    def _attention_review_queue_anchors(
        self,
        *,
        limit: int,
    ) -> tuple[tuple[ReviewAnchor, ...], bool]:
        """Resolve durable REVIEW_QUEUE Wake evidence without invoking cognition."""

        if limit < 1:
            raise ValueError("attention review queue limit must be >= 1")

        anchors: list[ReviewAnchor] = []
        seen: set[tuple[str, int]] = set()
        total = 0
        for payload in self.store.list_payloads(
            object_type=ObjectType.WAKE,
            subject_id=self.subject_id,
        ):
            wake = Wake.model_validate(payload)
            if wake.wake_state not in {WakeState.NEW, WakeState.QUEUED}:
                continue
            metadata = wake.metadata
            if str(metadata.get("attention_class") or "") != "review_queue":
                continue
            for ref in wake.evidence_refs:
                key = (ref.object_id, int(ref.revision or 0))
                if key in seen:
                    continue
                evidence = self.store.get_payload(
                    ref.object_id,
                    revision=ref.revision,
                )
                if str(evidence.get("subject_id") or "") != self.subject_id:
                    raise ValueError("review-queue evidence belongs to another subject")
                seen.add(key)
                total += 1
                anchors.append(
                    ReviewAnchor(
                        object_ref=ref,
                        object_type=str(evidence["object_type"]),
                        recorded_at=_parse_time(
                            evidence.get("recorded_at"),
                            "recorded_at",
                        ),
                        excerpt=_excerpt(evidence),
                    )
                )

        anchors.sort(
            key=lambda item: (
                item.recorded_at,
                item.object_type,
                item.object_ref.object_id,
                int(item.object_ref.revision or 0),
            )
        )
        selected = tuple(anchors[-limit:])
        return selected, len(selected) < total

    def _collect_candidates(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
        policy: ReviewSchedulePolicy,
        excluded_refs: set[tuple[str, int]] | None = None,
    ) -> tuple[tuple[ReviewAnchor, ...], bool]:
        start = as_utc(window_start, "window_start")
        end = as_utc(window_end, "window_end")
        excluded = excluded_refs or set()
        per_type: dict[str, list[ReviewAnchor]] = {}

        for object_type in _REVIEWABLE_TYPES:
            for payload in self.store.list_payloads(
                object_type=object_type,
                subject_id=self.subject_id,
            ):
                try:
                    recorded = _parse_time(payload.get("recorded_at"), "recorded_at")
                except ValueError:
                    continue
                # Start is exclusive. Review-produced cognition is written before
                # the review Wake is completed at the same timestamp; excluding the
                # boundary prevents a completed review from mechanically scheduling
                # another review of itself on the next interval.
                if recorded <= start or recorded > end:
                    continue

                ref_key = (
                    str(payload["object_id"]),
                    int(payload["revision"]),
                )
                if ref_key in excluded:
                    continue

                # Review summaries may be useful as compressed evidence, but the
                # scheduler itself never treats their text as a semantic verdict.
                anchor = ReviewAnchor(
                    object_ref=ObjectRef(
                        object_id=ref_key[0],
                        revision=ref_key[1],
                    ),
                    object_type=str(payload["object_type"]),
                    recorded_at=recorded,
                    excerpt=_excerpt(payload),
                )
                bucket = per_type.setdefault(anchor.object_type, [])
                bucket.append(anchor)

        # R6 policies are reviewed when their own evaluation window becomes due,
        # not merely because the policy object happened to be written in this review
        # window. A policy that remains unevaluated may reappear in a later review;
        # keeping/revising/rolling it forward creates a new revision and a new due time.
        for payload in self.store.list_payloads(
            object_type=ObjectType.COGNITIVE_POLICY,
            subject_id=self.subject_id,
        ):
            ref_key = (
                str(payload["object_id"]),
                int(payload["revision"]),
            )
            if ref_key in excluded:
                continue
            metadata = payload.get("metadata")
            if not isinstance(metadata, Mapping):
                metadata = {}
            raw_due = metadata.get("next_evaluation_at")
            try:
                due_at = (
                    _parse_time(raw_due, "next_evaluation_at")
                    if raw_due is not None
                    else evaluation_due_at(
                        _parse_time(payload.get("changed_at"), "changed_at"),
                        str(payload.get("evaluation_window") or ""),
                    )
                )
            except ValueError:
                # Invalid policy schedule is a durable contract error, not a reason
                # to silently invent a review time.
                raise
            if due_at > end:
                continue
            anchor = ReviewAnchor(
                object_ref=ObjectRef(
                    object_id=ref_key[0],
                    revision=ref_key[1],
                ),
                object_type=ObjectType.COGNITIVE_POLICY.value,
                recorded_at=due_at,
                excerpt=_excerpt(payload),
            )
            per_type.setdefault(anchor.object_type, []).append(anchor)

        eligible_count = sum(len(bucket) for bucket in per_type.values())
        selected: list[ReviewAnchor] = []
        for object_type in sorted(per_type):
            bucket = per_type[object_type]
            bucket.sort(
                key=lambda item: (
                    item.recorded_at,
                    item.object_ref.object_id,
                    int(item.object_ref.revision or 0),
                )
            )
            selected.extend(bucket[-policy.max_per_object_type :])

        selected.sort(
            key=lambda item: (
                item.recorded_at,
                item.object_type,
                item.object_ref.object_id,
                int(item.object_ref.revision or 0),
            )
        )
        page = tuple(selected[-policy.max_candidates :])
        return page, len(page) < eligible_count

    def _create_wake(
        self,
        *,
        now: datetime,
        window_start: datetime,
        window_end: datetime,
        anchors: Sequence[ReviewAnchor],
        state: WakeState,
        reason: str,
        truncated: bool = False,
    ) -> ReviewWakeReceipt:
        moment = as_utc(now, "now")
        start = as_utc(window_start, "window_start")
        end = as_utc(window_end, "window_end")
        refs = [anchor.object_ref for anchor in anchors]
        wake_id = _stable_id(
            "wake_review",
            self.subject_id,
            start.isoformat(),
            end.isoformat(),
            moment.isoformat(),
            [(ref.object_id, ref.revision) for ref in refs],
            state.value,
            bool(truncated),
        )
        wake = Wake(
            object_id=wake_id,
            subject_id=self.subject_id,
            occurred=TemporalExtent.point(moment),
            learned_at=moment,
            recorded_at=moment,
            source_refs=[
                SourceRef(object_id=ref.object_id, revision=ref.revision)
                for ref in refs
            ],
            created_by="periodic_review:scheduler",
            wake_source=WakeSource.PERIODIC_REVIEW,
            wake_state=state,
            rule_id="periodic_review.interval",
            first_hit_at=moment,
            last_hit_at=moment,
            evidence_refs=list(refs),
            priority=10,
            dedupe_key=f"periodic-review:{self.subject_id}:{moment.isoformat()}",
            status=state.value,
            metadata={
                "review_kind": REVIEW_KIND,
                "window_start": start.isoformat(),
                "window_end": end.isoformat(),
                "reason": reason,
                "candidate_count": len(refs),
                "truncated": bool(truncated),
            },
        )
        result = self.store.commit(
            [wake],
            OperationRequest(
                operation_name="review.schedule",
                arguments={
                    "wake_id": wake_id,
                    "window_start": start.isoformat(),
                    "window_end": end.isoformat(),
                    "state": state.value,
                    "candidate_count": len(refs),
                    "truncated": bool(truncated),
                },
                expected_world_revision=int(self.store.current_world_revision()),
                reason=reason,
                idempotency_key=f"review-schedule:{wake_id}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        return ReviewWakeReceipt(
            wake_id=wake_id,
            revision=1,
            state=state.value,
            world_revision=result.world_revision,
        )

    def prepare_due_review(
        self,
        *,
        now: datetime,
        policy: ReviewSchedulePolicy | None = None,
    ) -> PeriodicReviewRequest | None:
        policy = policy or ReviewSchedulePolicy()
        moment = as_utc(now, "now")
        latest = self._latest_marker()

        if latest is not None and latest.wake_state in {
            WakeState.NEW,
            WakeState.QUEUED,
            WakeState.RUNNING,
        }:
            metadata = latest.metadata
            start = _parse_time(metadata.get("window_start"), "window_start")
            anchors = []
            for ref in latest.evidence_refs:
                payload = self.store.get_payload(
                    ref.object_id,
                    revision=ref.revision,
                )
                anchors.append(
                    ReviewAnchor(
                        object_ref=ref,
                        object_type=str(payload["object_type"]),
                        recorded_at=_parse_time(payload["recorded_at"], "recorded_at"),
                        excerpt=_excerpt(payload),
                    )
                )
            if not anchors:
                return None
            return PeriodicReviewRequest(
                review_id=latest.object_id,
                subject_id=self.subject_id,
                wake_ref=ObjectRef(
                    object_id=latest.object_id,
                    revision=latest.revision,
                ),
                window_start=start,
                window_end=_parse_time(
                    metadata.get("window_end"),
                    "window_end",
                ),
                anchors=tuple(anchors),
            )

        backlog = False
        if latest is not None:
            metadata = latest.metadata
            if (
                latest.wake_state is WakeState.COMPLETED
                and bool(metadata.get("truncated"))
            ):
                backlog = True
                window_start = _parse_time(
                    metadata.get("window_start"),
                    "window_start",
                )
                window_end = _parse_time(
                    metadata.get("window_end"),
                    "window_end",
                )
            else:
                since = moment - as_utc(latest.last_hit_at, "last_hit_at")
                if since < timedelta(hours=float(policy.interval_hours)):
                    return None
                raw_cursor = metadata.get("window_end")
                window_start = (
                    _parse_time(raw_cursor, "window_end")
                    if raw_cursor is not None
                    else as_utc(latest.last_hit_at, "last_hit_at")
                )
                window_end = moment
        else:
            window_start = moment - timedelta(hours=float(policy.lookback_hours))
            window_end = moment

        excluded = self._reviewed_refs_for_window(
            window_start=window_start,
            window_end=window_end,
        )
        anchors, truncated = self._collect_candidates(
            window_start=window_start,
            window_end=window_end,
            policy=policy,
            excluded_refs=excluded,
        )
        outcome_anchors, outcome_truncated = self._attention_outcome_anchors(
            window_start=window_start,
            window_end=window_end,
            limit=policy.max_candidates,
        )
        if outcome_anchors:
            existing_keys = {
                (
                    item.object_ref.object_id,
                    int(item.object_ref.revision or 0),
                )
                for item in anchors
            }
            combined = [
                *anchors,
                *[
                    item
                    for item in outcome_anchors
                    if (
                        item.object_ref.object_id,
                        int(item.object_ref.revision or 0),
                    )
                    not in existing_keys
                ],
            ]
            combined.sort(
                key=lambda item: (
                    item.recorded_at,
                    item.object_type,
                    item.object_ref.object_id,
                    int(item.object_ref.revision or 0),
                )
            )
            if len(combined) > policy.max_candidates:
                truncated = True
                combined = combined[-policy.max_candidates :]
            anchors = tuple(combined)
            truncated = bool(truncated or outcome_truncated)

        attention_anchors, attention_truncated = self._attention_review_queue_anchors(
            limit=policy.max_candidates,
        )
        if attention_anchors:
            attention_keys = {
                (
                    item.object_ref.object_id,
                    int(item.object_ref.revision or 0),
                )
                for item in attention_anchors
            }
            ordinary = [
                item
                for item in anchors
                if (
                    item.object_ref.object_id,
                    int(item.object_ref.revision or 0),
                )
                not in attention_keys
            ]
            remaining = max(0, policy.max_candidates - len(attention_anchors))
            selected_ordinary = ordinary[-remaining:] if remaining else []
            anchors = tuple(
                [
                    *selected_ordinary,
                    *attention_anchors,
                ]
            )
            anchors = tuple(
                sorted(
                    anchors,
                    key=lambda item: (
                        item.recorded_at,
                        item.object_type,
                        item.object_ref.object_id,
                        int(item.object_ref.revision or 0),
                    ),
                )
            )
            truncated = bool(
                truncated
                or attention_truncated
                or len(ordinary) > remaining
            )
        if not anchors:
            self._create_wake(
                now=moment,
                window_start=window_start,
                window_end=window_end,
                anchors=(),
                state=WakeState.SUPPRESSED,
                reason=(
                    "periodic review backlog drained"
                    if backlog
                    else "periodic review checked; no eligible world changes"
                ),
                truncated=False,
            )
            return None

        wake = self._create_wake(
            now=moment,
            window_start=window_start,
            window_end=window_end,
            anchors=anchors,
            state=WakeState.NEW,
            reason=(
                "periodic review backlog page due"
                if backlog
                else "periodic review due with eligible world changes"
            ),
            truncated=truncated,
        )
        return PeriodicReviewRequest(
            review_id=wake.wake_id,
            subject_id=self.subject_id,
            wake_ref=ObjectRef(object_id=wake.wake_id, revision=1),
            window_start=window_start,
            window_end=window_end,
            anchors=anchors,
        )

    def augment_request_with_attention_refs(
        self,
        request: PeriodicReviewRequest,
        refs: Sequence[ObjectRef],
        *,
        max_extra: int = 40,
    ) -> PeriodicReviewRequest:
        """Add mechanically queued attention evidence to an already-due review."""

        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        if max_extra < 0:
            raise ValueError("max_extra must be >= 0")

        merged = list(request.anchors)
        seen = {
            (item.object_ref.object_id, int(item.object_ref.revision or 0))
            for item in merged
        }
        added = 0
        for ref in refs:
            if added >= max_extra:
                break
            if ref.revision is None:
                raise ValueError("attention review refs must pin exact revisions")
            key = (ref.object_id, int(ref.revision))
            if key in seen:
                continue
            payload = self.store.get_payload(
                ref.object_id,
                revision=ref.revision,
            )
            if str(payload.get("subject_id") or "") != self.subject_id:
                raise ValueError("attention review ref belongs to another subject")
            recorded = _parse_time(payload.get("recorded_at"), "recorded_at")
            merged.append(
                ReviewAnchor(
                    object_ref=ref,
                    object_type=str(payload["object_type"]),
                    recorded_at=recorded,
                    excerpt=_excerpt(payload),
                )
            )
            seen.add(key)
            added += 1

        merged.sort(
            key=lambda item: (
                item.recorded_at,
                item.object_type,
                item.object_ref.object_id,
                int(item.object_ref.revision or 0),
            )
        )
        return request.model_copy(
            update={
                "anchors": tuple(merged),
                "instruction": (
                    request.instruction
                    + " Some anchors were explicitly queued by the Resident's "
                    "mechanical attention watches for this periodic review; treat "
                    "that routing fact as attention only, not as semantic truth."
                ),
            }
        )

    def defer_review(
        self,
        request: PeriodicReviewRequest,
        *,
        deferred_at: datetime,
        reasons: Sequence[str],
    ) -> ReviewWakeReceipt:
        """Keep a due review durable without invoking the Resident model."""

        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        moment = as_utc(deferred_at, "deferred_at")
        latest = Wake.model_validate(
            self.store.get_payload(request.wake_ref.object_id)
        )
        if latest.wake_state is WakeState.QUEUED:
            return ReviewWakeReceipt(
                wake_id=latest.object_id,
                revision=latest.revision,
                state=latest.wake_state.value,
                world_revision=int(self.store.current_world_revision()),
            )
        if latest.wake_state is not WakeState.NEW:
            raise ValueError("only NEW periodic review wake may be deferred")

        revision = latest.revision + 1
        metadata = dict(latest.metadata)
        metadata.update(
            {
                "budget_deferred_at": moment.isoformat(),
                "budget_defer_reasons": [
                    str(item) for item in reasons if str(item).strip()
                ],
            }
        )
        queued = Wake.model_validate(
            {
                **latest.model_dump(mode="python", round_trip=True),
                "revision": revision,
                "occurred": TemporalExtent.point(moment),
                "learned_at": moment,
                "recorded_at": moment,
                "wake_state": WakeState.QUEUED,
                "last_hit_at": moment,
                "status": WakeState.QUEUED.value,
                "metadata": metadata,
            }
        )
        result = self.store.commit(
            [queued],
            OperationRequest(
                operation_name="review.defer_budget",
                arguments={"wake_id": queued.object_id, "revision": revision},
                expected_world_revision=int(self.store.current_world_revision()),
                reason="defer periodic review because C13 background budget is unavailable",
                idempotency_key=f"review-defer-budget:{queued.object_id}:{revision}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        return ReviewWakeReceipt(
            wake_id=queued.object_id,
            revision=revision,
            state=WakeState.QUEUED.value,
            world_revision=result.world_revision,
        )

    def suppress_review(
        self,
        request: PeriodicReviewRequest,
        *,
        suppressed_at: datetime,
        reasons: Sequence[str],
    ) -> ReviewWakeReceipt:
        """Terminally suppress a due review when C13 policy is HARD_DENY."""

        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        moment = as_utc(suppressed_at, "suppressed_at")
        latest = Wake.model_validate(
            self.store.get_payload(request.wake_ref.object_id)
        )
        if latest.wake_state is WakeState.SUPPRESSED:
            return ReviewWakeReceipt(
                wake_id=latest.object_id,
                revision=latest.revision,
                state=latest.wake_state.value,
                world_revision=int(self.store.current_world_revision()),
            )
        if latest.wake_state not in {
            WakeState.NEW,
            WakeState.QUEUED,
            WakeState.RUNNING,
        }:
            raise ValueError("periodic review wake is not suppressible")

        revision = latest.revision + 1
        metadata = dict(latest.metadata)
        metadata.update(
            {
                "budget_suppressed_at": moment.isoformat(),
                "budget_suppress_reasons": [
                    str(item) for item in reasons if str(item).strip()
                ],
            }
        )
        suppressed = Wake.model_validate(
            {
                **latest.model_dump(mode="python", round_trip=True),
                "revision": revision,
                "occurred": TemporalExtent.point(moment),
                "learned_at": moment,
                "recorded_at": moment,
                "wake_state": WakeState.SUPPRESSED,
                "last_hit_at": moment,
                "status": WakeState.SUPPRESSED.value,
                "metadata": metadata,
            }
        )
        result = self.store.commit(
            [suppressed],
            OperationRequest(
                operation_name="review.suppress_budget",
                arguments={"wake_id": suppressed.object_id, "revision": revision},
                expected_world_revision=int(self.store.current_world_revision()),
                reason="suppress periodic review because C13 background budget hard-denied it",
                idempotency_key=f"review-suppress-budget:{suppressed.object_id}:{revision}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        return ReviewWakeReceipt(
            wake_id=suppressed.object_id,
            revision=revision,
            state=WakeState.SUPPRESSED.value,
            world_revision=result.world_revision,
        )

    def begin_review(
        self,
        request: PeriodicReviewRequest,
        *,
        started_at: datetime,
        expected_world_revision: int | None = None,
        metadata_update: Mapping[str, Any] | None = None,
    ) -> PeriodicReviewRequest:
        """Atomically claim a due review before invoking the resident model.

        A RUNNING wake is resumable after process failure. This prevents two workers
        from independently reviewing the same NEW wake while keeping crash recovery
        possible without inventing a second scheduler database.
        """
        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        started = as_utc(started_at, "started_at")
        payload = self.store.get_payload(
            request.wake_ref.object_id,
            revision=request.wake_ref.revision,
        )
        wake = Wake.model_validate(payload)
        latest = Wake.model_validate(self.store.get_payload(wake.object_id))

        if latest.wake_state is WakeState.RUNNING and not metadata_update:
            if latest.revision != request.wake_ref.revision:
                return request.model_copy(
                    update={
                        "wake_ref": ObjectRef(
                            object_id=latest.object_id,
                            revision=latest.revision,
                        )
                    }
                )
            return request

        if latest.wake_state is WakeState.RUNNING and metadata_update:
            wake = latest
        elif latest.revision != wake.revision:
            raise ValueError("review wake is no longer current")

        if wake.wake_state not in {
            WakeState.NEW,
            WakeState.QUEUED,
            WakeState.RUNNING,
        }:
            raise ValueError("only NEW/QUEUED/RUNNING periodic review wake may begin")

        new_revision = wake.revision + 1
        metadata = dict(wake.metadata)
        # A RUNNING review may refresh a budget reservation after a window rollover.
        # Keep the original cognition/write timestamp stable across that recovery;
        # economic metering uses the actual execution time independently.
        if wake.wake_state is not WakeState.RUNNING or metadata.get("started_at") is None:
            metadata["started_at"] = started.isoformat()
        metadata.update(dict(metadata_update or {}))
        running = Wake.model_validate(
            {
                **wake.model_dump(mode="python", round_trip=True),
                "revision": new_revision,
                "occurred": TemporalExtent.point(started),
                "learned_at": started,
                "recorded_at": started,
                "wake_state": WakeState.RUNNING,
                "last_hit_at": started,
                "hit_count": wake.hit_count + 1,
                "status": WakeState.RUNNING.value,
                "metadata": metadata,
            }
        )
        result = self.store.commit(
            [running],
            OperationRequest(
                operation_name="review.begin",
                arguments={
                    "wake_id": wake.object_id,
                    "revision": new_revision,
                },
                expected_world_revision=(
                    int(self.store.current_world_revision())
                    if expected_world_revision is None
                    else int(expected_world_revision)
                ),
                reason="claim due periodic review for resident-model execution",
                idempotency_key=f"review-begin:{wake.object_id}:{new_revision}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        _ = result
        return request.model_copy(
            update={
                "wake_ref": ObjectRef(
                    object_id=running.object_id,
                    revision=new_revision,
                )
            }
        )

    def mark_runtime_incomplete(
        self,
        request: PeriodicReviewRequest,
        *,
        marked_at: datetime,
        termination_reason: str,
        model_rounds: int,
        next_model_round_index: int,
        capability_names: Sequence[str],
    ) -> PeriodicReviewRequest:
        """Persist a known-safe continuation point without completing the review."""

        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        if (
            isinstance(next_model_round_index, bool)
            or not isinstance(next_model_round_index, int)
            or next_model_round_index < 1
        ):
            raise ValueError("next_model_round_index must be a positive integer")
        moment = as_utc(marked_at, "marked_at")
        payload = self.store.get_payload(
            request.wake_ref.object_id,
            revision=request.wake_ref.revision,
        )
        wake = Wake.model_validate(payload)
        latest = Wake.model_validate(self.store.get_payload(wake.object_id))
        if latest.revision != wake.revision:
            raise ValueError("review wake is no longer current")
        if wake.wake_state is not WakeState.RUNNING:
            raise ValueError("only RUNNING periodic review may be runtime-incomplete")

        metadata = dict(wake.metadata)
        attempts = metadata.get("runtime_incomplete_attempts", 0)
        if not isinstance(attempts, int) or isinstance(attempts, bool) or attempts < 0:
            attempts = 0
        metadata.update(
            {
                "runtime_incomplete": True,
                "runtime_incomplete_at": moment.isoformat(),
                "runtime_incomplete_reason": str(termination_reason),
                "runtime_incomplete_attempts": attempts + 1,
                "runtime_incomplete_model_rounds": int(model_rounds),
                "runtime_incomplete_next_model_round_index": int(
                    next_model_round_index
                ),
                "runtime_incomplete_capability_names": [
                    str(item) for item in capability_names
                ],
            }
        )
        new_revision = wake.revision + 1
        running = Wake.model_validate(
            {
                **wake.model_dump(mode="python", round_trip=True),
                "revision": new_revision,
                "occurred": TemporalExtent.point(moment),
                "learned_at": moment,
                "recorded_at": moment,
                "wake_state": WakeState.RUNNING,
                "status": WakeState.RUNNING.value,
                "metadata": metadata,
            }
        )
        self.store.commit(
            [running],
            OperationRequest(
                operation_name="review.runtime_incomplete",
                arguments={
                    "wake_id": wake.object_id,
                    "revision": new_revision,
                    "termination_reason": str(termination_reason),
                    "next_model_round_index": int(next_model_round_index),
                },
                expected_world_revision=int(self.store.current_world_revision()),
                reason="persist known-safe periodic review model continuation point",
                idempotency_key=f"review-runtime-incomplete:{wake.object_id}:{new_revision}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        return request.model_copy(
            update={
                "wake_ref": ObjectRef(
                    object_id=running.object_id,
                    revision=new_revision,
                )
            }
        )

    def complete_review(
        self,
        request: PeriodicReviewRequest,
        *,
        completed_at: datetime,
        termination_reason: str,
        model_rounds: int,
        capability_names: Sequence[str],
    ) -> ReviewWakeReceipt:
        if request.subject_id != self.subject_id:
            raise ValueError("review request belongs to another subject")
        completed = as_utc(completed_at, "completed_at")
        payload = self.store.get_payload(
            request.wake_ref.object_id,
            revision=request.wake_ref.revision,
        )
        wake = Wake.model_validate(payload)
        latest = Wake.model_validate(self.store.get_payload(wake.object_id))
        if latest.revision != wake.revision:
            if latest.wake_state is WakeState.COMPLETED:
                return ReviewWakeReceipt(
                    wake_id=latest.object_id,
                    revision=latest.revision,
                    state=latest.wake_state.value,
                    world_revision=int(self.store.current_world_revision()),
                )
            raise ValueError("review wake is no longer current")
        if wake.wake_state is not WakeState.RUNNING:
            raise ValueError("only RUNNING periodic review wake may complete")

        metadata = dict(wake.metadata)
        metadata.update(
            {
                "completed_at": completed.isoformat(),
                "termination_reason": termination_reason,
                "model_rounds": int(model_rounds),
                "capability_names": list(capability_names),
            }
        )
        new_revision = wake.revision + 1
        completed_wake = Wake.model_validate(
            {
                **wake.model_dump(mode="python", round_trip=True),
                "revision": new_revision,
                "occurred": TemporalExtent.point(completed),
                "learned_at": completed,
                "recorded_at": completed,
                "wake_state": WakeState.COMPLETED,
                "last_hit_at": completed,
                "hit_count": wake.hit_count + 1,
                "status": WakeState.COMPLETED.value,
                "metadata": metadata,
            }
        )
        result = self.store.commit(
            [completed_wake],
            OperationRequest(
                operation_name="review.complete",
                arguments={
                    "wake_id": wake.object_id,
                    "revision": new_revision,
                    "termination_reason": termination_reason,
                },
                expected_world_revision=int(self.store.current_world_revision()),
                reason="record completion of model-driven periodic review",
                idempotency_key=f"review-complete:{wake.object_id}:{new_revision}",
                source_class=SourceClass.MAINTENANCE,
                maintenance_class=MaintenanceClass.PERIODIC_REVIEW,
            ),
        )
        self._catch_up()
        return ReviewWakeReceipt(
            wake_id=wake.object_id,
            revision=new_revision,
            state=WakeState.COMPLETED.value,
            world_revision=result.world_revision,
        )

    def commit_operation_experience(
        self,
        request: OperationExperienceRequest,
        *,
        learned_at: datetime,
    ) -> OperationExperienceReceipt:
        request = OperationExperienceRequest.model_validate(
            request.model_dump(mode="python", round_trip=True)
        )
        learned = as_utc(learned_at, "learned_at")
        refs = (*request.positive_case_refs, *request.negative_case_refs)
        for ref in refs:
            payload = self.store.get_payload(
                ref.object_id,
                revision=ref.revision,
            )
            if payload.get("subject_id") != self.subject_id:
                raise ValueError(
                    "operation experience case ref belongs to another subject"
                )
            try:
                object_type = ObjectType(str(payload["object_type"]))
            except (KeyError, ValueError) as exc:
                raise ValueError(
                    "operation experience case ref has invalid object type"
                ) from exc
            if object_type not in _REAL_OPERATION_CASE_TYPES:
                raise ValueError(
                    "operation experience requires real result evidence: "
                    "Observation, Outcome or CommunicationExperience"
                )
            if object_type is ObjectType.OBSERVATION:
                metadata = payload.get("metadata")
                role = (
                    str(metadata.get("role") or "").strip().lower()
                    if isinstance(metadata, Mapping)
                    else ""
                )
                created_by = str(payload.get("created_by") or "").strip().lower()
                if role == "assistant" or created_by == "conversation_ingest:assistant":
                    raise ValueError(
                        "assistant observation cannot be used as real result evidence"
                    )

        experience_id = _stable_id(
            "opexp",
            self.subject_id,
            request.problem_type.strip(),
            tuple(step.strip() for step in request.method_path),
            request.result_summary.strip(),
            request.applicability,
            {key: float(value) for key, value in request.cost.items()},
            tuple(item.strip() for item in request.misses),
            request.experience_state.strip(),
            [
                (ref.object_id, ref.revision)
                for ref in request.positive_case_refs
            ],
            [
                (ref.object_id, ref.revision)
                for ref in request.negative_case_refs
            ],
        )
        try:
            existing = self.store.get_payload(experience_id, revision=1)
        except StoreError as exc:
            if exc.code == ErrorCode.NOT_FOUND:
                existing = None
            else:
                raise
        if existing is not None:
            self._catch_up()
            return OperationExperienceReceipt(
                experience_id=experience_id,
                revision=1,
                world_revision=int(self.store.current_world_revision()),
            )

        experience = OperationExperience(
            object_id=experience_id,
            subject_id=self.subject_id,
            occurred=TemporalExtent.point(learned),
            learned_at=learned,
            recorded_at=learned,
            source_refs=[
                SourceRef(object_id=ref.object_id, revision=ref.revision)
                for ref in refs
            ],
            created_by="periodic_review:resident_ai",
            problem_type=request.problem_type.strip(),
            method_path=[step.strip() for step in request.method_path],
            applicability=dict(request.applicability),
            cost={key: float(value) for key, value in request.cost.items()},
            result_summary=request.result_summary.strip(),
            misses=[item.strip() for item in request.misses],
            positive_case_refs=list(request.positive_case_refs),
            negative_case_refs=list(request.negative_case_refs),
            experience_state=request.experience_state.strip(),
            metadata={
                "review_kind": REVIEW_KIND,
                "evidence_grounded": True,
            },
        )
        exp_ref = ObjectRef(object_id=experience_id, revision=1)
        dependencies = [
            Dependency(
                object_id=_stable_id(
                    "dep_opexp",
                    experience_id,
                    ref.object_id,
                    ref.revision,
                ),
                subject_id=self.subject_id,
                learned_at=learned,
                recorded_at=learned,
                created_by="periodic_review:dependency",
                dependent_ref=exp_ref,
                dependency_ref=ref,
                dependency_type="operation_experience_uses_case",
            )
            for ref in refs
        ]
        result = self.store.commit(
            [experience, *dependencies],
            OperationRequest(
                operation_name="review.commit_operation_experience",
                arguments={
                    "experience_id": experience_id,
                    "problem_type": request.problem_type,
                    "positive_count": len(request.positive_case_refs),
                    "negative_count": len(request.negative_case_refs),
                },
                expected_world_revision=int(self.store.current_world_revision()),
                reason="persist model-authored experience grounded in real cases",
                idempotency_key=f"operation-experience:{experience_id}",
                source_class=SourceClass.AI_COGNITION,
            ),
        )
        self._catch_up()
        return OperationExperienceReceipt(
            experience_id=experience_id,
            revision=1,
            world_revision=result.world_revision,
        )
