"""C13 mechanical budget gate for autonomous Resident model execution.

The gate reads durable BudgetPolicy objects from the unified World and measures
usage from durable Wake lifecycle records. It never judges semantic importance.

Provider token usage is intentionally *not* estimated here. Exact completed usage
is counted when a model handler reports it. A hard max_tokens policy still fails
closed unless a reliable pre-invocation token bound exists, because post-call usage
cannot guarantee that the first request stayed under the cap.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping

from aios_core.contracts.enums import (
    BudgetOnExceed,
    BudgetScope,
    ObjectType,
    WakeSource,
    WakeState,
)
from aios_core.contracts.models import BudgetPolicy, Wake
from aios_core.contracts.refs import ObjectRef
from aios_core.contracts.time import as_utc
from aios_core.storage.sqlite_store import SQLiteWorldStore

from .metering import ModelMeteringLedger


@dataclass(frozen=True, slots=True)
class BackgroundBudgetDecision:
    applies: bool
    available: bool
    world_revision: int
    window_start: datetime | None = None
    window_end: datetime | None = None
    policy_refs: tuple[ObjectRef, ...] = ()
    used_wakes: int = 0
    used_model_calls: int = 0
    used_tokens: int = 0
    token_usage_available: bool = False
    max_wakes: int | None = None
    max_model_calls: int | None = None
    model_round_limit: int | None = None
    reserved_model_calls: int = 0
    reasons: tuple[str, ...] = ()
    on_exceed: tuple[BudgetOnExceed, ...] = ()

    @property
    def hard_deny(self) -> bool:
        return (not self.available) and BudgetOnExceed.HARD_DENY in self.on_exceed

    @property
    def requires_reservation(self) -> bool:
        return self.applies and self.available and bool(self.policy_refs)

    def reservation_metadata(self) -> dict[str, Any]:
        if not self.requires_reservation or self.window_start is None or self.window_end is None:
            return {}
        return {
            "budget_scope": BudgetScope.BACKGROUND_DAY.value,
            "budget_window_start": self.window_start.isoformat(),
            "budget_window_end": self.window_end.isoformat(),
            "budget_policy_refs": [
                ref.model_dump(mode="json") for ref in self.policy_refs
            ],
            "budget_reserved_wakes": 1,
            "budget_reserved_model_calls": int(self.reserved_model_calls),
        }

    def context_payload(self) -> dict[str, Any]:
        return {
            "applies": self.applies,
            "available": self.available,
            "scope": (
                BudgetScope.BACKGROUND_DAY.value if self.applies else None
            ),
            "window_start": (
                None if self.window_start is None else self.window_start.isoformat()
            ),
            "window_end": (
                None if self.window_end is None else self.window_end.isoformat()
            ),
            "policy_refs": [
                ref.model_dump(mode="json") for ref in self.policy_refs
            ],
            "used_wakes": self.used_wakes,
            "used_model_calls": self.used_model_calls,
            "used_tokens": self.used_tokens,
            "token_usage_available": self.token_usage_available,
            "max_wakes": self.max_wakes,
            "max_model_calls": self.max_model_calls,
            "model_round_limit": self.model_round_limit,
            "reserved_model_calls": self.reserved_model_calls,
            "reasons": list(self.reasons),
        }


class BackgroundBudgetGate:
    """Enforce BACKGROUND_DAY BudgetPolicy before autonomous model execution."""

    def __init__(
        self,
        *,
        store: SQLiteWorldStore,
        subject_id: str = "user_1",
        metering_ledger: ModelMeteringLedger | None = None,
    ) -> None:
        if not isinstance(subject_id, str) or not subject_id.strip():
            raise ValueError("subject_id must not be blank")
        self.store = store
        self.subject_id = subject_id.strip()
        self.metering_ledger = metering_ledger or ModelMeteringLedger(store)

    @staticmethod
    def _window(now: datetime) -> tuple[datetime, datetime]:
        moment = as_utc(now, "now")
        start = moment.astimezone(timezone.utc).replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0,
        )
        return start, start + timedelta(days=1)

    def _policies(self) -> tuple[BudgetPolicy, ...]:
        policies: list[BudgetPolicy] = []
        for payload in self.store.list_payloads(
            object_type=ObjectType.BUDGET_POLICY,
            subject_id=self.subject_id,
        ):
            if str(payload.get("status") or "active") != "active":
                continue
            policy = BudgetPolicy.model_validate(payload)
            if policy.scope is BudgetScope.BACKGROUND_DAY:
                policies.append(policy)
        policies.sort(
            key=lambda item: (
                as_utc(item.recorded_at, "recorded_at"),
                item.object_id,
                item.revision,
            )
        )
        return tuple(policies)

    @staticmethod
    def _parse_time(value: object, field_name: str) -> datetime | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return as_utc(value, field_name)
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return as_utc(parsed, field_name)

    @staticmethod
    def _is_autonomous_wake(wake: Wake) -> bool:
        return wake.wake_source not in {
            WakeSource.SAFETY,
            WakeSource.USER_INTERACTION,
        }

    def _usage(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
        exclude_wake_id: str,
    ) -> tuple[int, int, int, bool]:
        used_wakes = 0
        used_model_calls = 0

        # Token truth comes from the non-world metering ledger. Wake metadata remains
        # lifecycle/grant state and is not the authoritative economic ledger.
        meter_records = self.metering_ledger.list_model_calls(
            subject_id=self.subject_id,
            start_at=window_start,
            end_at=window_end,
            execution_classes=("background", "periodic_review"),
        )
        records_by_wake: dict[str, list[Any]] = {}
        used_tokens = 0
        token_usage_available = True
        for record in meter_records:
            if record.wake_id == exclude_wake_id:
                continue
            if record.wake_id is not None:
                records_by_wake.setdefault(record.wake_id, []).append(record)
            if record.usage_complete and record.total_tokens is not None:
                used_tokens += record.total_tokens
            else:
                token_usage_available = False

        for payload in self.store.list_payloads(
            object_type=ObjectType.WAKE,
            subject_id=self.subject_id,
        ):
            wake = Wake.model_validate(payload)
            if wake.object_id == exclude_wake_id:
                continue
            if not self._is_autonomous_wake(wake):
                continue

            metadata: Mapping[str, Any] = wake.metadata
            if (
                wake.wake_state is WakeState.QUEUED
                and bool(metadata.get("runtime_incomplete"))
            ):
                attempt_at = self._parse_time(
                    metadata.get("runtime_incomplete_at")
                    or metadata.get("runtime_first_started_at")
                    or wake.recorded_at,
                    "runtime_incomplete_at",
                )
                if attempt_at is None or not (
                    window_start <= attempt_at < window_end
                ):
                    continue
                wake_records = records_by_wake.get(wake.object_id, ())
                rounds = len(wake_records)
                if rounds == 0:
                    raw_rounds = metadata.get("runtime_incomplete_model_rounds")
                    if (
                        isinstance(raw_rounds, int)
                        and not isinstance(raw_rounds, bool)
                        and raw_rounds > 0
                    ):
                        rounds = raw_rounds
                    token_usage_available = False
                elif not all(
                    record.usage_complete and record.total_tokens is not None
                    for record in wake_records
                ):
                    token_usage_available = False
                if rounds > 0:
                    used_wakes += 1
                    used_model_calls += rounds
                continue

            if wake.wake_state is WakeState.RUNNING:
                started_at = self._parse_time(
                    metadata.get("started_at"),
                    "started_at",
                )
                if started_at is None:
                    started_at = as_utc(wake.recorded_at, "recorded_at")
                if not (window_start <= started_at < window_end):
                    continue
                used_wakes += 1
                reserved = metadata.get("budget_reserved_model_calls")
                if isinstance(reserved, int) and not isinstance(reserved, bool) and reserved > 0:
                    used_model_calls += reserved
                else:
                    used_model_calls += max(
                        1,
                        len(records_by_wake.get(wake.object_id, ())),
                    )
                # A RUNNING invocation may still consume another model call. Exact
                # spend-so-far is visible above, but the final token total is unknown.
                token_usage_available = False
                continue

            if wake.wake_state is not WakeState.COMPLETED:
                continue

            completed_at = self._parse_time(
                metadata.get("completed_at"),
                "completed_at",
            )
            if completed_at is None:
                completed_at = self._parse_time(
                    metadata.get("started_at"),
                    "started_at",
                )
            if completed_at is None:
                completed_at = as_utc(wake.recorded_at, "recorded_at")
            if not (window_start <= completed_at < window_end):
                continue

            rounds = metadata.get("model_rounds")
            if (
                not isinstance(rounds, int)
                or isinstance(rounds, bool)
                or rounds <= 0
            ):
                continue
            used_wakes += 1

            # C13 MeteringLedger is the economic truth. A C14 Wake may span
            # multiple runtime-incomplete attempts before semantic completion, so
            # the final Wake metadata only describes the last attempt. Count every
            # durable provider response for modern Wakes; fall back to lifecycle
            # metadata only for legacy Wakes that predate the ledger.
            wake_records = records_by_wake.get(wake.object_id, ())
            if wake_records:
                used_model_calls += len(wake_records)
            else:
                used_model_calls += rounds
                token_usage_available = False

        return (
            used_wakes,
            used_model_calls,
            used_tokens,
            token_usage_available,
        )

    def _queued_runtime_incomplete_usage(
        self,
        wake: Wake,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> tuple[int, int, int, bool]:
        if (
            wake.wake_state is not WakeState.QUEUED
            or not bool(wake.metadata.get("runtime_incomplete"))
        ):
            return 0, 0, 0, True
        raw_at = (
            wake.metadata.get("runtime_incomplete_at")
            or wake.metadata.get("runtime_first_started_at")
            or wake.recorded_at
        )
        attempt_at = self._parse_time(raw_at, "runtime_incomplete_at")
        if attempt_at is None or not (window_start <= attempt_at < window_end):
            return 0, 0, 0, True

        records = self.metering_ledger.list_model_calls(
            subject_id=self.subject_id,
            start_at=window_start,
            end_at=window_end,
            execution_classes=("background", "periodic_review"),
            wake_id=wake.object_id,
        )
        used_model_calls = len(records)
        used_tokens = sum(
            int(record.total_tokens or 0)
            for record in records
            if record.usage_complete and record.total_tokens is not None
        )
        token_usage_available = bool(records) and all(
            record.usage_complete and record.total_tokens is not None
            for record in records
        )
        if not records:
            raw_rounds = wake.metadata.get("runtime_incomplete_model_rounds")
            if isinstance(raw_rounds, int) and not isinstance(raw_rounds, bool):
                used_model_calls = max(0, raw_rounds)
            token_usage_available = False
        return (
            1 if used_model_calls > 0 else 0,
            used_model_calls,
            used_tokens,
            token_usage_available,
        )

    def status(self, *, now: datetime) -> dict[str, Any]:
        """Return mechanical BACKGROUND_DAY policy/usage facts for Resident inspection."""

        world_revision = int(self.store.current_world_revision())
        policies = self._policies()
        if not policies:
            return {
                "applies": False,
                "scope": BudgetScope.BACKGROUND_DAY.value,
                "world_revision": world_revision,
                "policy_refs": [],
                "used_wakes": 0,
                "used_model_calls": 0,
                "used_tokens": 0,
                "max_wakes": None,
                "max_model_calls": None,
                "max_tokens": None,
                "remaining_wakes": None,
                "remaining_model_calls": None,
                "remaining_tokens": None,
                "token_usage_available": False,
                "on_exceed": [],
            }

        window_start, window_end = self._window(now)
        (
            used_wakes,
            used_model_calls,
            used_tokens,
            token_usage_available,
        ) = self._usage(
            window_start=window_start,
            window_end=window_end,
            exclude_wake_id="",
        )
        wake_caps = [item.max_wakes for item in policies if item.max_wakes is not None]
        call_caps = [
            item.max_model_calls
            for item in policies
            if item.max_model_calls is not None
        ]
        token_caps = [item.max_tokens for item in policies if item.max_tokens is not None]
        max_wakes = min(wake_caps) if wake_caps else None
        max_model_calls = min(call_caps) if call_caps else None
        max_tokens = min(token_caps) if token_caps else None

        return {
            "applies": True,
            "scope": BudgetScope.BACKGROUND_DAY.value,
            "world_revision": world_revision,
            "window_start": window_start.isoformat(),
            "window_end": window_end.isoformat(),
            "policy_refs": [
                ObjectRef(
                    object_id=item.object_id,
                    revision=item.revision,
                ).model_dump(mode="json")
                for item in policies
            ],
            "used_wakes": used_wakes,
            "used_model_calls": used_model_calls,
            "used_tokens": used_tokens,
            "max_wakes": max_wakes,
            "max_model_calls": max_model_calls,
            "max_tokens": max_tokens,
            "remaining_wakes": (
                None if max_wakes is None else max(0, max_wakes - used_wakes)
            ),
            "remaining_model_calls": (
                None
                if max_model_calls is None
                else max(0, max_model_calls - used_model_calls)
            ),
            "remaining_tokens": (
                None
                if max_tokens is None or not token_usage_available
                else max(0, max_tokens - used_tokens)
            ),
            "token_usage_available": token_usage_available,
            "on_exceed": list(
                dict.fromkeys(item.on_exceed.value for item in policies)
            ),
        }

    def evaluate(
        self,
        wake: Wake,
        *,
        now: datetime,
        max_model_rounds: int,
        require_full_model_round_budget: bool = False,
    ) -> BackgroundBudgetDecision:
        if max_model_rounds < 1:
            raise ValueError("max_model_rounds must be >= 1")

        world_revision = int(self.store.current_world_revision())
        if not self._is_autonomous_wake(wake):
            return BackgroundBudgetDecision(
                applies=False,
                available=True,
                world_revision=world_revision,
            )

        policies = self._policies()
        if not policies:
            return BackgroundBudgetDecision(
                applies=False,
                available=True,
                world_revision=world_revision,
            )

        window_start, window_end = self._window(now)
        policy_refs = tuple(
            ObjectRef(object_id=item.object_id, revision=item.revision)
            for item in policies
        )

        # A budget-reserved RUNNING Wake must never become a free same-day retry.
        # The process may have crashed after calling the provider, so Core cannot
        # safely assume the reservation is unused. Keep it blocked for that budget
        # window; after the window rolls over a fresh reservation may be claimed.
        if wake.wake_state is WakeState.RUNNING:
            metadata = wake.metadata
            if str(metadata.get("budget_scope") or "") == BudgetScope.BACKGROUND_DAY.value:
                reserved_start = self._parse_time(
                    metadata.get("budget_window_start"),
                    "budget_window_start",
                )
                reserved_end = self._parse_time(
                    metadata.get("budget_window_end"),
                    "budget_window_end",
                )
                if (
                    reserved_start is not None
                    and reserved_end is not None
                    and reserved_start <= as_utc(now, "now") < reserved_end
                ):
                    return BackgroundBudgetDecision(
                        applies=True,
                        available=False,
                        world_revision=world_revision,
                        window_start=window_start,
                        window_end=window_end,
                        policy_refs=policy_refs,
                        reasons=("background_budget_reservation_already_running",),
                    )

        (
            used_wakes,
            used_model_calls,
            used_tokens,
            token_usage_available,
        ) = self._usage(
            window_start=window_start,
            window_end=window_end,
            exclude_wake_id=wake.object_id,
        )
        (
            resumed_wakes,
            resumed_model_calls,
            resumed_tokens,
            resumed_token_usage_available,
        ) = self._queued_runtime_incomplete_usage(
            wake,
            window_start=window_start,
            window_end=window_end,
        )
        used_wakes += resumed_wakes
        used_model_calls += resumed_model_calls
        used_tokens += resumed_tokens
        token_usage_available = (
            token_usage_available and resumed_token_usage_available
        )

        wake_caps = [item.max_wakes for item in policies if item.max_wakes is not None]
        call_caps = [
            item.max_model_calls
            for item in policies
            if item.max_model_calls is not None
        ]
        max_wakes = min(wake_caps) if wake_caps else None
        max_model_calls = min(call_caps) if call_caps else None

        reasons: list[str] = []
        exceeded_modes: list[BudgetOnExceed] = []

        token_policies = [item for item in policies if item.max_tokens is not None]
        if token_policies:
            reasons.append(
                "background_token_budget_requires_preflight_token_bound"
                if token_usage_available
                else "background_token_budget_usage_incomplete"
            )
            exceeded_modes.extend(item.on_exceed for item in token_policies)

        if max_wakes is not None and used_wakes >= max_wakes:
            reasons.append(
                f"background_wake_budget_exhausted:{used_wakes}/{max_wakes}"
            )
            exceeded_modes.extend(
                item.on_exceed
                for item in policies
                if item.max_wakes is not None and used_wakes >= item.max_wakes
            )

        remaining_calls: int | None = None
        if max_model_calls is not None:
            remaining_calls = max_model_calls - used_model_calls
            if remaining_calls <= 0:
                reasons.append(
                    "background_model_call_budget_exhausted:"
                    f"{used_model_calls}/{max_model_calls}"
                )
                exceeded_modes.extend(
                    item.on_exceed
                    for item in policies
                    if item.max_model_calls is not None
                    and used_model_calls >= item.max_model_calls
                )
            elif (
                require_full_model_round_budget
                and remaining_calls < max_model_rounds
            ):
                reasons.append(
                    "background_model_call_budget_insufficient_for_full_run:"
                    f"{remaining_calls}/{max_model_rounds}"
                )
                exceeded_modes.extend(
                    item.on_exceed
                    for item in policies
                    if item.max_model_calls is not None
                )

        available = not reasons
        if not available:
            return BackgroundBudgetDecision(
                applies=True,
                available=False,
                world_revision=world_revision,
                window_start=window_start,
                window_end=window_end,
                policy_refs=policy_refs,
                used_wakes=used_wakes,
                used_model_calls=used_model_calls,
                used_tokens=used_tokens,
                token_usage_available=token_usage_available,
                max_wakes=max_wakes,
                max_model_calls=max_model_calls,
                reasons=tuple(dict.fromkeys(reasons)),
                on_exceed=tuple(dict.fromkeys(exceeded_modes)),
            )

        model_round_limit = None
        reserved_model_calls = 0
        if remaining_calls is not None:
            model_round_limit = (
                max_model_rounds
                if require_full_model_round_budget
                else min(max_model_rounds, remaining_calls)
            )
            reserved_model_calls = model_round_limit

        return BackgroundBudgetDecision(
            applies=True,
            available=True,
            world_revision=world_revision,
            window_start=window_start,
            window_end=window_end,
            policy_refs=policy_refs,
            used_wakes=used_wakes,
            used_model_calls=used_model_calls,
            used_tokens=used_tokens,
            token_usage_available=token_usage_available,
            max_wakes=max_wakes,
            max_model_calls=max_model_calls,
            model_round_limit=model_round_limit,
            reserved_model_calls=reserved_model_calls,
            on_exceed=tuple(dict.fromkeys(item.on_exceed for item in policies)),
        )
