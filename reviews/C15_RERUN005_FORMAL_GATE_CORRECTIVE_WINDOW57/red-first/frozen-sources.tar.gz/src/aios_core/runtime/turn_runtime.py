"""First runnable fused AIOS v3.0 turn loop.

This module connects proactive recommendation, context assembly, model-driven
capabilities and unified-world conversation writeback. It is intentionally small:
advanced summaries, AI-self writeback and policy learning are layered on after this
vertical slice stays green.
"""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from typing import Any, Callable, Mapping, Sequence

from aios_core.storage.idempotency import canonical_json_dumps

from .turn_execution import TurnExecutionStore

from aios_core.ai_world import (
    AI_SELF_SUBJECT_ID,
    AIWorldClaimRequest,
    AIWorldCognitionService,
    AIWorldDomain,
)
from aios_core.context.continuity import (
    ConversationContinuityService,
    RoundSummaryCommit,
    RoundSummaryRequest,
)
from aios_core.context.controller import ContextController, ModelContextBundle
from aios_core.communication import CommunicationExperienceRequest, CommunicationExperienceService
from aios_core.dimensions import (
    DimensionProposalRequest,
    DimensionRegistryService,
    DimensionTransitionRequest,
)
from aios_core.events import EventDimensionService, EventTransitionRequest, EventWriteRequest
from aios_core.execution import (
    ActionProposalRequest,
    GoalCreateRequest,
    GoalTaskActionService,
    GoalTransitionRequest,
    TaskCreateRequest,
    TaskTransitionRequest,
)
from aios_core.ingest import RealityIngestService
from aios_core.ingest.conversation import (
    INTERACTION_DIMENSION,
    ConversationCommit,
    ConversationIngestor,
)
from aios_core.policy import (
    CognitionEvidencePolicy,
    CognitivePolicyCreateRequest,
    CognitivePolicyRegistry,
    CognitivePolicyUpdateRequest,
)
from aios_core.projections.all_dimensions import AllDimensionsProjectionService
from aios_core.query.search import WorldSearchIndex
from aios_core.recommendation.proactive import (
    ProactiveMemoryRecommender,
    RecommendationBundle,
)
from aios_core.recommendation.topic_state import TopicState, TopicStateService
from aios_core.revision.service import ClaimRevisionRequest, CognitionRevisionService
from aios_core.review import (
    OperationExperienceRequest,
    PeriodicReviewRequest,
    PeriodicReviewService,
    ReviewSchedulePolicy,
    ReviewWakeReceipt,
)
from aios_core.storage.sqlite_store import SQLiteWorldStore
from aios_core.summaries import (
    CognitiveDerivationScheduler,
    DimensionSummaryInput,
    MultiScaleSummaryScheduler,
    SummaryScale,
    SummaryScheduleResult,
)
from aios_core.writeback.cognition import ClaimWriteRequest, CognitionWritebackService
from aios_core.contracts.refs import ObjectRef
from aios_core.contracts.time import TemporalExtent, as_utc, canonical_utc_iso
from aios_core.contracts.enums import AttentionClass, ObjectType, PolicyClass, WakeSource
from aios_core.wake import (
    AttentionRouter,
    AttentionSchedulingPolicy,
    AttentionWatchRequest,
    AttentionWatchService,
    NumericPredicate,
    Step0GateInput,
    Step0GateResult,
    WakeBus,
    WakeStateReceipt,
)
from aios_core.world_graph import (
    EntityProposalRequest,
    EntityRelationService,
    EntityRevisionRequest,
    RelationUpsertRequest,
)

from .background_attempt import (
    BackgroundModelAttempt,
    BackgroundModelAttemptStore,
    BackgroundModelExecutionInDoubt,
    BackgroundModelResponseStaging,
)
from .budget_gate import BackgroundBudgetDecision, BackgroundBudgetGate
from .capabilities import CapabilityKind, CapabilityRegistry, CapabilitySpec
from .cognitive_runtime import (
    CognitiveRuntime,
    ModelDirective,
    ModelHandler,
    RecoveredModelResponse,
    RuntimeSnapshot,
    RuntimeTurnResult,
)
from .metering import ModelMeteringLedger
from .late_return import ExternalReturnObserver, LateReturnVerifier


_AUTO_TOPIC = object()

class _KnowledgeCutoffStoreView:
    """Read-only temporal lens over the durable World store.

    Services using this view keep their existing parsing, subject isolation and
    revision semantics while every object lookup is constrained to one knowledge cut.
    """

    def __init__(self, store: SQLiteWorldStore, cutoff: datetime) -> None:
        self._store = store
        self._cutoff = as_utc(cutoff, "knowledge_cutoff")

    def get_payload(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        kwargs["knowledge_cutoff"] = self._cutoff
        return self._store.get_payload(*args, **kwargs)

    def list_payloads(self, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
        kwargs["knowledge_cutoff"] = self._cutoff
        return self._store.list_payloads(*args, **kwargs)

    def iter_latest_payloads(self, *args: Any, **kwargs: Any):
        kwargs["knowledge_cutoff"] = self._cutoff
        return self._store.iter_latest_payloads(*args, **kwargs)

    def get_payloads_for_ids(self, *args: Any, **kwargs: Any) -> dict[str, dict[str, Any]]:
        kwargs["knowledge_cutoff"] = self._cutoff
        return self._store.get_payloads_for_ids(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._store, name)


_C14_COGNITIVE_SIDE_EFFECT_ALLOWLIST = frozenset(
    {
        "commit_claim",
        "commit_ai_world_claim",
        "revise_claim",
        "retract_claim",
    }
)
_C14_SEMANTIC_TERMINATIONS = frozenset({"responded", "silence"})


@dataclass(frozen=True, slots=True)
class FusedTurnResult:
    runtime: RuntimeTurnResult
    recommendation: RecommendationBundle
    context: ModelContextBundle
    conversation_commit: ConversationCommit
    continuity_summary_commits: tuple[RoundSummaryCommit, ...] = ()
    continuity_summary_error: str | None = None


@dataclass(frozen=True, slots=True)
class TurnExecutionInspection:
    execution_id: str
    state: str
    recovery_disposition: str
    assistant_ref: ObjectRef | None
    model_attempts: tuple[BackgroundModelAttempt, ...] = ()
    retry_authorized: bool = False
    retry_count: int = 0
    reconciliation_evidence: str | None = None


@dataclass(frozen=True, slots=True)
class PeriodicReviewRunResult:
    request: PeriodicReviewRequest
    runtime: RuntimeTurnResult | None
    context: ModelContextBundle | None
    wake: ReviewWakeReceipt
    budget: BackgroundBudgetDecision | None = None


@dataclass(frozen=True, slots=True)
class WakeDispatchRunResult:
    wake_ref: ObjectRef
    runtime: RuntimeTurnResult | None
    context: ModelContextBundle | None
    step0: Step0GateResult
    wake: WakeStateReceipt
    delivery_response: str | None
    delivery_suppressed: bool
    delivery_observation_ref: ObjectRef | None = None


class FusedTurnRuntime:
    """Minimal vertical slice: world -> recall -> model -> world."""

    def __init__(
        self,
        *,
        store: SQLiteWorldStore,
        index: WorldSearchIndex,
        model_handler: ModelHandler,
        subject_id: str = "user_1",
        context_controller: ContextController | None = None,
        recommendation_limit: int = 5,
        max_tool_rounds: int = 4,
        round_summary_handler: Callable[[RoundSummaryRequest], str] | None = None,
        dimension_summary_handler: Callable[[DimensionSummaryInput], str] | None = None,
        recent_turn_limit: int = 8,
        summary_chunk_turns: int = 12,
        max_round_summaries_per_turn: int = 1,
        attention_scheduling_policy: AttentionSchedulingPolicy | None = None,
        late_return_verifier: LateReturnVerifier | None = None,
        external_return_observer: ExternalReturnObserver | None = None,
    ) -> None:
        if recent_turn_limit < 0:
            raise ValueError("recent_turn_limit must be >= 0")
        if summary_chunk_turns < 1:
            raise ValueError("summary_chunk_turns must be >= 1")
        if max_round_summaries_per_turn < 0:
            raise ValueError("max_round_summaries_per_turn must be >= 0")
        self.store = store
        self.index = index
        self.subject_id = subject_id.strip()
        self.ingestor = ConversationIngestor(store, subject_id=self.subject_id)
        self.turn_executions = TurnExecutionStore(store.db_path)
        self.continuity = ConversationContinuityService(
            store=store,
            index=index,
            subject_id=self.subject_id,
        )
        self.round_summary_handler = round_summary_handler
        self.recent_turn_limit = int(recent_turn_limit)
        self.summary_chunk_turns = int(summary_chunk_turns)
        self.max_round_summaries_per_turn = int(max_round_summaries_per_turn)
        self.attention_scheduling_policy = (
            attention_scheduling_policy or AttentionSchedulingPolicy()
        )
        if late_return_verifier is not None and not isinstance(
            late_return_verifier, LateReturnVerifier
        ):
            raise TypeError("late_return_verifier must be LateReturnVerifier")
        if external_return_observer is not None and late_return_verifier is None:
            raise ValueError(
                "external_return_observer requires a public late_return_verifier"
            )
        self.late_return_verifier = late_return_verifier
        self.external_return_observer = external_return_observer
        self.recommender = ProactiveMemoryRecommender(
            index=index,
            store=store,
            default_limit=recommendation_limit,
        )
        self.topic_state = TopicStateService()
        self.context_controller = context_controller or ContextController()
        self.all_dimensions = AllDimensionsProjectionService(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.evidence_policy = CognitionEvidencePolicy(
            store=store,
            index=index,
            subject_id=self.subject_id,
            allowed_subject_ids=(self.subject_id, AI_SELF_SUBJECT_ID),
        )
        self.writeback = CognitionWritebackService(
            store=store,
            index=index,
            subject_id=subject_id,
            evidence_policy=self.evidence_policy,
        )
        self.ai_world = AIWorldCognitionService(
            store=store,
            index=index,
            user_id=subject_id,
            evidence_policy=self.evidence_policy,
        )
        self.revision = CognitionRevisionService(
            store=store,
            index=index,
            subject_id=subject_id,
            evidence_subject_ids=(self.subject_id, self.ai_world.ai_subject_id),
            evidence_policy=self.evidence_policy,
        )
        self.world_graph = EntityRelationService(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.dimensions = DimensionRegistryService(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.execution_world = GoalTaskActionService(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.events = EventDimensionService(
            store=store,
            index=index,
            subject_id=subject_id,
            propagation_subject_ids=(self.subject_id, self.ai_world.ai_subject_id),
        )
        self.communication_experience = CommunicationExperienceService(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.policies = CognitivePolicyRegistry(
            store=store,
            index=index,
            subject_id=subject_id,
        )
        self.dimension_summary_scheduler = (
            None
            if dimension_summary_handler is None
            else MultiScaleSummaryScheduler(
                store=store,
                index=index,
                summary_handler=dimension_summary_handler,
                subject_id=subject_id,
                source_subject_ids=(self.subject_id, self.ai_world.ai_subject_id),
            )
        )
        self.periodic_review = PeriodicReviewService(
            store=store,
            index=index,
            subject_id=self.subject_id,
        )
        self.wake_bus = WakeBus(
            store=store,
            index=index,
            subject_id=self.subject_id,
        )
        self.cognitive_derivation = CognitiveDerivationScheduler(
            store=store,
            index=index,
            wake_bus=self.wake_bus,
            subject_id=self.subject_id,
            allowed_subject_ids=(self.subject_id, AI_SELF_SUBJECT_ID),
            evidence_policy=self.evidence_policy,
        )
        self.attention_watches = AttentionWatchService(
            store=store,
            index=index,
            execution_world=self.execution_world,
            wake_bus=self.wake_bus,
            subject_id=self.subject_id,
        )
        self.attention_router = AttentionRouter(
            store=store,
            wake_bus=self.wake_bus,
            subject_id=self.subject_id,
        )
        self.background_model_attempts = BackgroundModelAttemptStore(store)
        self.metering = ModelMeteringLedger(store)
        self.background_budget_gate = BackgroundBudgetGate(
            store=store,
            subject_id=self.subject_id,
            metering_ledger=self.metering,
        )
        self.reality_ingest = RealityIngestService(
            store=store,
            index=index,
            subject_id=self.subject_id,
            observation_listener=self.attention_watches.evaluate_observation,
        )
        self._active_turn_time: datetime | None = None
        self._active_meter_time: datetime | None = None
        self._active_session_id: str | None = None
        self._active_wake_id: str | None = None
        self._active_wake_source: WakeSource | None = None
        self._active_review_request: PeriodicReviewRequest | None = None
        self._active_user_turn_execution_id: str | None = None

        registry = CapabilityRegistry()
        registry.register(
            CapabilitySpec(
                name="search_world",
                description="Recall candidate world objects related to a query.",
                kind=CapabilityKind.READ,
                input_schema={"query": "string", "limit": "integer?"},
            ),
            self._search_world,
        )
        registry.register(
            CapabilitySpec(
                name="inspect_world_object",
                description="Read one pinned or latest world object by object id.",
                kind=CapabilityKind.READ,
                input_schema={"object_id": "string", "revision": "integer?"},
            ),
            self._inspect_world_object,
        )
        registry.register(
            CapabilitySpec(
                name="read_periodic_review_anchors",
                description=(
                    "Read a bounded page of the evidence anchors selected for the "
                    "currently active periodic review. Available only during review."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "offset": "integer?",
                    "limit": "integer?",
                },
            ),
            self._read_periodic_review_anchors,
        )
        registry.register(
            CapabilitySpec(
                name="list_conversation_summaries",
                description=(
                    "List same-session continuity summary windows on demand. Use this "
                    "when token budgeting omitted summary content from the cockpit."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "session_id": "string?",
                    "limit": "integer?",
                },
            ),
            self._list_conversation_summaries,
        )
        registry.register(
            CapabilitySpec(
                name="search_conversation_summaries",
                description=(
                    "Search same-session round-summary indexes by topic/text, then "
                    "drill down to exact pinned raw dialogue when precision is needed."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "query": "string",
                    "session_id": "string?",
                    "limit": "integer?",
                },
            ),
            self._search_conversation_summaries,
        )
        registry.register(
            CapabilitySpec(
                name="drill_down_conversation",
                description=(
                    "Read exact pinned raw dialogue behind a same-session round summary, "
                    "or an explicit turn range. Round summaries are indexes, not truth."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "summary_id": "string?",
                    "revision": "integer?",
                    "session_id": "string?",
                    "turn_start": "integer?",
                    "turn_end": "integer?",
                },
            ),
            self._drill_down_conversation,
        )
        registry.register(
            CapabilitySpec(
                name="read_ai_world",
                description=(
                    "Read current evidence-grounded AI cognition across user understanding, "
                    "relationship, self, intent, strategy, boundary, personality and calibration. "
                    "Displays valid_time, unknown_items, and counter_evidence_summary."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "domains": "array[string]?",
                    "scope_key": "string?",
                    "limit": "integer?",
                },
            ),
            self._read_ai_world,
        )
        registry.register(
            CapabilitySpec(
                name="list_dimensions",
                description=(
                    "List current registered dimension definitions so the resident AI "
                    "can check whether an existing observation axis already serves the need."
                ),
                kind=CapabilityKind.READ,
                input_schema={"include_terminal": "boolean?"},
            ),
            self._list_dimensions,
        )
        registry.register(
            CapabilitySpec(
                name="read_world_map",
                description=(
                    "Refresh the compact L0 world-map directory. Returns dimension identity, "
                    "mechanical activity/count metadata and expansion capability names only; "
                    "it does not return dimension payloads or semantic conclusions."
                ),
                kind=CapabilityKind.READ,
                input_schema={},
            ),
            self._read_world_map,
        )
        registry.register(
            CapabilitySpec(
                name="list_attention_watches",
                description=(
                    "List Resident-authored active attention watches. Watches contain only "
                    "mechanical future-match predicates; the Resident interprets meaning after Wake."
                ),
                kind=CapabilityKind.READ,
                input_schema={},
            ),
            self._list_attention_watches,
        )
        registry.register(
            CapabilitySpec(
                name="read_background_budget",
                description=(
                    "Read the current mechanical BACKGROUND_DAY budget and durable usage. "
                    "This reports policy caps, Wake/model-call usage and remaining capacity only; "
                    "it does not decide which future fact is important."
                ),
                kind=CapabilityKind.READ,
                input_schema={},
            ),
            self._read_background_budget,
        )
        registry.register(
            CapabilitySpec(
                name="create_attention_watch",
                description=(
                    "Register future attention as a constrained mechanical Observation watch. "
                    "The Resident chooses the routing class: interrupt wakes cognition immediately "
                    "and may allow user delivery after Resident judgment; background waits for short "
                    "mechanical batching, invokes cognition, and is silent to the user by default; "
                    "review_queue does not invoke the Resident immediately and carries matched evidence "
                    "into Periodic Review. Choose the class from the future-attention intent and current "
                    "runtime facts; Core does not infer urgency for you. Do not encode emotion, intent, "
                    "diagnosis, or other semantic conclusions in the mechanical predicate."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "title": "string",
                    "dimensions": "array[string]",
                    "reason_refs": "array[{object_id:string,revision:integer}]",
                    "goal_ref": "{object_id:string,revision:integer}?",
                    "source_kind": "string?",
                    "modality": "string?",
                    "metadata_equals": "object?",
                    "numeric": "{operator:gt|gte|lt|lte|eq|ne,threshold:number,path:array[string]?}?",
                    "priority": "integer?",
                    "cooldown_seconds": "integer?",
                    "attention_class": "interrupt|background|review_queue?",
                    "mode": "recurring|one_shot?",
                    "expires_at": "ISO-8601 datetime?",
                },
            ),
            self._create_attention_watch,
        )
        registry.register(
            CapabilitySpec(
                name="read_execution_world",
                description=(
                    "Read current Goals, Tasks and proposed/executed Actions from the "
                    "unified world. This is a read-only planning view."
                ),
                kind=CapabilityKind.READ,
                input_schema={},
            ),
            self._read_execution_world,
        )
        registry.register(
            CapabilitySpec(
                name="request_all_dimensions_projection",
                description=(
                    "Observe several parallel dimensions in one time window without "
                    "turning co-occurrence into a causal conclusion."
                ),
                kind=CapabilityKind.READ,
                input_schema={
                    "dimensions": "array[string]",
                    "window_start": "ISO-8601 datetime",
                    "window_end": "ISO-8601 datetime",
                    "query": "string?",
                },
            ),
            self._request_all_dimensions_projection,
        )
        registry.register(
            CapabilitySpec(
                name="commit_claim",
                description=(
                    "Persist a revisable AI cognition Claim grounded in pinned world evidence. "
                    "This capability cannot create Observation facts."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "content": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "confidence": "number[0,1]",
                    "dimension": "string",
                    "claim_type": "string?",
                    "knowledge_state": "string?",
                    "valid_time": "TemporalExtent object?",
                    "unknown_items": "array[string]?",
                    "counter_evidence_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._commit_claim,
        )
        registry.register(
            CapabilitySpec(
                name="commit_ai_world_claim",
                description=(
                    "Persist a typed AI-world cognition using the unified "
                    "EvidenceSet + Claim + Dependency path."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "domain": "user_understanding|relationship|self|intent|strategy|cognitive_boundary|personality|calibration",
                    "statement": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "confidence": "number[0,1]",
                    "knowledge_state": "string?",
                    "claim_type": "string?",
                    "scope_key": "string?",
                    "tags": "array[string]?",
                    "valid_time": "TemporalExtent object?",
                    "unknown_items": "array[string]?",
                    "counter_evidence_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._commit_ai_world_claim,
        )
        registry.register(
            CapabilitySpec(
                name="propose_entity",
                description=(
                    "Create a durable Entity anchor from pinned same-world evidence. "
                    "The resident supplies identity meaning; Core enforces explicit entity_key and provenance."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "entity_key": "string",
                    "entity_kind": "string",
                    "canonical_name": "string?",
                    "aliases": "array[string]?",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "identity_claim_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._propose_entity,
        )
        registry.register(
            CapabilitySpec(
                name="revise_entity",
                description=(
                    "Append a new revision of the current Entity identity anchor using pinned evidence."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "entity_ref": "{object_id:string,revision:integer}",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "canonical_name": "string?",
                    "aliases": "array[string]?",
                    "identity_claim_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._revise_entity,
        )
        registry.register(
            CapabilitySpec(
                name="upsert_relation",
                description=(
                    "Create or forward-revise an evidence-grounded Relation between current Entity revisions."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "left_ref": "{object_id:string,revision:integer}",
                    "relation_type": "string",
                    "right_ref": "{object_id:string,revision:integer}",
                    "valid_time": "TemporalExtent object?",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "confidence": "number[0,1]",
                    "reason": "string",
                },
            ),
            self._upsert_relation,
        )

        registry.register(
            CapabilitySpec(
                name="propose_dimension",
                description=(
                    "Submit an evidence-grounded candidate observation axis. "
                    "The system validates structure; the model supplies semantic rationale."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "dimension_key": "string starting dim:",
                    "name": "string",
                    "description": "string",
                    "data_shape": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "why_existing_dimensions_are_insufficient": "string",
                    "continuity_rationale": "string",
                    "user_value_rationale": "string",
                    "maintenance_cost_rationale": "string",
                    "confidence": "number[0,1]",
                    "update_method": "string?",
                    "expected_value": "string?",
                },
            ),
            self._propose_dimension,
        )
        registry.register(
            CapabilitySpec(
                name="transition_dimension",
                description=(
                    "Move the current dimension revision through a legal lifecycle "
                    "transition using pinned evidence and an AI-supplied reason."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "dimension_ref": "{object_id:string,revision:integer}",
                    "new_lifecycle": "candidate|trial|active|low_activity|dormant|merged|split|revised|rejected|reactivated|archived",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "related_dimension_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._transition_dimension,
        )
        registry.register(
            CapabilitySpec(
                name="propose_goal",
                description=(
                    "Create an evidence-grounded Goal proposal in the unified world. "
                    "A proposal does not grant external-action authorization."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "source_type": "user_explicit|user_inferred|ai_self|app|external",
                    "title": "string",
                    "description": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "confidence": "number[0,1]",
                    "success_criteria": "array[string]?",
                },
            ),
            self._propose_goal,
        )
        registry.register(
            CapabilitySpec(
                name="transition_goal",
                description=(
                    "Move the current Goal revision through a legal evidence-backed state transition."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "goal_ref": "{object_id:string,revision:integer}",
                    "new_status": "proposed|active|paused|achieved|abandoned|unknown",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                },
            ),
            self._transition_goal,
        )
        registry.register(
            CapabilitySpec(
                name="create_task",
                description=(
                    "Create a concrete evidence-grounded Task, optionally under a current Goal."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "title": "string",
                    "task_type": "string",
                    "reason_refs": "array[{object_id:string,revision:integer}]",
                    "goal_ref": "{object_id:string,revision:integer}?",
                    "initial_state": "string?",
                    "priority": "integer?",
                    "next_wake_at": "ISO-8601 datetime?",
                    "deadline": "ISO-8601 datetime?",
                    "timezone_name": "string?",
                    "next_step": "string?",
                    "completion_condition": (
                        "object?; use mode=world_evidence|action_outcome|mixed; "
                        "optional result_object_types=array[string]"
                    ),
                },
            ),
            self._create_task,
        )
        registry.register(
            CapabilitySpec(
                name="transition_task",
                description=(
                    "Move the current Task revision through a legal state transition. "
                    "Terminal transitions obey the Task's explicit completion mode: "
                    "WORLD_EVIDENCE uses pinned durable evidence; ACTION_OUTCOME "
                    "requires a real authorized Action-linked Outcome; MIXED requires both."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "task_ref": "{object_id:string,revision:integer}",
                    "new_state": "string",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "execution_refs": "array[{object_id:string,revision:integer}]?",
                    "outcome_refs": "array[{object_id:string,revision:integer}]?",
                    "next_wake_at": "ISO-8601 datetime?",
                    "next_step": "string?",
                },
            ),
            self._transition_task,
        )
        registry.register(
            CapabilitySpec(
                name="propose_action",
                description=(
                    "Create a PROPOSED external Action for a RUNNING Task. "
                    "This capability never executes the side effect and cannot authorize itself."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "task_ref": "{object_id:string,revision:integer}",
                    "action_type": "string",
                    "payload": "object",
                    "expected_outcome": "string?",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                },
            ),
            self._propose_action,
        )
        registry.register(
            CapabilitySpec(
                name="commit_operation_experience",
                description=(
                    "During an active periodic review, persist a model-authored "
                    "operation experience grounded in pinned real case refs."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "problem_type": "string",
                    "method_path": "array[string]",
                    "result_summary": "string",
                    "positive_case_refs": "array[{object_id:string,revision:integer}]?",
                    "negative_case_refs": "array[{object_id:string,revision:integer}]?",
                    "applicability": "object?",
                    "cost": "object[number]?",
                    "misses": "array[string]?",
                    "experience_state": "string?",
                },
            ),
            self._commit_operation_experience,
        )
        registry.register(
            CapabilitySpec(
                name="revise_claim",
                description=(
                    "Create a forward-only new revision of the current Claim and mark "
                    "dependent cognition review-required."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "target_ref": "{object_id:string,revision:integer}",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "replacement_content": "string",
                    "confidence": "number[0,1]?",
                    "valid_time": "TemporalExtent object?",
                    "unknown_items": "array[string]?",
                    "counter_evidence_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._revise_claim,
        )
        registry.register(
            CapabilitySpec(
                name="retract_claim",
                description=(
                    "Retract the current Claim using pinned contrary/correcting evidence "
                    "and propagate review-required state to dependents."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "target_ref": "{object_id:string,revision:integer}",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                },
            ),
            self._retract_claim,
        )
        registry.register(
            CapabilitySpec(
                name="focus_entity",
                description="Focus retrieval on one known Entity id without semantic reinterpretation.",
                kind=CapabilityKind.READ,
                input_schema={"entity_id": "string", "query": "string?", "limit": "integer?"},
            ),
            self._focus_entity,
        )
        registry.register(
            CapabilitySpec(
                name="search_timeline",
                description="Search the world inside an explicit time window, optionally bounded by dimension/type/query.",
                kind=CapabilityKind.READ,
                input_schema={
                    "window_start": "ISO-8601 datetime",
                    "window_end": "ISO-8601 datetime",
                    "dimension": "string?",
                    "object_types": "array[string]?",
                    "query": "string?",
                    "limit": "integer?",
                },
            ),
            self._search_timeline,
        )
        registry.register(
            CapabilitySpec(
                name="follow_relation",
                description="Follow one-hop explicit Relation objects connected to a world object.",
                kind=CapabilityKind.READ,
                input_schema={"object_id": "string", "limit": "integer?"},
            ),
            self._follow_relation,
        )
        registry.register(
            CapabilitySpec(
                name="compare_claims",
                description="Inspect multiple pinned Claims side by side with their evidence/status; the model decides meaning.",
                kind=CapabilityKind.READ,
                input_schema={"claim_refs": "array[{object_id:string,revision:integer}]"},
            ),
            self._compare_claims,
        )
        registry.register(
            CapabilitySpec(
                name="retrieve_original_observation",
                description="Retrieve an exact Observation fact by id/revision for evidence drill-down.",
                kind=CapabilityKind.READ,
                input_schema={"object_id": "string", "revision": "integer?"},
            ),
            self._retrieve_original_observation,
        )
        registry.register(
            CapabilitySpec(
                name="expand_recall",
                description="Request a broader bounded world recall after the initial recommendation/search was insufficient.",
                kind=CapabilityKind.READ,
                input_schema={
                    "query": "string",
                    "dimension": "string?",
                    "limit": "integer?",
                },
            ),
            self._expand_recall,
        )
        registry.register(
            CapabilitySpec(
                name="inspect_outcome",
                description="Inspect a pinned real Action Outcome and its Action reference.",
                kind=CapabilityKind.READ,
                input_schema={"outcome_ref": "{object_id:string,revision:integer}"},
            ),
            self._inspect_outcome,
        )
        registry.register(
            CapabilitySpec(
                name="read_cognitive_policies",
                description="Read current versioned R6 policy records from the unified world.",
                kind=CapabilityKind.READ,
                input_schema={"policy_id": "string?"},
            ),
            self._read_cognitive_policies,
        )
        registry.register(
            CapabilitySpec(
                name="propose_cognitive_policy",
                description=(
                    "Register a new evidence-grounded AI-mutable cognitive policy. "
                    "Only real user/world result evidence is accepted; hard boundaries "
                    "cannot be created by the resident AI."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "policy_id": "string",
                    "scope": "string",
                    "default_value": "json value",
                    "current_value": "json value",
                    "allowed_range_or_choices": "json value?",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "evaluation_window": "string",
                },
            ),
            self._propose_cognitive_policy,
        )
        registry.register(
            CapabilitySpec(
                name="form_event",
                description=(
                    "Form a revisable Event candidate from pinned world evidence. "
                    "The model supplies the event meaning; code only validates provenance."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "title": "string",
                    "interpretation": "string",
                    "event_time": "TemporalExtent object",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "participant_refs": "array[{object_id:string,revision:integer}]?",
                    "primary_claim_refs": "array[{object_id:string,revision:integer}]?",
                    "confidence": "number[0,1]",
                    "dimension": "string?",
                },
            ),
            self._form_event,
        )
        registry.register(
            CapabilitySpec(
                name="transition_event",
                description="Forward-revise/resolve/reject/merge/split the current Event using pinned evidence.",
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "event_ref": "{object_id:string,revision:integer}",
                    "new_status": "candidate|active|resolved|revised|rejected|merged|split",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "replacement_title": "string?",
                    "replacement_interpretation": "string?",
                    "confidence": "number[0,1]?",
                    "related_event_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._transition_event,
        )
        registry.register(
            CapabilitySpec(
                name="record_communication_experience",
                description=(
                    "Record what communication style was used and the real user/world reaction. "
                    "This records evidence only and does not choose a future style."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "scenario": "string",
                    "style": "string",
                    "tone": "string?",
                    "user_reaction": "accepted|resisted|ignored|unknown",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "action_ref": "{object_id:string,revision:integer}?",
                    "applicable_conditions": "object?",
                    "counterexample_refs": "array[{object_id:string,revision:integer}]?",
                },
            ),
            self._record_communication_experience,
        )
        registry.register(
            CapabilitySpec(
                name="update_cognitive_policy",
                description=(
                    "Append an evidence-grounded value revision to an already-registered "
                    "AI-mutable cognitive policy. Cannot create or loosen hard boundaries."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "policy_id": "string",
                    "current_value": "json value",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                    "evaluation_window": "string?",
                },
            ),
            self._update_cognitive_policy,
        )
        registry.register(
            CapabilitySpec(
                name="rollback_cognitive_policy",
                description=(
                    "Forward-append a rollback to an earlier policy version using pinned evidence."
                ),
                kind=CapabilityKind.WRITE,
                side_effecting=True,
                input_schema={
                    "policy_id": "string",
                    "target_version": "integer",
                    "reason": "string",
                    "evidence_refs": "array[{object_id:string,revision:integer}]",
                },
            ),
            self._rollback_cognitive_policy,
        )
        self.registry = registry
        self.cognitive_runtime = CognitiveRuntime(
            registry=registry,
            model_handler=model_handler,
            max_tool_rounds=max_tool_rounds,
            side_effect_authorizer=self._authorize_side_effect,
            model_usage_recorder=self._record_model_usage,
            model_attempt_admitter=self._admit_background_model_attempt,
            model_dispatch_recorder=self._mark_background_model_dispatch,
            model_response_recorder=self._record_background_model_response,
            model_failure_recorder=self._record_background_model_failure,
            model_response_recovery=self._recover_exact_model_response,
        )

    def _active_background_attempt_scope(self) -> tuple[str, str] | None:
        if self._active_wake_id is None:
            return None
        return (
            (
                "periodic_review"
                if self._active_review_request is not None
                else "wake"
            ),
            self._active_wake_id,
        )

    def _active_model_attempt_scope(self) -> tuple[str, str] | None:
        background = self._active_background_attempt_scope()
        if background is not None:
            return background
        if self._active_user_turn_execution_id is not None:
            return ("user_turn", self._active_user_turn_execution_id)
        return None

    def _background_model_round_offset(
        self,
        *,
        wake_id: str,
        metadata: Mapping[str, Any],
    ) -> int:
        if not bool(metadata.get("runtime_incomplete")):
            return 0
        raw_next = metadata.get("runtime_incomplete_next_model_round_index")
        if isinstance(raw_next, int) and not isinstance(raw_next, bool) and raw_next >= 1:
            return raw_next

        # Upgrade compatibility for pre-FIX-002 runtime-incomplete Wakes. The old
        # runtime persisted this marker only after a ModelDirective had returned, and
        # C13 metering was already written before requeue. Those durable meter rows
        # prove that the old provider rounds returned; use their count only to choose
        # a fresh post-upgrade round identity. Missing meter evidence fails closed.
        legacy_records = self.metering.list_model_calls(
            subject_id=self.subject_id,
            wake_id=wake_id,
        )
        if not legacy_records:
            raise RuntimeError(
                "legacy runtime-incomplete work lacks durable metering evidence"
            )
        return len(legacy_records)

    def _protect_legacy_running_background_work(
        self,
        *,
        wake: Any,
        work_kind: str,
        wake_reason: str,
        now: datetime,
        model_round_offset: int,
    ) -> None:
        if wake.wake_state.value != "running":
            return
        metadata = wake.metadata
        if bool(metadata.get("runtime_incomplete")):
            return
        existing = self.background_model_attempts.inspect(
            subject_id=self.subject_id,
            work_kind=work_kind,
            work_id=wake.object_id,
            model_round_index=model_round_offset,
        )
        if existing is not None:
            return
        if metadata.get("background_model_attempt_protocol") == "v1":
            # New-code invariant: the Wake/Review became RUNNING before provider
            # admission, and every provider call is preceded by a durable attempt.
            # No attempt row therefore proves dispatch did not start yet.
            return
        adopted = self.background_model_attempts.adopt_legacy_in_doubt(
            subject_id=self.subject_id,
            work_kind=work_kind,
            work_id=wake.object_id,
            wake_reason=wake_reason,
            model_round_index=model_round_offset,
            world_revision=int(self.store.current_world_revision()),
            observed_at=now,
        )
        raise BackgroundModelExecutionInDoubt(adopted)

    def _admit_background_model_attempt(
        self,
        snapshot: RuntimeSnapshot,
    ) -> str | None:
        scope = self._active_model_attempt_scope()
        if scope is None:
            return None
        if self._active_meter_time is None:
            raise RuntimeError("background model attempt is missing execution time")
        work_kind, work_id = scope
        attempt = self.background_model_attempts.admit(
            subject_id=self.subject_id,
            work_kind=work_kind,
            work_id=work_id,
            wake_reason=snapshot.wake_reason,
            model_round_index=snapshot.round_index,
            world_revision=int(self.store.current_world_revision()),
            admitted_at=self._active_meter_time,
        )
        return attempt.attempt_id

    def _outbound_request_fingerprint(
        self,
        snapshot: RuntimeSnapshot,
        *,
        work_kind: str,
        work_id: str,
    ) -> str:
        """Canonical fingerprint of the exact request about to cross the provider boundary."""

        payload = {
            "attempt_id": snapshot.model_attempt_id,
            "capability_catalog": [dict(item) for item in snapshot.capability_catalog],
            "capability_history": [
                {
                    "call_id": item.call_id,
                    "data": item.data,
                    "error_code": item.error_code,
                    "error_message": item.error_message,
                    "name": item.name,
                    "ok": bool(item.ok),
                }
                for item in snapshot.capability_history
            ],
            "cockpit": dict(snapshot.cockpit),
            "remaining_tool_rounds": int(snapshot.remaining_tool_rounds),
            "round_index": int(snapshot.round_index),
            "subject_id": self.subject_id,
            "user_input": snapshot.user_input,
            "wake_reason": snapshot.wake_reason,
            "work_id": work_id,
            "work_kind": work_kind,
        }
        raw = canonical_json_dumps(payload).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def _mark_background_model_dispatch(self, snapshot: RuntimeSnapshot) -> None:
        if snapshot.model_attempt_id is None:
            return
        if self._active_meter_time is None:
            raise RuntimeError("background model dispatch is missing execution time")
        scope = self._active_model_attempt_scope()
        if scope is None:
            raise RuntimeError("background model dispatch is missing work scope")
        work_kind, work_id = scope
        fingerprint = self._outbound_request_fingerprint(
            snapshot, work_kind=work_kind, work_id=work_id
        )
        self.background_model_attempts.mark_dispatching(
            snapshot.model_attempt_id,
            dispatched_at=self._active_meter_time,
            outbound_request_fingerprint=fingerprint,
            late_return_verifier=self.late_return_verifier,
        )
        binding = self.background_model_attempts.outbound_request_binding(
            snapshot.model_attempt_id
        )
        if binding is None:
            raise RuntimeError(
                "originating request binding was not durable before provider dispatch"
            )
        object.__setattr__(snapshot, "_outbound_relay_id", binding.relay_id)
        if self.external_return_observer is not None:
            context = self.background_model_attempts.late_return_signing_context(
                snapshot.model_attempt_id
            )
            if context is None:
                raise RuntimeError(
                    "late-return verifier context was not durable before provider dispatch"
                )
            # Only public request scope leaves Core.  The external side already
            # owns the private key and signs after observing a genuine return.
            self.external_return_observer.accept_return_context(snapshot, context)

    def _record_background_model_response(
        self,
        snapshot: RuntimeSnapshot,
        directive: ModelDirective,
    ) -> None:
        if snapshot.model_attempt_id is None:
            return
        if self._active_meter_time is None:
            raise RuntimeError("background model response is missing execution time")
        self.background_model_attempts.record_response(
            snapshot.model_attempt_id,
            returned_at=self._active_meter_time,
            directive=directive,
        )

    def _record_background_model_failure(
        self,
        snapshot: RuntimeSnapshot,
        error: BaseException,
        definitely_not_submitted: bool,
    ) -> None:
        if snapshot.model_attempt_id is None:
            return
        if self._active_meter_time is None:
            raise RuntimeError("background model failure is missing execution time")
        self.background_model_attempts.mark_failure(
            snapshot.model_attempt_id,
            failed_at=self._active_meter_time,
            definitely_not_submitted=definitely_not_submitted,
            error=error,
        )

    def stage_exact_background_response(
        self,
        *,
        work_kind: str,
        work_id: str,
        model_round_index: int,
        provider: str,
        model: str,
        provider_request_id: str,
        response_fingerprint: str,
        directive_payload: str,
        staged_at: datetime,
        evidence: str,
        authenticity_proof: str | None = None,
    ) -> BackgroundModelResponseStaging:
        """Durably bind one exact externally preserved provider reply to an attempt.

        This is the only Core entry point allowed to carry a provider reply from an
        external durable journal back into a background attempt/round. The exact
        directive, its response fingerprint and the exact provider/model/request_id
        are verified against the durable attempt before anything is staged; missing
        or mismatched identity stays fail-closed.
        """

        attempt = self.background_model_attempts.inspect(
            subject_id=self.subject_id,
            work_kind=work_kind,
            work_id=work_id,
            model_round_index=model_round_index,
        )
        if attempt is None:
            raise KeyError(
                "no durable background model attempt exists for the requested "
                "work identity and round"
            )
        return self.background_model_attempts.stage_exact_response(
            attempt.attempt_id,
            staged_at=staged_at,
            provider=provider,
            model=model,
            provider_request_id=provider_request_id,
            response_fingerprint=response_fingerprint,
            directive_payload=directive_payload,
            authenticity_proof=authenticity_proof,
            evidence=evidence,
        )

    def _pending_exact_response(
        self,
        *,
        work_kind: str,
        work_id: str,
    ) -> tuple[BackgroundModelAttempt, BackgroundModelResponseStaging] | None:
        return self.background_model_attempts.recover_trusted_handoff(
            subject_id=self.subject_id,
            work_kind=work_kind,
            work_id=work_id,
        )

    def _recover_exact_model_response(
        self,
        snapshot: RuntimeSnapshot,
    ) -> RecoveredModelResponse | None:
        """Serve a durable exact provider reply for the current attempt/round.

        The model handler is never invoked for a recovered round. Returned None for
        every other round keeps the ordinary provider path untouched, and any
        unresolved attempt without exact durable bytes keeps failing closed through
        the existing admission guards.
        """

        scope = self._active_model_attempt_scope()
        if scope is None:
            return None
        work_kind, work_id = scope
        pending = self._pending_exact_response(
            work_kind=work_kind,
            work_id=work_id,
        )
        if pending is None:
            return None
        attempt, _staged = pending
        if attempt.model_round_index != snapshot.round_index:
            return None
        directive = self.background_model_attempts.exact_response_directive(
            attempt.attempt_id
        )
        return RecoveredModelResponse(
            attempt_id=attempt.attempt_id,
            directive=directive,
        )

    def _record_model_usage(
        self,
        snapshot: RuntimeSnapshot,
        directive: ModelDirective,
    ) -> None:
        if self._active_meter_time is None:
            raise RuntimeError(
                "FusedTurnRuntime model invocation is missing active metering time"
            )

        wake_reason = snapshot.wake_reason
        if wake_reason == WakeSource.USER_INTERACTION.value:
            execution_class = "user_interaction"
        elif wake_reason == WakeSource.PERIODIC_REVIEW.value:
            execution_class = "periodic_review"
        elif wake_reason == WakeSource.SAFETY.value:
            execution_class = "safety"
        elif self._active_wake_id is not None:
            execution_class = "background"
        else:
            execution_class = "other"

        self.metering.record_model_call(
            subject_id=self.subject_id,
            world_revision=int(self.store.current_world_revision()),
            recorded_at=self._active_meter_time,
            execution_class=execution_class,
            wake_id=self._active_wake_id,
            session_id=self._active_session_id,
            wake_reason=wake_reason,
            model_round_index=snapshot.round_index,
            usage=directive.usage,
            provenance=directive.provenance,
            # Every durable model-attempt round is metered against its exact attempt
            # identity, including user turns. This keeps one uniform reason truth for
            # "provider response returned, round applied" and makes metering replay
            # idempotent per attempt/round instead of inventing a new record.
            background_attempt_id=snapshot.model_attempt_id,
        )

    def _cockpit_capability_catalog(self) -> tuple[dict[str, Any], ...]:
        """Compact capability awareness for context budgeting.

        CognitiveRuntime already supplies the full schemas/descriptions separately in
        RuntimeSnapshot.capability_catalog. Repeating the full tool schema inside the
        cockpit wastes context budget and can evict memory/continuity. The cockpit only
        needs enough information to tell the model which named abilities exist.
        """

        return tuple(
            {
                "name": item["name"],
                "kind": item["kind"],
                "side_effecting": bool(item.get("side_effecting", False)),
            }
            for item in self.registry.catalog()
        )

    def _search_world(self, query: str, limit: int = 8) -> list[dict[str, Any]]:
        page = self.index.recall_candidates(
            str(query),
            subject=self.subject_id,
            as_of=self._active_turn_time,
            limit=max(1, min(int(limit), 50)),
        )
        return [
            {
                "object_id": hit.object_id,
                "revision": hit.revision,
                "object_type": hit.object_type,
                "dimension": hit.dimension,
                "excerpt": hit.excerpt,
                "retrieval_score": hit.score,
            }
            for hit in page.hits
        ]

    def _cutoff_store(
        self,
        cutoff: datetime | None = None,
    ) -> SQLiteWorldStore | _KnowledgeCutoffStoreView:
        effective = self._active_turn_time if cutoff is None else cutoff
        if effective is None:
            return self.store
        return _KnowledgeCutoffStoreView(self.store, effective)

    def _ai_world_reader(
        self,
        cutoff: datetime | None = None,
    ) -> AIWorldCognitionService:
        effective = self._active_turn_time if cutoff is None else cutoff
        if effective is None:
            return self.ai_world
        return AIWorldCognitionService(
            store=self._cutoff_store(effective),
            index=self.index,
            user_id=self.subject_id,
            ai_subject_id=self.ai_world.ai_subject_id,
            evidence_policy=self.evidence_policy,
        )

    def _continuity_reader(
        self,
        cutoff: datetime | None = None,
    ) -> ConversationContinuityService:
        return ConversationContinuityService(
            store=self._cutoff_store(cutoff),
            index=self.index,
            subject_id=self.subject_id,
        )

    def _policy_reader(
        self,
        cutoff: datetime | None = None,
    ) -> CognitivePolicyRegistry:
        effective = self._active_turn_time if cutoff is None else cutoff
        if effective is None:
            return self.policies
        return CognitivePolicyRegistry(
            store=self._cutoff_store(effective),
            index=self.index,
            subject_id=self.subject_id,
        )

    def _derive_c14_lineage_at_cutoff(
        self,
        summary_ref: ObjectRef,
        cutoff: datetime,
    ):
        """Resolve model-visible C14 lineage from World as known at cutoff.

        Reusing the existing cutoff Store view constrains both support Dependency
        enumeration (list_payloads) and pinned leaf traversal (get_payload) without
        introducing a second graph or lineage truth store.
        """

        evidence_reader = CognitionEvidencePolicy(
            store=self._cutoff_store(cutoff),
            index=self.index,
            subject_id=self.subject_id,
            allowed_subject_ids=(self.subject_id, AI_SELF_SUBJECT_ID),
        )
        return evidence_reader.derive_lineage_for_refs((summary_ref,))

    def _runtime_subject_scope(self) -> frozenset[str]:
        """Subjects that belong to this resident private user/AI world."""

        return frozenset({self.subject_id, self.ai_world.ai_subject_id})

    def _enforce_active_read_cutoff(
        self,
        payload: Mapping[str, Any],
    ) -> None:
        """Fail closed when a model-visible exact read crosses execution knowledge time."""

        cutoff = self._active_turn_time
        if cutoff is None:
            return
        raw_learned_at = payload.get("learned_at")
        if not isinstance(raw_learned_at, str) or not raw_learned_at.strip():
            raise ValueError(
                "world object unavailable at active runtime read cutoff: "
                "missing learned_at"
            )
        try:
            learned_at = as_utc(
                datetime.fromisoformat(raw_learned_at),
                "learned_at",
            )
            active_cutoff = as_utc(cutoff, "active_runtime_read_cutoff")
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "world object unavailable at active runtime read cutoff: "
                "invalid learned_at"
            ) from exc
        if learned_at > active_cutoff:
            raise ValueError(
                "world object unavailable at active runtime read cutoff: "
                f"learned_at {learned_at.isoformat()} is after "
                f"{active_cutoff.isoformat()}"
            )

    def _scoped_payload(
        self,
        object_id: str,
        revision: int | None = None,
    ) -> dict[str, Any]:
        payload = self._cutoff_store().get_payload(
            str(object_id),
            revision=revision,
        )
        payload_subject = str(payload.get("subject_id") or "")
        if payload_subject not in self._runtime_subject_scope():
            raise ValueError(
                "world object crosses the runtime private-world subject scope: "
                f"{payload_subject!r}"
            )
        self._enforce_active_read_cutoff(payload)
        return payload

    def _inspect_world_object(
        self,
        object_id: str,
        revision: int | None = None,
    ) -> dict[str, Any]:
        return self._scoped_payload(str(object_id), revision=revision)

    def _read_periodic_review_anchors(
        self,
        offset: int = 0,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        request = self._active_review_request
        if request is None:
            raise RuntimeError(
                "read_periodic_review_anchors is only available during periodic review"
            )
        start = max(0, int(offset))
        take = max(1, min(int(limit), 50))
        return [
            anchor.model_dump(mode="json")
            for anchor in request.anchors[start : start + take]
        ]

    def _list_conversation_summaries(
        self,
        session_id: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        active_session = (
            str(session_id).strip()
            if session_id is not None and str(session_id).strip()
            else self._active_session_id
        )
        if active_session is None:
            raise ValueError(
                "session_id is required outside an active turn"
            )
        bounded = max(1, min(int(limit), 200))
        summaries = self._continuity_reader().round_summaries(
            session_id=active_session,
        )
        return [dict(item) for item in summaries[-bounded:]]

    def _search_conversation_summaries(
        self,
        query: str,
        session_id: str | None = None,
        limit: int = 8,
    ) -> list[dict[str, Any]]:
        active_session = (
            str(session_id).strip()
            if session_id is not None and str(session_id).strip()
            else self._active_session_id
        )
        if active_session is None:
            raise ValueError(
                "session_id is required outside an active turn"
            )
        return [
            dict(item)
            for item in self._continuity_reader().search_round_summaries(
                session_id=active_session,
                query=str(query),
                limit=max(1, min(int(limit), 20)),
                as_of=self._active_turn_time,
            )
        ]

    def _drill_down_conversation(
        self,
        summary_id: str | None = None,
        revision: int | None = None,
        session_id: str | None = None,
        turn_start: int | None = None,
        turn_end: int | None = None,
    ) -> list[dict[str, Any]]:
        if summary_id is not None:
            return [
                dict(item)
                for item in self._continuity_reader().drill_down_summary(
                    str(summary_id),
                    revision=(None if revision is None else int(revision)),
                )
            ]

        active_session = (
            str(session_id).strip()
            if session_id is not None and str(session_id).strip()
            else self._active_session_id
        )
        if active_session is None:
            raise ValueError(
                "session_id is required outside an active turn when summary_id is absent"
            )
        if turn_start is None or turn_end is None:
            raise ValueError(
                "turn_start and turn_end are required when summary_id is absent"
            )
        return [
            dict(item)
            for item in self._continuity_reader().drill_down_range(
                session_id=active_session,
                turn_start=int(turn_start),
                turn_end=int(turn_end),
            )
        ]

    def _read_ai_world(
        self,
        domains: Sequence[str] | None = None,
        scope_key: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        parsed = (
            None
            if domains is None
            else [AIWorldDomain(str(domain)) for domain in domains]
        )
        return [
            item.model_dump(mode="json")
            for item in self._ai_world_reader().current(
                domains=parsed,
                scope_key=scope_key,
                limit=max(1, min(int(limit), 200)),
            )
        ]

    def _ai_world_core_context(
        self,
        as_of: datetime,
        *,
        per_domain: int = 3,
    ) -> dict[str, list[dict[str, Any]]]:
        return self._ai_world_reader(as_of).core_context(per_domain=per_domain)

    def _ai_world_snapshot(
        self,
        as_of: datetime,
        *,
        per_domain: int = 3,
    ) -> dict[str, list[dict[str, Any]]]:
        return self._ai_world_reader(as_of).snapshot(per_domain=per_domain)

    def _world_map_context(self, as_of: datetime) -> dict[str, Any]:
        """Build the always-visible L0 world directory without injecting payload semantics."""

        directory = self.index.dimension_directory(
            subject=self.subject_id,
            as_of=as_of,
            include_inactive=False,
            limit=24,
        )
        rows_by_key = {
            str(item["dimension"]): dict(item)
            for item in directory["dimensions"]
        }

        terminal_lifecycles = {"merged", "split", "rejected", "archived"}
        for definition in self.store.list_payloads(
            object_type=ObjectType.DIMENSION_DEFINITION,
            subject_id=self.subject_id,
            knowledge_cutoff=as_of,
        ):
            metadata = definition.get("metadata")
            if not isinstance(metadata, Mapping):
                metadata = {}
            key = str(metadata.get("dimension_key") or "").strip()
            lifecycle = str(definition.get("lifecycle") or "")
            if not key or lifecycle in terminal_lifecycles:
                continue
            row = rows_by_key.setdefault(
                key,
                {
                    "dimension": key,
                    "current_object_count": 0,
                    "recent_24h_count": 0,
                    "recent_7d_count": 0,
                    "latest_activity_at": None,
                    "object_types": [],
                },
            )
            row.update(
                {
                    "registered": True,
                    "name": definition.get("name"),
                    "lifecycle": lifecycle,
                    "definition_ref": {
                        "object_id": str(definition["object_id"]),
                        "revision": int(definition.get("revision", 1)),
                    },
                }
            )

        dimensions: list[dict[str, Any]] = []
        for key, row in rows_by_key.items():
            normalized = dict(row)
            normalized.setdefault("registered", False)
            normalized.setdefault("name", None)
            normalized.setdefault("lifecycle", None)
            normalized.setdefault("definition_ref", None)
            normalized["object_types"] = list(normalized.get("object_types") or [])[:8]
            dimensions.append(normalized)

        dimensions.sort(
            key=lambda item: (
                -int(item.get("recent_24h_count") or 0),
                -int(item.get("recent_7d_count") or 0),
                str(item.get("dimension") or ""),
            )
        )

        return {
            "schema": "aios.world-map.l0.v1",
            "directory_only": True,
            "semantic_conclusions": False,
            "world_revision": int(directory["world_revision"]),
            "index_watermark": int(directory["index_watermark"]),
            "index_lag": int(directory["lag"]),
            "as_of": directory["as_of"],
            "dimension_count": len(dimensions),
            "dimensions": dimensions,
            "truncated": bool(directory["truncated"]),
            "expand_capabilities": {
                "multi_dimension_window": "request_all_dimensions_projection",
                "single_dimension_timeline": "search_timeline",
                "semantic_recall": "search_world",
                "broader_recall": "expand_recall",
                "exact_object": "inspect_world_object",
                "dimension_definitions": "list_dimensions",
                "refresh_directory": "read_world_map",
            },
        }

    def _read_world_map(self) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("read_world_map is only available during an active AIOS turn")
        return self._world_map_context(self._active_turn_time)

    def _list_attention_watches(self) -> list[dict[str, Any]]:
        watches: list[dict[str, Any]] = []
        for payload in self._cutoff_store().list_payloads(
            object_type=ObjectType.TASK,
            subject_id=self.subject_id,
        ):
            if str(payload.get("task_type") or "") != "observation":
                continue
            if str(payload.get("task_state") or "") != "waiting_evidence":
                continue
            condition = payload.get("completion_condition")
            if not isinstance(condition, Mapping):
                continue
            if condition.get("kind") != AttentionWatchService.CONDITION_KIND:
                continue
            watches.append(payload)
        watches.sort(
            key=lambda item: (
                -int(item.get("priority") or 0),
                str(item.get("object_id") or ""),
            )
        )
        return watches

    def _read_background_budget(self) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "read_background_budget is only available during an active AIOS turn"
            )
        return self.background_budget_gate.status(now=self._active_turn_time)

    def _create_attention_watch(
        self,
        title: str,
        dimensions: Sequence[str],
        reason_refs: Sequence[Mapping[str, Any]],
        goal_ref: Mapping[str, Any] | None = None,
        source_kind: str | None = None,
        modality: str | None = None,
        metadata_equals: Mapping[str, Any] | None = None,
        numeric: Mapping[str, Any] | None = None,
        priority: int = 50,
        cooldown_seconds: int = 0,
        attention_class: str = "background",
        mode: str = "recurring",
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "create_attention_watch is only available during an active AIOS turn"
            )
        parsed_goal = (
            None
            if goal_ref is None
            else ObjectRef(
                object_id=str(goal_ref["object_id"]),
                revision=int(goal_ref["revision"]),
            )
        )
        parsed_numeric = (
            None
            if numeric is None
            else NumericPredicate.model_validate(dict(numeric))
        )
        receipt = self.attention_watches.create(
            AttentionWatchRequest(
                title=str(title),
                dimensions=tuple(str(item) for item in dimensions),
                reason_refs=self._coerce_refs(reason_refs),
                goal_ref=parsed_goal,
                source_kind=source_kind,
                modality=modality,
                metadata_equals=dict(metadata_equals or {}),
                numeric=parsed_numeric,
                priority=int(priority),
                cooldown_seconds=int(cooldown_seconds),
                attention_class=AttentionClass(str(attention_class)),
                mode=str(mode),
                expires_at=(
                    None
                    if expires_at is None
                    else datetime.fromisoformat(
                        str(expires_at).replace("Z", "+00:00")
                    )
                ),
            ),
            created_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _list_dimensions(
        self,
        include_terminal: bool = False,
    ) -> list[dict[str, Any]]:
        terminal_lifecycles = {"merged", "split", "rejected", "archived"}
        return [
            payload
            for payload in self._cutoff_store().list_payloads(
                object_type=ObjectType.DIMENSION_DEFINITION,
                subject_id=self.subject_id,
            )
            if bool(include_terminal)
            or str(payload.get("lifecycle") or "") not in terminal_lifecycles
        ]

    def _read_execution_world(self) -> dict[str, Any]:
        reader = self._cutoff_store()
        return {
            "goals": reader.list_payloads(
                object_type=ObjectType.GOAL,
                subject_id=self.subject_id,
            ),
            "tasks": reader.list_payloads(
                object_type=ObjectType.TASK,
                subject_id=self.subject_id,
            ),
            "actions": reader.list_payloads(
                object_type=ObjectType.ACTION,
                subject_id=self.subject_id,
            ),
        }

    @staticmethod
    def _optional_datetime(value: str | None) -> datetime | None:
        if value is None:
            return None
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))

    def _propose_goal(
        self,
        source_type: str,
        title: str,
        description: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        confidence: float,
        success_criteria: Sequence[str] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("propose_goal is only available during an active AIOS turn")
        receipt = self.execution_world.create_goal(
            GoalCreateRequest(
                source_type=source_type,
                title=title,
                description=description,
                evidence_refs=self._coerce_refs(evidence_refs),
                confidence=float(confidence),
                success_criteria=tuple(success_criteria),
            ),
            created_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _transition_goal(
        self,
        goal_ref: Mapping[str, Any],
        new_status: str,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("transition_goal is only available during an active AIOS turn")
        receipt = self.execution_world.transition_goal(
            GoalTransitionRequest(
                goal_ref=ObjectRef(
                    object_id=str(goal_ref["object_id"]),
                    revision=int(goal_ref["revision"]),
                ),
                new_status=new_status,
                reason=reason,
                evidence_refs=self._coerce_refs(evidence_refs),
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _create_task(
        self,
        title: str,
        task_type: str,
        reason_refs: Sequence[Mapping[str, Any]],
        goal_ref: Mapping[str, Any] | None = None,
        initial_state: str = "draft",
        priority: int = 50,
        next_wake_at: str | None = None,
        deadline: str | None = None,
        timezone_name: str | None = None,
        next_step: str | None = None,
        completion_condition: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("create_task is only available during an active AIOS turn")
        parsed_goal = (
            None
            if goal_ref is None
            else ObjectRef(
                object_id=str(goal_ref["object_id"]),
                revision=int(goal_ref["revision"]),
            )
        )
        receipt = self.execution_world.create_task(
            TaskCreateRequest(
                title=title,
                task_type=task_type,
                reason_refs=self._coerce_refs(reason_refs),
                goal_ref=parsed_goal,
                initial_state=initial_state,
                priority=int(priority),
                next_wake_at=self._optional_datetime(next_wake_at),
                deadline=self._optional_datetime(deadline),
                timezone_name=timezone_name,
                next_step=next_step,
                completion_condition=dict(completion_condition or {}),
            ),
            created_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _transition_task(
        self,
        task_ref: Mapping[str, Any],
        new_state: str,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        execution_refs: Sequence[Mapping[str, Any]] = (),
        outcome_refs: Sequence[Mapping[str, Any]] = (),
        next_wake_at: str | None = None,
        next_step: str | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("transition_task is only available during an active AIOS turn")
        receipt = self.execution_world.transition_task(
            TaskTransitionRequest(
                task_ref=ObjectRef(
                    object_id=str(task_ref["object_id"]),
                    revision=int(task_ref["revision"]),
                ),
                new_state=new_state,
                reason=reason,
                evidence_refs=self._coerce_refs(evidence_refs),
                execution_refs=self._coerce_refs(execution_refs),
                outcome_refs=self._coerce_refs(outcome_refs),
                next_wake_at=self._optional_datetime(next_wake_at),
                next_step=next_step,
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _propose_action(
        self,
        task_ref: Mapping[str, Any],
        action_type: str,
        payload: Mapping[str, Any],
        evidence_refs: Sequence[Mapping[str, Any]],
        expected_outcome: str | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("propose_action is only available during an active AIOS turn")
        receipt = self.execution_world.propose_action(
            ActionProposalRequest(
                task_ref=ObjectRef(
                    object_id=str(task_ref["object_id"]),
                    revision=int(task_ref["revision"]),
                ),
                action_type=action_type,
                payload=dict(payload),
                expected_outcome=expected_outcome,
                evidence_refs=self._coerce_refs(evidence_refs),
            ),
            proposed_at=self._active_turn_time,
        )
        return asdict(receipt)


    def _propose_entity(
        self,
        entity_key: str,
        entity_kind: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        canonical_name: str | None = None,
        aliases: Sequence[str] = (),
        identity_claim_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("propose_entity is only available during an active AIOS turn")
        receipt = self.world_graph.propose_entity(
            EntityProposalRequest(
                entity_key=str(entity_key),
                entity_kind=str(entity_kind),
                canonical_name=canonical_name,
                aliases=tuple(str(item) for item in aliases),
                evidence_refs=self._coerce_refs(evidence_refs),
                identity_claim_refs=self._coerce_refs(identity_claim_refs),
            ),
            proposed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _revise_entity(
        self,
        entity_ref: Mapping[str, Any],
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        canonical_name: str | None = None,
        aliases: Sequence[str] | None = None,
        identity_claim_refs: Sequence[Mapping[str, Any]] | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("revise_entity is only available during an active AIOS turn")
        receipt = self.world_graph.revise_entity(
            EntityRevisionRequest(
                entity_ref=ObjectRef(
                    object_id=str(entity_ref["object_id"]),
                    revision=int(entity_ref["revision"]),
                ),
                reason=str(reason),
                evidence_refs=self._coerce_refs(evidence_refs),
                canonical_name=canonical_name,
                aliases=(
                    None
                    if aliases is None
                    else tuple(str(item) for item in aliases)
                ),
                identity_claim_refs=(
                    None
                    if identity_claim_refs is None
                    else self._coerce_refs(identity_claim_refs)
                ),
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _upsert_relation(
        self,
        left_ref: Mapping[str, Any],
        relation_type: str,
        right_ref: Mapping[str, Any],
        evidence_refs: Sequence[Mapping[str, Any]],
        confidence: float,
        reason: str,
        valid_time: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("upsert_relation is only available during an active AIOS turn")
        receipt = self.world_graph.upsert_relation(
            RelationUpsertRequest(
                left_ref=ObjectRef(
                    object_id=str(left_ref["object_id"]),
                    revision=int(left_ref["revision"]),
                ),
                relation_type=str(relation_type),
                right_ref=ObjectRef(
                    object_id=str(right_ref["object_id"]),
                    revision=int(right_ref["revision"]),
                ),
                valid_time=(
                    TemporalExtent.unknown_time()
                    if valid_time is None
                    else TemporalExtent.model_validate(valid_time)
                ),
                evidence_refs=self._coerce_refs(evidence_refs),
                confidence=float(confidence),
                reason=str(reason),
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _propose_dimension(
        self,
        dimension_key: str,
        name: str,
        description: str,
        data_shape: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        why_existing_dimensions_are_insufficient: str,
        continuity_rationale: str,
        user_value_rationale: str,
        maintenance_cost_rationale: str,
        confidence: float,
        update_method: str | None = None,
        expected_value: str | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("propose_dimension is only available during an active AIOS turn")
        receipt = self.dimensions.propose(
            DimensionProposalRequest(
                dimension_key=dimension_key,
                name=name,
                description=description,
                data_shape=data_shape,
                evidence_refs=self._coerce_refs(evidence_refs),
                why_existing_dimensions_are_insufficient=why_existing_dimensions_are_insufficient,
                continuity_rationale=continuity_rationale,
                user_value_rationale=user_value_rationale,
                maintenance_cost_rationale=maintenance_cost_rationale,
                confidence=float(confidence),
                update_method=update_method,
                expected_value=expected_value,
            ),
            proposed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _transition_dimension(
        self,
        dimension_ref: Mapping[str, Any],
        new_lifecycle: str,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        related_dimension_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "transition_dimension is only available during an active AIOS turn"
            )
        receipt = self.dimensions.transition(
            DimensionTransitionRequest(
                dimension_ref=ObjectRef(
                    object_id=str(dimension_ref["object_id"]),
                    revision=int(dimension_ref["revision"]),
                ),
                new_lifecycle=new_lifecycle,
                reason=reason,
                evidence_refs=self._coerce_refs(evidence_refs),
                related_dimension_refs=self._coerce_refs(related_dimension_refs),
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)


    def _request_all_dimensions_projection(
        self,
        dimensions: Sequence[str],
        window_start: str,
        window_end: str,
        query: str | None = None,
    ) -> dict[str, Any]:
        start = datetime.fromisoformat(str(window_start).replace("Z", "+00:00"))
        end = datetime.fromisoformat(str(window_end).replace("Z", "+00:00"))
        projection_reader = AllDimensionsProjectionService(
            store=self._cutoff_store(),
            index=self.index,
            subject_id=self.subject_id,
            max_items_per_dimension=self.all_dimensions.max_items_per_dimension,
        )
        projection = projection_reader.project(
            dimensions=dimensions,
            window_start=start,
            window_end=end,
            query=query,
            as_of=self._active_turn_time,
        )
        return projection.model_dump(mode="json")

    @staticmethod
    def _search_hit_payload(hit) -> dict[str, Any]:
        return {
            "object_id": hit.object_id,
            "revision": hit.revision,
            "object_type": hit.object_type,
            "dimension": hit.dimension,
            "excerpt": hit.excerpt,
            "retrieval_score": hit.score,
        }

    def _focus_entity(
        self,
        entity_id: str,
        query: str | None = None,
        limit: int = 12,
    ) -> list[dict[str, Any]]:
        page = self.index.search_by_entity(
            str(entity_id),
            keywords=(() if query is None or not str(query).strip() else (str(query),)),
            subject=self.subject_id,
            as_of=self._active_turn_time,
            limit=max(1, min(int(limit), 50)),
        )
        return [self._search_hit_payload(hit) for hit in page.hits]

    def _search_timeline(
        self,
        window_start: str,
        window_end: str,
        dimension: str | None = None,
        object_types: Sequence[str] | None = None,
        query: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        start = datetime.fromisoformat(str(window_start).replace("Z", "+00:00"))
        end = datetime.fromisoformat(str(window_end).replace("Z", "+00:00"))
        page = self.index.search_mind(
            keywords=(() if query is None or not str(query).strip() else (str(query),)),
            subject=self.subject_id,
            dimension=(None if dimension is None else str(dimension)),
            object_types=(None if object_types is None else tuple(str(x) for x in object_types)),
            time_range=(start, end),
            as_of=self._active_turn_time,
            limit=max(1, min(int(limit), 100)),
        )
        return [self._search_hit_payload(hit) for hit in page.hits]

    def _follow_relation(
        self,
        object_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        target = str(object_id)
        matched: list[dict[str, Any]] = []
        for payload in self._cutoff_store().list_payloads(
            object_type=ObjectType.RELATION,
            subject_id=self.subject_id,
        ):
            left = payload.get("left") or {}
            right = payload.get("right") or {}
            if str(left.get("object_id") or "") != target and str(right.get("object_id") or "") != target:
                continue
            matched.append(payload)
            if len(matched) >= max(1, min(int(limit), 100)):
                break
        return matched

    def _compare_claims(
        self,
        claim_refs: Sequence[Mapping[str, Any]],
    ) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for ref in self._coerce_refs(claim_refs):
            payload = self._scoped_payload(
                ref.object_id,
                revision=ref.revision,
            )
            if payload.get("object_type") != ObjectType.CLAIM.value:
                raise ValueError("compare_claims accepts only Claim references")
            result.append(
                {
                    "claim": payload,
                    "support_evidence_sets": [
                        self._scoped_payload(
                            str(item["object_id"]),
                            revision=int(item["revision"]),
                        )
                        for item in payload.get("support_evidence_set_refs") or []
                    ],
                    "counter_evidence_sets": [
                        self._scoped_payload(
                            str(item["object_id"]),
                            revision=int(item["revision"]),
                        )
                        for item in payload.get("counter_evidence_set_refs") or []
                    ],
                }
            )
        return result

    def _retrieve_original_observation(
        self,
        object_id: str,
        revision: int | None = None,
    ) -> dict[str, Any]:
        payload = self._scoped_payload(str(object_id), revision=revision)
        if payload.get("object_type") != ObjectType.OBSERVATION.value:
            raise ValueError("requested object is not an Observation")
        return payload

    def _expand_recall(
        self,
        query: str,
        dimension: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        page = self.index.recall_candidates(
            str(query),
            subject=self.subject_id,
            dimension=(None if dimension is None else str(dimension)),
            as_of=self._active_turn_time,
            limit=max(1, min(int(limit), 100)),
        )
        return [self._search_hit_payload(hit) for hit in page.hits]

    def _inspect_outcome(
        self,
        outcome_ref: Mapping[str, Any],
    ) -> dict[str, Any]:
        ref = ObjectRef(
            object_id=str(outcome_ref["object_id"]),
            revision=int(outcome_ref["revision"]),
        )
        payload = self._scoped_payload(
            ref.object_id,
            revision=ref.revision,
        )
        if payload.get("object_type") != ObjectType.OUTCOME.value:
            raise ValueError("outcome_ref must point to an Outcome")
        action_ref = payload.get("action_ref") or {}
        action = self._scoped_payload(
            str(action_ref["object_id"]),
            revision=int(action_ref["revision"]),
        )
        return {"outcome": payload, "action": action}

    def _read_cognitive_policies(
        self,
        policy_id: str | None = None,
    ) -> list[dict[str, Any]]:
        reader = self._policy_reader()
        if policy_id is not None and str(policy_id).strip():
            item = reader.latest(str(policy_id))
            return [] if item is None else [item.model_dump(mode="json")]
        return [
            item.model_dump(mode="json")
            for item in reader.list_current()
        ]

    def _propose_cognitive_policy(
        self,
        policy_id: str,
        scope: str,
        default_value: Any,
        current_value: Any,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        evaluation_window: str,
        allowed_range_or_choices: Any = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "propose_cognitive_policy is only available during an active AIOS turn"
            )
        receipt = self.policies.register(
            CognitivePolicyCreateRequest(
                policy_id=str(policy_id),
                scope=str(scope),
                policy_class=PolicyClass.COGNITIVE_POLICY,
                default_value=default_value,
                current_value=current_value,
                allowed_range_or_choices=allowed_range_or_choices,
                mutable_by_ai=True,
                reason=str(reason),
                evidence_refs=self._coerce_refs(evidence_refs),
                changed_by="resident_ai",
                evaluation_window=str(evaluation_window),
            ),
            changed_at=self._active_turn_time,
            actor_is_ai=True,
        )
        return asdict(receipt)


    def _form_event(
        self,
        title: str,
        interpretation: str,
        event_time: Mapping[str, Any],
        evidence_refs: Sequence[Mapping[str, Any]],
        confidence: float,
        participant_refs: Sequence[Mapping[str, Any]] = (),
        primary_claim_refs: Sequence[Mapping[str, Any]] = (),
        dimension: str = "dim:events",
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("form_event is only available during an active AIOS turn")
        receipt = self.events.form_event(
            EventWriteRequest(
                title=title,
                interpretation=interpretation,
                event_time=dict(event_time),
                evidence_refs=self._coerce_refs(evidence_refs),
                participant_refs=self._coerce_refs(participant_refs),
                primary_claim_refs=self._coerce_refs(primary_claim_refs),
                confidence=float(confidence),
                dimension=dimension,
            ),
            learned_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _transition_event(
        self,
        event_ref: Mapping[str, Any],
        new_status: str,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        replacement_title: str | None = None,
        replacement_interpretation: str | None = None,
        confidence: float | None = None,
        related_event_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("transition_event is only available during an active AIOS turn")
        receipt = self.events.transition(
            EventTransitionRequest(
                event_ref=ObjectRef(
                    object_id=str(event_ref["object_id"]),
                    revision=int(event_ref["revision"]),
                ),
                new_status=new_status,
                reason=reason,
                evidence_refs=self._coerce_refs(evidence_refs),
                replacement_title=replacement_title,
                replacement_interpretation=replacement_interpretation,
                confidence=confidence,
                related_event_refs=self._coerce_refs(related_event_refs),
            ),
            changed_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _record_communication_experience(
        self,
        scenario: str,
        style: str,
        user_reaction: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        tone: str | None = None,
        action_ref: Mapping[str, Any] | None = None,
        applicable_conditions: Mapping[str, Any] | None = None,
        counterexample_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "record_communication_experience is only available during an active AIOS turn"
            )
        parsed_action = (
            None
            if action_ref is None
            else ObjectRef(
                object_id=str(action_ref["object_id"]),
                revision=int(action_ref["revision"]),
            )
        )
        receipt = self.communication_experience.record(
            CommunicationExperienceRequest(
                scenario=scenario,
                style=style,
                tone=tone,
                user_reaction=user_reaction,
                evidence_refs=self._coerce_refs(evidence_refs),
                action_ref=parsed_action,
                applicable_conditions=dict(applicable_conditions or {}),
                counterexample_refs=self._coerce_refs(counterexample_refs),
            ),
            recorded_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _update_cognitive_policy(
        self,
        policy_id: str,
        current_value: Any,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        evaluation_window: str | None = None,
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "update_cognitive_policy is only available during an active AIOS turn"
            )
        receipt = self.policies.update(
            CognitivePolicyUpdateRequest(
                policy_id=policy_id,
                current_value=current_value,
                reason=reason,
                evidence_refs=self._coerce_refs(evidence_refs),
                changed_by="resident_ai",
                evaluation_window=evaluation_window,
            ),
            changed_at=self._active_turn_time,
            actor_is_ai=True,
        )
        return asdict(receipt)

    def _rollback_cognitive_policy(
        self,
        policy_id: str,
        target_version: int,
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "rollback_cognitive_policy is only available during an active AIOS turn"
            )
        receipt = self.policies.rollback(
            policy_id,
            int(target_version),
            reason=reason,
            evidence_refs=self._coerce_refs(evidence_refs),
            changed_by="resident_ai",
            changed_at=self._active_turn_time,
            actor_is_ai=True,
        )
        return asdict(receipt)

    def _cognitive_policy_context(
        self,
        *,
        limit: int = 32,
        as_of: datetime | None = None,
    ) -> dict[str, Any]:
        """Compact current policy view for every resident semantic entry point.

        Policies learned from direct evidence must become available to later cognition
        without requiring the model to guess a policy id first. Scope/class metadata is
        kept beside the convenience value map so a local policy is not silently treated
        as global. The full ledger remains available through read_cognitive_policies when
        this bounded context is truncated.
        """

        if limit < 1:
            raise ValueError("policy context limit must be >= 1")
        reader = self._policy_reader(as_of)
        items = [
            item
            for item in reader.list_current()
            if reader.is_effective(item)
        ]
        values: dict[str, Any] = {}
        records: list[dict[str, Any]] = []
        for item in items[:limit]:
            values[item.policy_id] = item.current_value
            records.append(
                {
                    "policy_id": item.policy_id,
                    "scope": item.scope,
                    "policy_class": item.policy_class.value,
                    "default_value": item.default_value,
                    "current_value": item.current_value,
                    "allowed_range_or_choices": item.allowed_range_or_choices,
                    "mutable_by_ai": item.mutable_by_ai,
                    "evaluation_window": item.evaluation_window,
                    "version": item.revision,
                    "previous_version": item.previous_version,
                    "rollback_pointer": item.rollback_pointer,
                }
            )
        values["_policy_records"] = records
        values["_meta"] = {
            "total": len(items),
            "included": min(len(items), limit),
            "truncated": len(items) > limit,
            "reader": "read_cognitive_policies",
        }
        return values

    def _execution_context_for_topic(
        self,
        topic: str | None,
        *,
        limit: int = 6,
        as_of: datetime | None = None,
    ) -> dict[str, Any]:
        clean = "" if topic is None else str(topic).strip()
        if not clean:
            return {"related_execution_anchors": []}
        page = self.index.recall_candidates(
            clean,
            subject=self.subject_id,
            object_types=(
                ObjectType.GOAL.value,
                ObjectType.TASK.value,
                ObjectType.ACTION.value,
                ObjectType.OUTCOME.value,
            ),
            as_of=as_of,
            limit=max(1, min(int(limit), 20)),
        )
        return {
            "related_execution_anchors": [
                self._search_hit_payload(hit)
                for hit in page.hits
            ]
        }

    def _authorize_side_effect(self, spec, call, snapshot) -> bool:
        # Reads never need side-effect authorization. CognitiveRuntime calls this
        # authorizer only for side-effecting specs, but keeping the boundary explicit
        # makes the C14 rule safe to inspect/test directly as the catalog evolves.
        if not spec.side_effecting:
            return True

        # C14 is a bounded background cognition-derivation wake. It may persist only
        # cognition create/revise/retract operations; every other present or future
        # side-effecting capability is denied by default. The four allowed handlers
        # still pass through _validate_cognition_evidence().
        if snapshot.wake_reason == WakeSource.COGNITIVE_DERIVATION.value:
            return spec.name in _C14_COGNITIVE_SIDE_EFFECT_ALLOWLIST

        # Preserve existing authorization semantics for user turns, Periodic Review,
        # and other Wake sources.
        return spec.name in {
            "commit_claim",
            "commit_ai_world_claim",
            "propose_entity",
            "revise_entity",
            "upsert_relation",
            "propose_dimension",
            "transition_dimension",
            "propose_goal",
            "transition_goal",
            "create_task",
            "transition_task",
            "create_attention_watch",
            "propose_action",
            "commit_operation_experience",
            "revise_claim",
            "retract_claim",
            "form_event",
            "transition_event",
            "record_communication_experience",
            "propose_cognitive_policy",
            "update_cognitive_policy",
            "rollback_cognitive_policy",
        }

    def _commit_operation_experience(
        self,
        problem_type: str,
        method_path: Sequence[str],
        result_summary: str,
        positive_case_refs: Sequence[Mapping[str, Any]] = (),
        negative_case_refs: Sequence[Mapping[str, Any]] = (),
        applicability: Mapping[str, Any] | None = None,
        cost: Mapping[str, float] | None = None,
        misses: Sequence[str] = (),
        experience_state: str = "candidate",
    ) -> dict[str, Any]:
        if self._active_turn_time is None or self._active_review_request is None:
            raise RuntimeError(
                "commit_operation_experience is only available during active periodic review"
            )
        receipt = self.periodic_review.commit_operation_experience(
            OperationExperienceRequest(
                problem_type=problem_type,
                method_path=tuple(method_path),
                result_summary=result_summary,
                positive_case_refs=self._coerce_refs(positive_case_refs),
                negative_case_refs=self._coerce_refs(negative_case_refs),
                applicability=dict(applicability or {}),
                cost=dict(cost or {}),
                misses=tuple(misses),
                experience_state=experience_state,
            ),
            learned_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _validate_cognition_evidence(
        self,
        refs: Sequence[ObjectRef],
        *,
        operation: str,
    ) -> None:
        """Enforce unified evidence support closure across all wake sources.

        Ordinary user turns, Periodic Review, and Cognitive Derivation all pass
        the same mechanical resolver in CognitionEvidencePolicy. No Claim prose,
        keywords, occurrence counts, confidence score or expected answer participates.
        Every durable Claim create/revise/retract route requires leaf-grounded reality support.
        """
        self.evidence_policy.validate(refs, operation=operation)

    def _commit_ai_world_claim(
        self,
        domain: str,
        statement: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        confidence: float,
        knowledge_state: str = "inferred",
        claim_type: str = "inference",
        scope_key: str | None = None,
        tags: Sequence[str] = (),
        valid_time: Mapping[str, Any] | None = None,
        unknown_items: Sequence[str] = (),
        counter_evidence_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError(
                "commit_ai_world_claim is only available during an active AIOS turn"
            )
        refs = self._coerce_refs(evidence_refs)
        self._validate_cognition_evidence(
            refs,
            operation="commit_ai_world_claim",
        )
        counter_refs = self._coerce_refs(counter_evidence_refs)
        if counter_refs:
            self._validate_cognition_evidence(
                counter_refs,
                operation="commit_ai_world_claim:counter_evidence",
            )
        parsed_valid_time = (
            TemporalExtent.unknown_time()
            if valid_time is None
            else TemporalExtent.model_validate(valid_time)
        )
        receipt = self.ai_world.commit(
            AIWorldClaimRequest(
                domain=AIWorldDomain(domain),
                statement=statement,
                evidence_refs=refs,
                confidence=float(confidence),
                knowledge_state=knowledge_state,
                claim_type=claim_type,
                scope_key=scope_key,
                tags=tuple(tags),
                valid_time=parsed_valid_time,
                unknown_items=tuple(unknown_items),
                counter_evidence_refs=counter_refs,
            ),
            learned_at=self._active_turn_time,
        )
        return {
            "domain": receipt.domain.value,
            "dimension": receipt.dimension,
            "subject_id": receipt.subject_id,
            "claim": asdict(receipt.claim),
        }

    def _commit_claim(
        self,
        content: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        confidence: float,
        dimension: str,
        claim_type: str = "inference",
        knowledge_state: str = "inferred",
        valid_time: Mapping[str, Any] | None = None,
        unknown_items: Sequence[str] = (),
        counter_evidence_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("commit_claim is only available during an active AIOS turn")
        refs = self._coerce_refs(evidence_refs)
        self._validate_cognition_evidence(
            refs,
            operation="commit_claim",
        )
        counter_refs = self._coerce_refs(counter_evidence_refs)
        if counter_refs:
            self._validate_cognition_evidence(
                counter_refs,
                operation="commit_claim:counter_evidence",
            )
        parsed_valid_time = (
            TemporalExtent.unknown_time()
            if valid_time is None
            else TemporalExtent.model_validate(valid_time)
        )
        receipt = self.writeback.commit_claim(
            ClaimWriteRequest(
                content=content,
                evidence_refs=refs,
                confidence=float(confidence),
                dimension=dimension,
                claim_type=claim_type,
                knowledge_state=knowledge_state,
                valid_time=parsed_valid_time,
                unknown_items=tuple(unknown_items),
                counter_evidence_refs=counter_refs,
            ),
            learned_at=self._active_turn_time,
        )
        return asdict(receipt)

    def _coerce_refs(
        self,
        refs: Sequence[Mapping[str, Any]],
    ) -> tuple[ObjectRef, ...]:
        return tuple(
            ObjectRef(
                object_id=str(item["object_id"]),
                revision=int(item["revision"]),
            )
            for item in refs
        )

    def _revise_claim(
        self,
        target_ref: Mapping[str, Any],
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
        replacement_content: str,
        confidence: float | None = None,
        valid_time: Mapping[str, Any] | None = None,
        unknown_items: Sequence[str] | None = None,
        counter_evidence_refs: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("revise_claim is only available during an active AIOS turn")
        refs = self._coerce_refs(evidence_refs)
        self._validate_cognition_evidence(
            refs,
            operation="revise_claim",
        )
        counter_refs = self._coerce_refs(counter_evidence_refs)
        if counter_refs:
            self._validate_cognition_evidence(
                counter_refs,
                operation="revise_claim:counter_evidence",
            )
        target = ObjectRef(
            object_id=str(target_ref["object_id"]),
            revision=int(target_ref["revision"]),
        )
        payload = self.store.get_payload(
            target.object_id,
            revision=target.revision,
        )
        metadata = payload.get("metadata")
        is_ai_world_target = isinstance(metadata, dict) and (
            metadata.get("ai_world") is True or "ai_domain" in metadata
        )
        parsed_valid_time = (
            None
            if valid_time is None
            else TemporalExtent.model_validate(valid_time)
        )
        parsed_unknown_items = (
            None
            if unknown_items is None
            else tuple(unknown_items)
        )
        if is_ai_world_target:
            receipt = self.ai_world.revise(
                target_ref=target,
                evidence_refs=refs,
                replacement_statement=replacement_content,
                reason=reason,
                changed_at=self._active_turn_time,
                confidence=confidence,
                valid_time=parsed_valid_time,
                unknown_items=parsed_unknown_items,
                counter_evidence_refs=counter_refs,
            )
        else:
            receipt = self.revision.apply(
                ClaimRevisionRequest(
                    target_ref=target,
                    mode="revise",
                    reason=reason,
                    evidence_refs=refs,
                    replacement_content=replacement_content,
                    confidence=confidence,
                    valid_time=parsed_valid_time,
                    unknown_items=parsed_unknown_items,
                    counter_evidence_refs=counter_refs,
                ),
                changed_at=self._active_turn_time,
            )
        return asdict(receipt)

    def _retract_claim(
        self,
        target_ref: Mapping[str, Any],
        reason: str,
        evidence_refs: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        if self._active_turn_time is None:
            raise RuntimeError("retract_claim is only available during an active AIOS turn")
        refs = self._coerce_refs(evidence_refs)
        self._validate_cognition_evidence(
            refs,
            operation="retract_claim",
        )
        target = ObjectRef(
            object_id=str(target_ref["object_id"]),
            revision=int(target_ref["revision"]),
        )
        payload = self.store.get_payload(
            target.object_id,
            revision=target.revision,
        )
        metadata = payload.get("metadata")
        is_ai_world_target = isinstance(metadata, dict) and (
            metadata.get("ai_world") is True or "ai_domain" in metadata
        )
        if is_ai_world_target:
            receipt = self.ai_world.retract(
                target_ref=target,
                evidence_refs=refs,
                reason=reason,
                changed_at=self._active_turn_time,
            )
        else:
            receipt = self.revision.apply(
                ClaimRevisionRequest(
                    target_ref=target,
                    mode="retract",
                    reason=reason,
                    evidence_refs=refs,
                ),
                changed_at=self._active_turn_time,
            )
        return asdict(receipt)

    def run_due_dimension_summaries(
        self,
        *,
        now: datetime,
        scales: Sequence[str | SummaryScale] = tuple(SummaryScale),
        max_jobs: int = 64,
        dimensions: Sequence[str] | None = None,
    ) -> SummaryScheduleResult:
        """Run deterministic summary scheduling with model-generated content.

        This is maintenance, not resident cognition. The scheduler chooses only
        dimensions/windows/sources; the injected dimension_summary_handler writes the
        descriptive text and cannot alter raw facts.
        """

        if self.dimension_summary_scheduler is None:
            raise RuntimeError(
                "dimension_summary_handler is required for semantic dimension summaries"
            )
        parsed = tuple(SummaryScale(item) for item in scales)
        return self.dimension_summary_scheduler.run_due(
            now=now,
            scales=parsed,
            max_jobs=max_jobs,
            dimensions=dimensions,
        )

    def _structured_topic_history_signal(
        self,
        user_input: str,
    ) -> tuple[bool, str | None]:
        """Return mechanical current-world anchor signals without semantic guessing.

        Exact named anchors remain the strongest signal. When the user does not repeat
        an object's full title/name, Core may still open the history gate if the
        current utterance has at least two lexical-token overlaps with a *current*
        durable world anchor. This is candidate retrieval only: it decides whether
        historical context may help; it does not decide what the evidence means.

        Conversation Observations are deliberately excluded from this fallback so a
        long chat history cannot silently reopen proactive recall. Non-conversation
        Observations (calendar/sensor/platform/etc.) may act as factual world anchors.
        """

        current = " ".join(str(user_input).strip().split()).casefold()
        if not current:
            return False, None

        def mentioned(value: object) -> bool:
            text = " ".join(str(value or "").strip().split())
            # Single-character labels are too ambiguous for proactive injection.
            return len(text) >= 2 and text.casefold() in current

        for entity in self.world_graph.current_entities():
            labels = [entity.canonical_name, *entity.aliases]
            if any(mentioned(label) for label in labels if label):
                return True, "explicit_entity_anchor"

        for payload in self.store.list_payloads(
            object_type=ObjectType.EVENT,
            subject_id=self.subject_id,
        ):
            if mentioned(payload.get("title")):
                return True, "explicit_event_anchor"

        for goal in self.execution_world.current_goals():
            if mentioned(goal.title):
                return True, "explicit_goal_anchor"

        for task in self.execution_world.current_tasks():
            if mentioned(task.title):
                return True, "explicit_task_anchor"

        # P16 habitation exposed a false negative where a planning question depended
        # on a revised current Claim but did not repeat the later schedule/event title.
        # Use the same public lexical index as recommendation, restricted to current
        # visible structured anchors. A score >= 2 means at least two independent
        # index tokens overlap; Core still does not infer relevance or causality.
        structured_types = (
            ObjectType.CLAIM.value,
            ObjectType.EVENT.value,
            ObjectType.GOAL.value,
            ObjectType.TASK.value,
            ObjectType.ENTITY.value,
            ObjectType.RELATION.value,
        )
        structured_page = self.index.recall_candidates(
            current,
            subject=self.subject_id,
            object_types=structured_types,
            limit=8,
        )
        if any(hit.score >= 2 for hit in structured_page.hits):
            return True, "indexed_current_world_anchor"

        # External factual observations may also carry current state (for example a
        # calendar entry). Old conversation turns are intentionally not eligible here;
        # those remain available through explicit history cues or model deep search.
        observation_page = self.index.recall_candidates(
            current,
            subject=self.subject_id,
            object_types=(ObjectType.OBSERVATION.value,),
            limit=16,
        )
        for hit in observation_page.hits:
            if hit.score < 2:
                continue
            payload = self.store.get_payload(hit.object_id, revision=hit.revision)
            source_kind = str(payload.get("source_kind") or "").strip().casefold()
            metadata = payload.get("metadata")
            if not isinstance(metadata, Mapping):
                metadata = {}
            dimension = str(metadata.get("dimension") or "").strip()
            # ConversationIngestor uses source_kind="user_ai_interaction"; the
            # canonical interaction dimension is the stronger guard because it
            # survives compatible ingestors that choose a different source label.
            if (
                source_kind in {"conversation", "user_ai_interaction"}
                or dimension == INTERACTION_DIMENSION
            ):
                continue
            return True, "indexed_external_observation_anchor"

        return False, None

    def _turn_recovery_identity(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
    ) -> tuple[str, str, str]:
        session = session_id.strip()
        if not session:
            raise ValueError("session_id must not be blank")
        if type(turn_index) is not int or turn_index < 1:
            raise ValueError("turn_index must be a positive integer")
        if not isinstance(user_input, str):
            raise ValueError("user_input must be text")
        occurred_iso = canonical_utc_iso(occurred_at, "occurred_at")
        _, _, assistant_id = self.ingestor._turn_identity(session, turn_index)
        return session, occurred_iso, assistant_id

    def inspect_turn_execution(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
    ) -> TurnExecutionInspection:
        session, occurred_iso, assistant_id = self._turn_recovery_identity(
            session_id=session_id,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )
        status = self.turn_executions.inspect(
            subject_id=self.subject_id,
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_iso,
            assistant_id=assistant_id,
        )
        attempts = self.background_model_attempts.list_for_work(
            subject_id=self.subject_id,
            work_kind="user_turn",
            work_id=status.execution_id,
        )
        return TurnExecutionInspection(
            execution_id=status.execution_id,
            state=status.state,
            recovery_disposition=status.recovery_disposition,
            assistant_ref=status.assistant_ref,
            model_attempts=attempts,
            retry_authorized=status.retry_authorized,
            retry_count=status.retry_count,
            reconciliation_evidence=status.reconciliation_evidence,
        )

    def authorize_turn_retry(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
        evidence: str,
    ) -> TurnExecutionInspection:
        session, occurred_iso, assistant_id = self._turn_recovery_identity(
            session_id=session_id,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )
        self.turn_executions.authorize_retry(
            subject_id=self.subject_id,
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_iso,
            assistant_id=assistant_id,
            evidence=evidence,
        )
        return self.inspect_turn_execution(
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )

    def reconcile_turn_model_not_submitted(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
        model_round_index: int,
        reconciled_at: datetime,
        evidence: str,
    ) -> TurnExecutionInspection:
        inspected = self.inspect_turn_execution(
            session_id=session_id,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )
        attempt = self.background_model_attempts.inspect(
            subject_id=self.subject_id,
            work_kind="user_turn",
            work_id=inspected.execution_id,
            model_round_index=model_round_index,
        )
        if attempt is None:
            raise KeyError(
                "user-turn model attempt does not exist for the requested round"
            )
        self.background_model_attempts.reconcile_not_submitted(
            attempt.attempt_id,
            reconciled_at=reconciled_at,
            evidence=evidence,
        )
        return self.inspect_turn_execution(
            session_id=session_id,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )

    def recover_turn_completion(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
        evidence: str,
    ) -> TurnExecutionInspection:
        session, occurred_iso, assistant_id = self._turn_recovery_identity(
            session_id=session_id,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )
        self.turn_executions.reconcile_completed(
            subject_id=self.subject_id,
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_iso,
            assistant_id=assistant_id,
            evidence=evidence,
        )
        return self.inspect_turn_execution(
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_at,
        )

    def run_turn(
        self,
        *,
        session_id: str,
        turn_index: int,
        user_input: str,
        occurred_at: datetime,
        current_topic: str | None | object = _AUTO_TOPIC,
        recent_turns: Sequence[Mapping[str, Any]] = (),
        ai_identity: Mapping[str, Any] | None = None,
        task_context: Mapping[str, Any] | None = None,
        token_budget: int | None = None,
    ) -> FusedTurnResult:
        session = session_id.strip()
        if not session:
            raise ValueError("session_id must not be blank")
        if recent_turns:
            raise ValueError(
                "P14 derives recent_turns from WorldStore; callers must not inject "
                "an externally maintained conversation history"
            )

        if type(turn_index) is not int or turn_index < 1:
            raise ValueError("turn_index must be a positive integer")
        if not isinstance(user_input, str):
            raise ValueError("user_input must be text")
        occurred_iso = canonical_utc_iso(occurred_at, "occurred_at")
        _, _, assistant_id = self.ingestor._turn_identity(session, turn_index)
        execution_id = self.turn_executions.execution_id_for(
            subject_id=self.subject_id,
            session_id=session,
            turn_index=turn_index,
        )
        # A durable assistant output is the terminal application receipt. Finish
        # the existing claim's mechanical ACK before considering any handoff:
        # never stage or reapply a metered directive after output was committed.
        status = self.turn_executions.inspect(
            subject_id=self.subject_id, session_id=session, turn_index=turn_index,
            user_input=user_input, occurred_at=occurred_iso, assistant_id=assistant_id,
        )
        if status.assistant_ref is not None or status.state == "completed":
            self.turn_executions.claim(
                subject_id=self.subject_id, session_id=session, turn_index=turn_index,
                user_input=user_input, occurred_at=occurred_iso, assistant_id=assistant_id,
            )
        exact_response = self._pending_exact_response(
            work_kind="user_turn",
            work_id=execution_id,
        )
        model_round_offset = 0
        if exact_response is None:
            self.turn_executions.claim(
                subject_id=self.subject_id, session_id=session, turn_index=turn_index,
                user_input=user_input, occurred_at=occurred_iso, assistant_id=assistant_id,
            )
            # Establish the same durable provider-attempt boundary used by FIX-002
            # before any user-turn pre-model work. If execution stops before
            # mark_dispatching(), the admitted state is durable proof that provider
            # submission did not begin; retry still requires explicit authorization.
            self.background_model_attempts.admit(
                subject_id=self.subject_id,
                work_kind="user_turn",
                work_id=execution_id,
                wake_reason=WakeSource.USER_INTERACTION.value,
                model_round_index=0,
                world_revision=int(self.store.current_world_revision()),
                admitted_at=occurred_at,
            )
        else:
            # Durable exact provider bytes exist for this turn's attempt/round, so the
            # ordinary entrypoint may resume that same attempt without any provider
            # call. This is mechanically authorized by the exact-response journal, not
            # by an operator semantic decision, and it never authorizes a retry.
            model_round_offset = exact_response[0].model_round_index
            self.turn_executions.authorize_exact_response_recovery(
                subject_id=self.subject_id,
                session_id=session,
                turn_index=turn_index,
                user_input=user_input,
                occurred_at=occurred_iso,
                assistant_id=assistant_id,
                evidence=(
                    "exact provider response durably staged for attempt "
                    f"{exact_response[0].attempt_id} round "
                    f"{exact_response[0].model_round_index} with fingerprint "
                    f"{exact_response[1].response_fingerprint}"
                ),
            )
        # Corrective-001: only after deterministic round-0 attempt admission is
        # durable do we promote the turn out of the explicit pre-attempt protocol.
        # A crash before this line is therefore mechanically recoverable; a crash
        # after it delegates disposition to the shared attempt ledger.
        self.turn_executions.mark_initial_attempt_admitted(
            subject_id=self.subject_id,
            session_id=session,
            turn_index=turn_index,
            user_input=user_input,
            occurred_at=occurred_iso,
            assistant_id=assistant_id,
        )

        self.attention_watches.expire_due(now=occurred_at)

        # The current user utterance enters the world before model inference. The
        # continuity view deliberately excludes this incomplete current turn and
        # rebuilds prior dialogue from canonical observations.
        user_commit = self.ingestor.commit_user_input(
            session_id=session,
            turn_index=turn_index,
            user_text=user_input,
            occurred_at=occurred_at,
        )
        self.index.catch_up()

        effective_token_budget = (
            self.context_controller.default_token_budget
            if token_budget is None
            else int(token_budget)
        )
        summary_trigger_tokens = max(
            128,
            int(effective_token_budget * 0.65),
        )
        continuity_snapshot = self._continuity_reader(occurred_at).snapshot(
            session_id=session,
            before_turn=turn_index,
            recent_turn_limit=self.recent_turn_limit,
            summary_chunk_turns=self.summary_chunk_turns,
            summary_trigger_tokens=summary_trigger_tokens,
        )

        structured_history_signal, structured_signal_reason = (
            self._structured_topic_history_signal(user_input)
        )

        if current_topic is _AUTO_TOPIC:
            topic_state = self.topic_state.resolve(
                user_input=user_input,
                recent_turns=continuity_snapshot.recent_turns,
                explicit_topic=None,
                structured_history_signal=structured_history_signal,
                structured_signal_reason=structured_signal_reason,
            )
        elif current_topic is None:
            # Compatibility and explicit control: callers that deliberately pass
            # current_topic=None are closing the proactive-memory topic gate for
            # this turn. Callers that omit current_topic get Core-owned topic state.
            topic_state = TopicState(
                topic=None,
                gate_open=False,
                history_may_help=False,
                reason="explicit_no_topic_override",
            )
        else:
            topic_state = self.topic_state.resolve(
                user_input=user_input,
                recent_turns=continuity_snapshot.recent_turns,
                explicit_topic=str(current_topic),
                structured_history_signal=structured_history_signal,
                structured_signal_reason=structured_signal_reason,
            )
        policy_reader = self._policy_reader(occurred_at)
        raw_recommendation_limit = policy_reader.effective_value(
            "memory.recommendation_limit",
            self.recommender.default_limit,
        )
        try:
            effective_recommendation_limit = max(
                1,
                min(int(raw_recommendation_limit), 20),
            )
        except (TypeError, ValueError):
            effective_recommendation_limit = self.recommender.default_limit

        recommendation = ProactiveMemoryRecommender(
            index=self.index,
            store=self._cutoff_store(occurred_at),
            default_limit=self.recommender.default_limit,
        ).recommend(
            current_topic=topic_state.topic,
            subject_id=self.subject_id,
            exclude_session_id=session,
            limit=effective_recommendation_limit,
            history_needed=topic_state.history_may_help,
            antecedent_fallback=topic_state.antecedent_recall_needed,
            as_of=occurred_at,
        )

        continuity_context = (
            dict(ai_identity)
            if ai_identity is not None
            else self._ai_world_core_context(occurred_at, per_domain=3)
        )

        current_task_context = dict(task_context or {})
        current_task_context["topic_state"] = topic_state.model_dump(mode="json")
        current_task_context["cognitive_policy_context"] = (
            self._cognitive_policy_context(as_of=occurred_at)
        )
        current_task_context["cognitive_policy_context"][
            "memory.recommendation_limit"
        ] = effective_recommendation_limit
        current_task_context["cognitive_policy_context"].setdefault(
            "communication.detail_level",
            policy_reader.effective_value(
                "communication.detail_level",
                None,
            ),
        )
        automatic_execution_context = self._execution_context_for_topic(
            topic_state.topic,
            as_of=occurred_at,
        )
        current_task_context.setdefault(
            "related_execution_anchors",
            automatic_execution_context["related_execution_anchors"],
        )
        current_task_context["current_user_observation_ref"] = {
            "object_id": user_commit.observation_id,
            "revision": 1,
        }
        current_task_context["conversation_continuity"] = {
            "session_id": session,
            "recent_turn_count": len(continuity_snapshot.recent_turns),
            "round_summary_count": len(continuity_snapshot.round_summaries),
            "summary_index_capability": "list_conversation_summaries",
            "summary_search_capability": "search_conversation_summaries",
            "raw_drill_down_capability": "drill_down_conversation",
            "pending_round_summary": (
                None
                if continuity_snapshot.pending_summary is None
                else {
                    "turn_start": continuity_snapshot.pending_summary.turn_start,
                    "turn_end": continuity_snapshot.pending_summary.turn_end,
                    "source_count": len(
                        continuity_snapshot.pending_summary.sources
                    ),
                }
            ),
        }

        context = self.context_controller.assemble(
            user_input=user_input,
            current_topic=topic_state.topic,
            recommendation=recommendation,
            recent_turns=continuity_snapshot.recent_turns,
            conversation_summaries=continuity_snapshot.round_summaries,
            ai_identity=continuity_context,
            world_map=self._world_map_context(occurred_at),
            task_context=current_task_context,
            capability_catalog=self._cockpit_capability_catalog(),
            token_budget=token_budget,
        )

        self._active_turn_time = occurred_at
        self._active_meter_time = occurred_at
        self._active_session_id = session
        self._active_wake_id = None
        self._active_user_turn_execution_id = execution_id
        try:
            runtime_result = self.cognitive_runtime.run_turn(
                user_input,
                wake_reason="user_interaction",
                cockpit=context.as_cockpit(),
                model_round_offset=model_round_offset,
            )
        finally:
            self._active_turn_time = None
            self._active_meter_time = None
            self._active_session_id = None
            self._active_wake_id = None
            self._active_user_turn_execution_id = None

        assistant_text = runtime_result.response or ""
        assistant_commit = self.ingestor.commit_assistant_output(
            session_id=session,
            turn_index=turn_index,
            assistant_text=assistant_text,
            occurred_at=occurred_at,
        )
        commit = ConversationCommit(
            world_revision=assistant_commit.world_revision,
            user_observation_id=user_commit.observation_id,
            assistant_observation_id=assistant_commit.observation_id,
            idempotent_replay=(
                user_commit.idempotent_replay
                and assistant_commit.idempotent_replay
            ),
            user_world_revision=user_commit.world_revision,
            assistant_world_revision=assistant_commit.world_revision,
        )
        self.index.catch_up()

        # Summarization is maintenance after the user-visible turn. Deterministic
        # code decides when a closed range needs summarization; an injected real
        # model handler supplies only the descriptive text. Failure never rewrites
        # or deletes raw dialogue, and is surfaced to the caller for audit/repair.
        summary_commits: list[RoundSummaryCommit] = []
        summary_error: str | None = None
        if (
            self.round_summary_handler is not None
            and self.max_round_summaries_per_turn > 0
        ):
            try:
                for _ in range(self.max_round_summaries_per_turn):
                    request = self.continuity.prepare_next_round_summary(
                        session_id=session,
                        before_turn=turn_index + 1,
                        recent_turn_limit=self.recent_turn_limit,
                        summary_chunk_turns=self.summary_chunk_turns,
                        summary_trigger_tokens=summary_trigger_tokens,
                    )
                    if request is None:
                        break
                    content = self.round_summary_handler(request)
                    summary_commits.append(
                        self.continuity.commit_round_summary(
                            request,
                            content=content,
                            generated_at=occurred_at,
                        )
                    )
            except Exception as exc:
                summary_error = f"{type(exc).__name__}: {exc}"

        self.index.catch_up()
        self.turn_executions.complete(
            subject_id=self.subject_id, session_id=session, turn_index=turn_index,
        )
        return FusedTurnResult(
            runtime=runtime_result,
            recommendation=recommendation,
            context=context,
            conversation_commit=commit,
            continuity_summary_commits=tuple(summary_commits),
            continuity_summary_error=summary_error,
        )



    def dispatch_next_pending_wake(
        self,
        *,
        now: datetime,
        step0: Step0GateInput | None = None,
        token_budget: int | None = None,
    ) -> WakeDispatchRunResult | None:
        """Advance mechanical timers and dispatch one eligible Resident Wake.

        This is the runtime-facing attention scheduler entrypoint. It expires stale
        watches, materializes due Task Wakes, then chooses exactly one pending Wake.
        REVIEW_QUEUE and conversation turns are intentionally excluded.
        """

        self.attention_watches.expire_due(now=now)
        self.execution_world.wake_due_tasks(now=now)

        wake = self.attention_router.next_dispatchable(
            now=now,
            background_batch_window_seconds=(
                self.attention_scheduling_policy.background_batch_window_seconds
            ),
        )
        if wake is None:
            return None

        return self.run_wake(
            wake_ref=ObjectRef(
                object_id=wake.object_id,
                revision=wake.revision,
            ),
            now=now,
            step0=step0,
            token_budget=token_budget,
        )


    def run_wake(
        self,
        *,
        wake_ref: ObjectRef | Mapping[str, Any],
        now: datetime,
        step0: Step0GateInput | None = None,
        token_budget: int | None = None,
    ) -> WakeDispatchRunResult:
        """Dispatch one durable non-conversation Wake through the resident runtime.

        This is the constitutional C09 bridge between deterministic Wake creation
        and semantic model judgment. It does not create a synthetic user
        Conversation Observation and it never interprets the trigger in code.
        """

        ref = (
            wake_ref
            if isinstance(wake_ref, ObjectRef)
            else ObjectRef(
                object_id=str(wake_ref["object_id"]),
                revision=int(wake_ref["revision"]),
            )
        )
        if ref.revision is None:
            raise ValueError("wake_ref must pin an exact revision")

        exact_payload = self.store.get_payload(
            ref.object_id,
            revision=ref.revision,
        )
        if exact_payload.get("object_type") != "wake":
            raise ValueError("wake_ref must point to a Wake object")

        initial_wake = self.wake_bus.current_wake(ref.object_id)
        initial_attention_class = self.wake_bus.attention_class_for_wake(
            initial_wake
        )
        bundle_excluded_sources = {
            WakeSource.SAFETY,
            WakeSource.PERIODIC_REVIEW,
            WakeSource.USER_INTERACTION,
            WakeSource.ATTENTION_BUNDLE,
        }
        if (
            initial_wake.wake_state.value in {"new", "queued"}
            and initial_wake.wake_source not in bundle_excluded_sources
            and initial_attention_class is AttentionClass.BACKGROUND
        ):
            bundle = self.attention_router.bundle_pending(
                now=now,
                window_seconds=(
                    self.attention_scheduling_policy.background_batch_window_seconds
                ),
                max_wakes=self.attention_scheduling_policy.background_bundle_max_wakes,
                anchor_wake_id=initial_wake.object_id,
            )
            if (
                bundle is not None
                and initial_wake.object_id in bundle.member_wake_ids
            ):
                ref = ObjectRef(
                    object_id=bundle.wake_id,
                    revision=bundle.revision,
                )

        wake = self.wake_bus.current_wake(ref.object_id)
        if wake.wake_source is WakeSource.PERIODIC_REVIEW:
            raise ValueError(
                "PERIODIC_REVIEW Wake must use run_periodic_review so review anchors remain intact"
            )
        if wake.wake_source is WakeSource.USER_INTERACTION:
            raise ValueError(
                "USER_INTERACTION must use run_turn so the user utterance enters the world"
            )

        # A delivery fact may already exist if the process failed after persisting
        # the user-facing assistant output but before making the Wake terminal.
        # Recover from that durable boundary without invoking the model again.
        persisted_delivery = self.ingestor.assistant_delivery_payload(wake.object_id)
        if persisted_delivery is not None:
            metadata = persisted_delivery.get("metadata")
            if not isinstance(metadata, Mapping):
                raise ValueError("persisted Wake delivery metadata is invalid")
            runtime_metadata = metadata.get("delivery_runtime")
            if not isinstance(runtime_metadata, Mapping):
                raise ValueError("persisted Wake delivery runtime metadata is invalid")
            stored_step0_raw = runtime_metadata.get("step0")
            if not isinstance(stored_step0_raw, Mapping):
                raise ValueError("persisted Wake delivery Step0 metadata is invalid")
            stored_step0 = Step0GateResult.model_validate(stored_step0_raw)
            if not stored_step0.delivery_allowed:
                raise ValueError(
                    "persisted Wake delivery cannot carry a denied Step0 result"
                )
            delivery_text = persisted_delivery.get("value")
            if not isinstance(delivery_text, str):
                raise ValueError("persisted Wake delivery text is invalid")
            raw_capability_names = runtime_metadata.get("capability_names")
            if not isinstance(raw_capability_names, list) or not all(
                isinstance(item, str) for item in raw_capability_names
            ):
                raise ValueError(
                    "persisted Wake delivery capability metadata is invalid"
                )
            termination_reason = runtime_metadata.get("termination_reason")
            model_rounds = runtime_metadata.get("model_rounds")
            if not isinstance(termination_reason, str) or not termination_reason:
                raise ValueError(
                    "persisted Wake delivery termination metadata is invalid"
                )
            if (
                not isinstance(model_rounds, int)
                or isinstance(model_rounds, bool)
                or model_rounds < 0
            ):
                raise ValueError(
                    "persisted Wake delivery model-round metadata is invalid"
                )

            if wake.wake_state.value == "running":
                recovered_wake = self.wake_bus.complete(
                    wake.object_id,
                    completed_at=now,
                    termination_reason=termination_reason,
                    model_rounds=model_rounds,
                    capability_names=tuple(raw_capability_names),
                    delivery_allowed=True,
                    step0_state=stored_step0.state,
                )
            elif wake.wake_state.value == "completed":
                recovered_wake = WakeStateReceipt(
                    wake_id=wake.object_id,
                    revision=wake.revision,
                    state=wake.wake_state.value,
                    world_revision=int(self.store.current_world_revision()),
                )
            else:
                raise ValueError(
                    "persisted Wake delivery requires RUNNING or COMPLETED Wake state"
                )

            delivery_observation_ref = ObjectRef(
                object_id=str(persisted_delivery["object_id"]),
                revision=int(persisted_delivery["revision"]),
            )
            self.index.catch_up()
            return WakeDispatchRunResult(
                wake_ref=ObjectRef(
                    object_id=recovered_wake.wake_id,
                    revision=recovered_wake.revision,
                ),
                runtime=None,
                context=None,
                step0=stored_step0,
                wake=recovered_wake,
                delivery_response=delivery_text,
                delivery_suppressed=False,
                delivery_observation_ref=delivery_observation_ref,
            )

        budget_decision = self.background_budget_gate.evaluate(
            wake,
            now=now,
            max_model_rounds=self.cognitive_runtime.max_tool_rounds + 1,
        )
        effective_step0 = step0 or Step0GateInput()
        if budget_decision.applies:
            effective_step0 = effective_step0.model_copy(
                update={
                    "budget_available": (
                        effective_step0.budget_available
                        and budget_decision.available
                    ),
                    "reasons": tuple(
                        dict.fromkeys(
                            [
                                *effective_step0.reasons,
                                *budget_decision.reasons,
                            ]
                        )
                    ),
                }
            )

        gate_result = self.wake_bus.evaluate_step0(wake, effective_step0)
        if not gate_result.model_allowed:
            if wake.wake_state.value == "running" and not budget_decision.hard_deny:
                terminal = WakeStateReceipt(
                    wake_id=wake.object_id,
                    revision=wake.revision,
                    state=wake.wake_state.value,
                    world_revision=int(self.store.current_world_revision()),
                )
            else:
                terminal = (
                    self.wake_bus.suppress(
                        wake.object_id,
                        suppressed_at=now,
                        step0=gate_result,
                    )
                    if budget_decision.hard_deny
                    else self.wake_bus.defer(
                        wake.object_id,
                        deferred_at=now,
                        step0=gate_result,
                    )
                )
            return WakeDispatchRunResult(
                wake_ref=ObjectRef(
                    object_id=terminal.wake_id,
                    revision=terminal.revision,
                ),
                runtime=None,
                context=None,
                step0=gate_result,
                wake=terminal,
                delivery_response=None,
                delivery_suppressed=True,
            )

        model_round_offset = self._background_model_round_offset(
            wake_id=wake.object_id,
            metadata=wake.metadata,
        )
        exact_response = self._pending_exact_response(
            work_kind="wake",
            work_id=wake.object_id,
        )
        recovered_attempt: BackgroundModelAttempt | None = None
        if exact_response is not None:
            # An externally durable exact reply exists for the round where execution
            # stopped. Resume that exact attempt/round instead of dispatching the
            # provider again; rounds whose provider reply was never durably preserved
            # keep failing closed through the ordinary admission guards.
            recovered_attempt = exact_response[0]
            model_round_offset = max(
                model_round_offset, recovered_attempt.model_round_index
            )
        self._protect_legacy_running_background_work(
            wake=wake,
            work_kind="wake",
            wake_reason=wake.wake_source.value,
            now=now,
            model_round_offset=model_round_offset,
        )
        claim_metadata = budget_decision.reservation_metadata()
        if wake.metadata.get("background_model_attempt_protocol") != "v1":
            claim_metadata = {
                **claim_metadata,
                "background_model_attempt_protocol": "v1",
            }
        claimed = self.wake_bus.claim(
            wake.object_id,
            started_at=now,
            expected_world_revision=(
                budget_decision.world_revision
                if budget_decision.requires_reservation
                else None
            ),
            metadata_update=claim_metadata,
        )
        running = self.wake_bus.current_wake(claimed.wake_id)
        running_ref = ObjectRef(
            object_id=running.object_id,
            revision=running.revision,
        )

        raw_attention_bundle = (
            running.metadata.get("attention_bundle")
            if running.wake_source is WakeSource.ATTENTION_BUNDLE
            else None
        )
        c14_bundle = False
        bundle_member_records: list[tuple[ObjectRef, Mapping[str, Any]]] = []
        if isinstance(raw_attention_bundle, Mapping):
            raw_members = raw_attention_bundle.get("members")
            if not isinstance(raw_members, list) or not raw_members:
                if (
                    raw_attention_bundle.get("execution_contract")
                    == AttentionRouter.C14_EXECUTION_CONTRACT
                ):
                    raise ValueError("C14 AttentionBundle requires pinned member Wakes")
            else:
                member_sources: set[str] = set()
                for raw_member in raw_members:
                    if not isinstance(raw_member, Mapping):
                        raise ValueError("AttentionBundle member must be a mapping")
                    raw_member_ref = raw_member.get("wake_ref")
                    if not isinstance(raw_member_ref, Mapping):
                        raise ValueError("AttentionBundle member requires exact wake_ref")
                    member_ref = ObjectRef.model_validate(raw_member_ref)
                    if member_ref.revision is None:
                        raise ValueError("AttentionBundle member wake_ref must be pinned")
                    member_payload = self.store.get_payload(
                        member_ref.object_id,
                        revision=member_ref.revision,
                    )
                    if member_payload.get("object_type") != ObjectType.WAKE.value:
                        raise ValueError("AttentionBundle member must point to a Wake")
                    member_sources.add(str(member_payload.get("wake_source") or ""))
                    if not any(
                        item.object_id == member_ref.object_id
                        and item.revision == member_ref.revision
                        for item in running.evidence_refs
                    ):
                        raise ValueError("AttentionBundle must pin each exact member Wake")
                    bundle_member_records.append((member_ref, member_payload))
                contains_c14 = (
                    WakeSource.COGNITIVE_DERIVATION.value in member_sources
                )
                declared_contract = raw_attention_bundle.get("execution_contract")
                if contains_c14:
                    if member_sources != {WakeSource.COGNITIVE_DERIVATION.value}:
                        raise ValueError(
                            "COGNITIVE_DERIVATION cannot share a broader AttentionBundle"
                        )
                    if (
                        declared_contract
                        != AttentionRouter.C14_EXECUTION_CONTRACT
                    ):
                        raise ValueError(
                            "C14 AttentionBundle must preserve its execution contract"
                        )
                    if raw_attention_bundle.get("member_count") != len(
                        bundle_member_records
                    ):
                        raise ValueError("C14 AttentionBundle member_count mismatch")
                    c14_bundle = True
                elif (
                    declared_contract
                    == AttentionRouter.C14_EXECUTION_CONTRACT
                ):
                    raise ValueError(
                        "C14 execution contract requires only C14 member Wakes"
                    )

        effective_wake_source = (
            WakeSource.COGNITIVE_DERIVATION
            if (
                running.wake_source is WakeSource.COGNITIVE_DERIVATION
                or c14_bundle
            )
            else running.wake_source
        )

        active_write_time = now
        if recovered_attempt is not None:
            # The recovered round re-applies the exact directive that already ran, so
            # its capability writebacks must keep the original execution write time.
            # Durable object identity for cognition, task and writeback commits is
            # derived from that time; a fresh `now` would create a second side effect
            # instead of replaying the same durable operation idempotently.
            active_write_time = recovered_attempt.admitted_at
        if effective_wake_source is WakeSource.COGNITIVE_DERIVATION:
            raw_first_started_at = (
                running.metadata.get("runtime_first_started_at")
                or running.metadata.get("started_at")
            )
            if raw_first_started_at is not None:
                active_write_time = datetime.fromisoformat(
                    str(raw_first_started_at).replace("Z", "+00:00")
                )

        empty_recommendation = RecommendationBundle(
            current_topic=None,
            topic_gate_open=False,
            world_revision=int(self.store.current_world_revision()),
            index_watermark=self.index.watermark(),
            cards=(),
            reason="wake_dispatch_uses_wake_reason_as_first_pointer",
        )
        continuity_context = self._ai_world_core_context(
            active_write_time,
            per_domain=3,
        )
        wake_context = {
            "wake_ref": running_ref.model_dump(mode="json"),
            "wake_source": running.wake_source.value,
            "effective_wake_source": effective_wake_source.value,
            "rule_id": running.rule_id,
            "priority": running.priority,
            "attention_class": self.wake_bus.attention_class_for_wake(
                running
            ).value,
            "dedupe_key": running.dedupe_key,
            "first_hit_at": running.first_hit_at.isoformat(),
            "last_hit_at": running.last_hit_at.isoformat(),
            "hit_count": running.hit_count,
            "evidence_refs": [
                item.model_dump(mode="json")
                for item in running.evidence_refs
            ],
            "step0": gate_result.model_dump(mode="json"),
            "budget": budget_decision.context_payload(),
            "evidence_reader": "inspect_world_object",
            "attention_bundle": (
                running.metadata.get("attention_bundle")
                if running.wake_source is WakeSource.ATTENTION_BUNDLE
                else None
            ),
        }
        task_context: dict[str, Any] = {
            "wake": wake_context,
            "cognitive_policy_context": self._cognitive_policy_context(
                as_of=active_write_time,
            ),
        }
        wake_input = (
            "System Wake. Start from the supplied Wake Reason and pinned evidence. "
            "Decide what, if anything, it means now. Search or inspect more world "
            "state when needed. You may respond, act through authorized capabilities, "
            "or remain silent. The trigger itself is not a semantic conclusion."
        )

        if running.wake_source is WakeSource.COGNITIVE_DERIVATION:
            raw_summary_ref = running.metadata.get("summary_ref")
            if not isinstance(raw_summary_ref, Mapping):
                raise ValueError(
                    "COGNITIVE_DERIVATION Wake requires exact summary_ref metadata"
                )
            summary_ref = ObjectRef.model_validate(raw_summary_ref)
            if summary_ref.revision is None:
                raise ValueError(
                    "COGNITIVE_DERIVATION summary_ref must pin an exact revision"
                )
            if not any(
                item.object_id == summary_ref.object_id
                and item.revision == summary_ref.revision
                for item in running.evidence_refs
            ):
                raise ValueError(
                    "COGNITIVE_DERIVATION summary_ref must be pinned by the Wake"
                )
            summary_payload = self.store.get_payload(
                summary_ref.object_id,
                revision=summary_ref.revision,
            )
            if summary_payload.get("object_type") != ObjectType.SUMMARY.value:
                raise ValueError(
                    "COGNITIVE_DERIVATION summary_ref must point to a Summary"
                )
            runtime_lineage = self._derive_c14_lineage_at_cutoff(
                summary_ref,
                active_write_time,
            )
            scheduler_lineage = running.metadata.get("derived_lineage")
            if not isinstance(scheduler_lineage, Mapping):
                scheduler_lineage = {}
            summary_metadata = summary_payload.get("metadata")
            if not isinstance(summary_metadata, Mapping):
                summary_metadata = {}
            summary_coverage = summary_payload.get("coverage")
            if not isinstance(summary_coverage, Mapping):
                summary_coverage = {}
            summary_dimension = (
                summary_metadata.get("dimension")
                or summary_coverage.get("dimension")
            )

            task_context["cognitive_derivation"] = {
                "wake_ref": running_ref.model_dump(mode="json"),
                "summary_ref": summary_ref.model_dump(mode="json"),
                "summary_revision": summary_ref.revision,
                "summary_dimension": summary_dimension,
                "granularity": summary_payload.get("granularity"),
                "summary_window": summary_payload.get("summary_time"),
                "scheduler_derived_lineage": dict(scheduler_lineage),
                "runtime_derived_lineage": runtime_lineage.audit_payload(),
                "current_ai_world": self._ai_world_snapshot(
                    active_write_time,
                    per_domain=3,
                ),
                "capability_names": [
                    item["name"] for item in self.registry.catalog()
                ],
                "step0": gate_result.model_dump(mode="json"),
                "budget": budget_decision.context_payload(),
                "summary_is_temporal_navigation_anchor": True,
                "summary_is_semantic_conclusion": False,
                "summary_is_sufficient_evidence_by_itself": False,
                "silence_is_valid_success": True,
            }
            wake_input = (
                "Cognitive derivation wake. The exact pinned Summary is only a "
                "temporal/navigation anchor: it is not a Claim, a semantic conclusion, "
                "or sufficient evidence by itself. Inspect its real leaf evidence, "
                "existing cognition, counter-evidence, and any cross-dimensional world "
                "state you judge relevant. Normal search, inspect, timeline, compare, "
                "recall, ALL_DIMENSIONS and Outcome inspection remain available. Only "
                "form, revise, or retract durable cognition when pinned support closes "
                "to qualifying non-Summary reality/case evidence. If evidence is "
                "insufficient or understanding should not change, silence is a correct "
                "successful result. The Wake contains no expected Claim."
            )
        elif c14_bundle:
            members: list[dict[str, Any]] = []
            for member_ref, member_payload in bundle_member_records:
                member_metadata = member_payload.get("metadata")
                if not isinstance(member_metadata, Mapping):
                    raise ValueError("C14 member Wake requires metadata")
                raw_summary_ref = member_metadata.get("summary_ref")
                if not isinstance(raw_summary_ref, Mapping):
                    raise ValueError(
                        "C14 member Wake requires exact summary_ref metadata"
                    )
                summary_ref = ObjectRef.model_validate(raw_summary_ref)
                if summary_ref.revision is None:
                    raise ValueError("C14 member summary_ref must be pinned")
                raw_member_evidence = member_payload.get("evidence_refs")
                if not isinstance(raw_member_evidence, list):
                    raw_member_evidence = []
                member_evidence = [
                    ObjectRef.model_validate(item)
                    for item in raw_member_evidence
                    if isinstance(item, Mapping)
                ]
                if not any(
                    item.object_id == summary_ref.object_id
                    and item.revision == summary_ref.revision
                    for item in member_evidence
                ):
                    raise ValueError("C14 member Wake must pin its Summary")
                summary_payload = self.store.get_payload(
                    summary_ref.object_id,
                    revision=summary_ref.revision,
                )
                if summary_payload.get("object_type") != ObjectType.SUMMARY.value:
                    raise ValueError("C14 member summary_ref must point to a Summary")
                runtime_lineage = self._derive_c14_lineage_at_cutoff(
                    summary_ref,
                    active_write_time,
                )
                scheduler_lineage = member_metadata.get("derived_lineage")
                if not isinstance(scheduler_lineage, Mapping):
                    scheduler_lineage = {}
                summary_metadata = summary_payload.get("metadata")
                if not isinstance(summary_metadata, Mapping):
                    summary_metadata = {}
                summary_coverage = summary_payload.get("coverage")
                if not isinstance(summary_coverage, Mapping):
                    summary_coverage = {}
                lineage_payload = runtime_lineage.audit_payload()
                members.append(
                    {
                        "wake_ref": member_ref.model_dump(mode="json"),
                        "summary_ref": summary_ref.model_dump(mode="json"),
                        "summary_revision": summary_ref.revision,
                        "summary_dimension": (
                            summary_metadata.get("dimension")
                            or summary_coverage.get("dimension")
                        ),
                        "granularity": summary_payload.get("granularity"),
                        "summary_window": summary_payload.get("summary_time"),
                        "scheduler_derived_lineage": dict(scheduler_lineage),
                        "runtime_derived_lineage": lineage_payload,
                        "grounding_leaf_refs": lineage_payload.get(
                            "grounding_leaf_refs",
                            [],
                        ),
                    }
                )
            task_context["cognitive_derivation_bundle"] = {
                "bundle_wake_ref": running_ref.model_dump(mode="json"),
                "member_count": len(members),
                "members": members,
                "current_ai_world": self._ai_world_snapshot(
                    active_write_time,
                    per_domain=3,
                ),
                "capability_names": [
                    item["name"] for item in self.registry.catalog()
                ],
                "step0": gate_result.model_dump(mode="json"),
                "budget": budget_decision.context_payload(),
                "grouping_policy": "homogeneous_execution_contract",
                "summary_is_temporal_navigation_anchor": True,
                "summary_is_semantic_conclusion": False,
                "summary_is_sufficient_evidence_by_itself": False,
                "silence_is_valid_success": True,
            }
            wake_input = (
                "Cognitive derivation bundle wake. The listed pinned Summaries are "
                "independent temporal/navigation anchors, not Claims or conclusions. "
                "Inspect whichever member leaves, existing cognition, counter-evidence, "
                "and cross-dimensional world state you judge relevant. Only form, revise, "
                "or retract durable cognition when pinned support closes to qualifying "
                "non-Summary reality/case evidence. Silence is a valid successful result. "
                "Mechanical bundling makes no semantic claim about the members."
            )

        context = self.context_controller.assemble(
            user_input=wake_input,
            current_topic=None,
            recommendation=empty_recommendation,
            recent_turns=(),
            conversation_summaries=(),
            ai_identity=continuity_context,
            world_map=self._world_map_context(active_write_time),
            task_context=task_context,
            capability_catalog=self.registry.catalog(),
            token_budget=token_budget,
        )

        self._active_turn_time = active_write_time
        self._active_meter_time = now
        self._active_session_id = None
        self._active_wake_id = running.object_id
        self._active_wake_source = effective_wake_source
        self._active_review_request = None
        try:
            runtime_result = self.cognitive_runtime.run_turn(
                wake_input,
                wake_reason=effective_wake_source.value,
                cockpit=context.as_cockpit(),
                max_model_rounds=budget_decision.model_round_limit,
                model_round_offset=model_round_offset,
            )
        finally:
            self._active_turn_time = None
            self._active_meter_time = None
            self._active_session_id = None
            self._active_wake_id = None
            self._active_wake_source = None
            self._active_review_request = None

        delivery_allowed = (
            gate_result.delivery_allowed
            and effective_wake_source is not WakeSource.COGNITIVE_DERIVATION
        )
        delivery_response = (
            runtime_result.response
            if delivery_allowed
            else None
        )
        runtime_incomplete = (
            effective_wake_source is WakeSource.COGNITIVE_DERIVATION
            and runtime_result.termination_reason not in _C14_SEMANTIC_TERMINATIONS
        )

        # A real proactive assistant->user delivery is itself interaction-world
        # truth. Persist it after the delivery gate has allowed the exact model
        # response, but before Wake completion. This ordering prevents a terminal
        # Wake from becoming durable without its delivered interaction fact.
        #
        # If the process dies after this commit and before Wake completion, the
        # Wake remains RUNNING. Recovery detects the durable delivery by logical
        # Wake identity, does not invoke the model again, and completes the Wake.
        # Direct exact replay of the persistence operation remains idempotent and
        # changed text under the same delivery identity fails closed.
        delivery_observation_ref: ObjectRef | None = None
        if not runtime_incomplete and delivery_response is not None:
            delivery_commit = self.ingestor.commit_assistant_delivery(
                assistant_text=delivery_response,
                occurred_at=now,
                origin_wake_ref=running_ref,
                termination_reason=runtime_result.termination_reason,
                model_rounds=runtime_result.model_rounds,
                capability_names=tuple(
                    item.name for item in runtime_result.capability_history
                ),
                step0=gate_result.model_dump(mode="json"),
            )
            delivery_observation_ref = ObjectRef(
                object_id=delivery_commit.observation_id,
                revision=1,
            )
            self.index.catch_up()

        if runtime_incomplete:
            completed = self.wake_bus.requeue_runtime_incomplete(
                running.object_id,
                requeued_at=now,
                termination_reason=runtime_result.termination_reason,
                model_rounds=runtime_result.model_rounds,
                next_model_round_index=(
                    model_round_offset + runtime_result.model_rounds
                ),
                capability_names=tuple(
                    item.name for item in runtime_result.capability_history
                ),
                step0_state=gate_result.state,
            )
        else:
            completed = self.wake_bus.complete(
                running.object_id,
                completed_at=now,
                termination_reason=runtime_result.termination_reason,
                model_rounds=runtime_result.model_rounds,
                capability_names=tuple(
                    item.name for item in runtime_result.capability_history
                ),
                delivery_allowed=delivery_allowed,
                step0_state=gate_result.state,
            )
        return WakeDispatchRunResult(
            wake_ref=ObjectRef(
                object_id=completed.wake_id,
                revision=completed.revision,
            ),
            runtime=runtime_result,
            context=context,
            step0=gate_result,
            wake=completed,
            delivery_response=delivery_response,
            delivery_suppressed=(
                runtime_result.response is not None
                and not delivery_allowed
            ),
            delivery_observation_ref=delivery_observation_ref,
        )


    def run_periodic_review(
        self,
        *,
        now: datetime,
        policy: ReviewSchedulePolicy | None = None,
        token_budget: int | None = None,
    ) -> PeriodicReviewRunResult | None:
        """Run one due evidence-grounded background review through the resident model.

        This path does not create a synthetic Conversation Observation. The Wake and
        any cognition/experience written by model capabilities are the durable audit.
        """
        self.attention_watches.expire_due(now=now)
        request = self.periodic_review.prepare_due_review(
            now=now,
            policy=policy,
        )
        if request is None:
            return None

        review_wake = self.wake_bus.current_wake(request.wake_ref.object_id)
        budget_decision = self.background_budget_gate.evaluate(
            review_wake,
            now=now,
            max_model_rounds=self.cognitive_runtime.max_tool_rounds + 1,
            require_full_model_round_budget=True,
        )
        if not budget_decision.available:
            if budget_decision.hard_deny:
                budget_wake = self.periodic_review.suppress_review(
                    request,
                    suppressed_at=now,
                    reasons=budget_decision.reasons,
                )
            elif review_wake.wake_state.value == "running":
                budget_wake = ReviewWakeReceipt(
                    wake_id=review_wake.object_id,
                    revision=review_wake.revision,
                    state=review_wake.wake_state.value,
                    world_revision=int(self.store.current_world_revision()),
                )
            else:
                budget_wake = self.periodic_review.defer_review(
                    request,
                    deferred_at=now,
                    reasons=budget_decision.reasons,
                )
            self.index.catch_up()
            return PeriodicReviewRunResult(
                request=request,
                runtime=None,
                context=None,
                wake=budget_wake,
                budget=budget_decision,
            )

        review_queue_wakes = self.attention_router.pending_review_queue()
        anchor_keys = {
            (
                item.object_ref.object_id,
                int(item.object_ref.revision or 0),
            )
            for item in request.anchors
        }
        review_queue_consumed_ids = tuple(
            wake.object_id
            for wake in review_queue_wakes
            if wake.evidence_refs
            and all(
                (ref.object_id, int(ref.revision or 0)) in anchor_keys
                for ref in wake.evidence_refs
            )
        )

        model_round_offset = self._background_model_round_offset(
            wake_id=review_wake.object_id,
            metadata=review_wake.metadata,
        )
        exact_response = self._pending_exact_response(
            work_kind="periodic_review",
            work_id=review_wake.object_id,
        )
        recovered_attempt: BackgroundModelAttempt | None = None
        if exact_response is not None:
            recovered_attempt = exact_response[0]
            model_round_offset = max(
                model_round_offset, recovered_attempt.model_round_index
            )
        self._protect_legacy_running_background_work(
            wake=review_wake,
            work_kind="periodic_review",
            wake_reason=WakeSource.PERIODIC_REVIEW.value,
            now=now,
            model_round_offset=model_round_offset,
        )
        review_metadata = budget_decision.reservation_metadata()
        if review_wake.metadata.get("background_model_attempt_protocol") != "v1":
            review_metadata = {
                **review_metadata,
                "background_model_attempt_protocol": "v1",
            }
        request = self.periodic_review.begin_review(
            request,
            started_at=now,
            expected_world_revision=(
                budget_decision.world_revision
                if budget_decision.requires_reservation
                else None
            ),
            metadata_update=review_metadata,
        )
        self.index.catch_up()

        running_payload = self.store.get_payload(
            request.wake_ref.object_id,
            revision=request.wake_ref.revision,
        )
        running_metadata = running_payload.get("metadata")
        raw_started_at = (
            running_metadata.get("started_at")
            if isinstance(running_metadata, Mapping)
            else None
        )
        review_write_time = (
            datetime.fromisoformat(str(raw_started_at).replace("Z", "+00:00"))
            if raw_started_at is not None
            else now
        )
        if recovered_attempt is not None:
            # Same rule as the Wake path: a recovered round must reproduce the
            # original execution write time so replayed capability writebacks stay
            # idempotent instead of becoming a second side effect.
            review_write_time = recovered_attempt.admitted_at

        empty_recommendation = RecommendationBundle(
            current_topic=None,
            topic_gate_open=False,
            world_revision=int(self.store.current_world_revision()),
            index_watermark=self.index.watermark(),
            cards=(),
            reason="periodic_review_does_not_use_proactive_memory_injection",
        )
        continuity_context = self._ai_world_core_context(
            review_write_time,
            per_domain=3,
        )
        review_context = {
            "review_id": request.review_id,
            "wake_ref": request.wake_ref.model_dump(mode="json"),
            "window_start": request.window_start.isoformat(),
            "window_end": request.window_end.isoformat(),
            "anchor_count": len(request.anchors),
            "review_queue_wake_count": len(review_queue_consumed_ids),
            "budget": budget_decision.context_payload(),
            "anchor_reader": "read_periodic_review_anchors",
            "instruction": request.instruction,
        }
        review_input = (
            "Periodic review wake. Inspect the selected world anchors, then decide "
            "whether any evidence-grounded cognition or operation experience should "
            "be revised, created, or left unchanged."
        )
        context = self.context_controller.assemble(
            user_input=review_input,
            current_topic=None,
            recommendation=empty_recommendation,
            recent_turns=(),
            conversation_summaries=(),
            ai_identity=continuity_context,
            world_map=self._world_map_context(review_write_time),
            task_context={
                "periodic_review": review_context,
                "cognitive_policy_context": self._cognitive_policy_context(
                    as_of=review_write_time,
                ),
            },
            capability_catalog=self.registry.catalog(),
            token_budget=token_budget,
        )

        # A resumed RUNNING review keeps its original write time. This makes
        # model-authored writebacks deterministic across crash/budget retries instead
        # of creating a second "same lesson" merely because the worker restarted later.
        self._active_turn_time = review_write_time
        self._active_meter_time = now
        self._active_session_id = None
        self._active_wake_id = request.wake_ref.object_id
        self._active_review_request = request
        try:
            runtime_result = self.cognitive_runtime.run_turn(
                review_input,
                wake_reason="periodic_review",
                cockpit=context.as_cockpit(),
                max_model_rounds=budget_decision.model_round_limit,
                model_round_offset=model_round_offset,
            )
        finally:
            self._active_review_request = None
            self._active_turn_time = None
            self._active_meter_time = None
            self._active_session_id = None
            self._active_wake_id = None

        # Tool/capability budget exhaustion is not a completed semantic review.
        # Keep the durable Wake RUNNING so a later worker can resume the exact review.
        if runtime_result.termination_reason not in {"responded", "silence"}:
            request = self.periodic_review.mark_runtime_incomplete(
                request,
                marked_at=now,
                termination_reason=runtime_result.termination_reason,
                model_rounds=runtime_result.model_rounds,
                next_model_round_index=(
                    model_round_offset + runtime_result.model_rounds
                ),
                capability_names=[
                    result.name for result in runtime_result.capability_history
                ],
            )
            self.index.catch_up()
            return PeriodicReviewRunResult(
                request=request,
                runtime=runtime_result,
                context=context,
                wake=ReviewWakeReceipt(
                    wake_id=request.wake_ref.object_id,
                    revision=int(request.wake_ref.revision or 0),
                    state="running",
                    world_revision=int(self.store.current_world_revision()),
                ),
                budget=budget_decision,
            )

        wake = self.periodic_review.complete_review(
            request,
            completed_at=now,
            termination_reason=runtime_result.termination_reason,
            model_rounds=runtime_result.model_rounds,
            capability_names=[
                result.name for result in runtime_result.capability_history
            ],
        )
        self.attention_router.complete_review_queue(
            review_queue_consumed_ids,
            completed_at=now,
        )
        self.index.catch_up()
        return PeriodicReviewRunResult(
            request=request,
            runtime=runtime_result,
            context=context,
            wake=wake,
            budget=budget_decision,
        )
