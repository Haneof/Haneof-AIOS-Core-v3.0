"$W61PY" -B -m pytest reviews/C15_RERUN005_OPERATOR_HARNESS_WINDOW53 --basetemp=$OPERATOR_TMP/formal38 --junitxml=$W61/formal38.xml -vv
