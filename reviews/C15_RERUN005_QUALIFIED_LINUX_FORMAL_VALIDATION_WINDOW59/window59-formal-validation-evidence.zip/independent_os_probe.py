"""Window59 capability preflight only. No product imports, keys or Resident data."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import select
import signal
import socket
import struct
import subprocess
import sys
import tempfile

results = {'kernel':platform.uname()._asdict(),'python':sys.executable,
           'pid':os.getpid(),'ppid':os.getppid(),'uid':os.getuid(),'gid':os.getgid()}
checks={}
def check(name, func):
    try: checks[name]={'status':'PASS','detail':func()}
    except Exception as e: checks[name]={'status':'BLOCKED','error':repr(e)}
def stat(pid):
    raw=Path(f'/proc/{pid}/stat').read_text()
    tail=raw[raw.rfind(')')+2:].split()
    return {'raw':raw,'pid':int(raw.split(' ',1)[0]),'ppid':int(tail[1]),'start':int(tail[19])}
def unix():
    with tempfile.TemporaryDirectory(prefix='w59-unix-') as d:
        os.chmod(d,0o700)
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as listener:
            path=d+'/listener.sock'
            listener.bind(path); listener.listen(1);listener.settimeout(5)
            child=subprocess.Popen([sys.executable,'-I','-c',
                'import socket,sys,os,json; s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.connect(sys.argv[1]); s.sendall(b"preflight"); print(json.dumps([os.getpid(),os.getuid(),os.getgid()]),flush=True); s.close()',path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                with listener.accept()[0] as conn:
                    peer=struct.unpack('3i',conn.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
                    data=conn.recv(32)
                out,err=child.communicate(timeout=5)
                assert child.returncode==0,(child.returncode,err)
                reported=json.loads(out)
                assert list(peer)==reported,(peer,reported)
                assert peer[0]==child.pid,(peer,child.pid)
                assert data==b'preflight'
                return {'SO_PEERCRED':peer,'child_reported':reported,'popen_pid':child.pid,'private_directory_mode':'0700','bind_listen_connect_accept':True}
            finally:
                if child.poll() is None:child.kill();child.wait(timeout=5)
def proc_identity():
    own=stat('self');results['proc_self']=own
    assert own['pid']==os.getpid(),('self PID mismatch',own,os.getpid())
    child=subprocess.Popen([sys.executable,'-I','-c','import os,json,sys; print(json.dumps([os.getpid(),os.getppid()]),flush=True);sys.stdin.read()'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    try:
        report=json.loads(child.stdout.readline()); actual=stat(child.pid)
        results['proc_child']={'popen_pid':child.pid,'reported':report,'stat':actual}
        assert actual['pid']==child.pid==report[0]
        assert actual['ppid']==os.getpid()==report[1]
        assert actual['start']==stat(child.pid)['start']
        def matches(expected_start):return stat(child.pid)['start']==expected_start
        assert matches(actual['start']) and not matches(actual['start']+1)
        return {'real_child_identity':True,'wrong_start_rejected':True,'actual_pid_reuse':'NOT_FORCED; start comparator only'}
    finally:child.kill();child.wait(timeout=5)
def pidfd():
    child=subprocess.Popen([sys.executable,'-I','-c','import sys;print("ready",flush=True);sys.stdin.read()'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    fd=None
    try:
        assert child.stdout.readline().strip()=='ready'
        fd=os.pidfd_open(child.pid)
        poll=select.poll();poll.register(fd,select.POLLIN)
        before=poll.poll(0)
        assert not before,('pidfd already readable before child death',before)
        child.kill();rc=child.wait(timeout=5)
        after=poll.poll(1500)
        assert rc==-signal.SIGKILL,rc
        assert after,('pidfd not readable after real SIGKILL',after)
        return {'child':child.pid,'before':before,'after':after,'SIGKILL_exit':rc}
    finally:
        if fd is not None:os.close(fd)
        if child.poll() is None:child.kill();child.wait(timeout=5)
def restart():
    code='import pathlib,sys; p=pathlib.Path(sys.argv[1]); print(p.read_text(),flush=True);sys.stdin.read()'
    with tempfile.TemporaryDirectory(prefix='w59-restart-') as d:
        p=Path(d)/'checkpoint';p.write_text('synthetic-checkpoint')
        child=subprocess.Popen([sys.executable,'-I','-c',code,str(p)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
        try:
            assert child.stdout.readline().strip()=='synthetic-checkpoint'
            child.kill();rc=child.wait(timeout=5);assert rc==-9,rc
            resumed=subprocess.run([sys.executable,'-I','-c','import pathlib,sys; print(pathlib.Path(sys.argv[1]).read_text())',str(p)],capture_output=True,text=True,timeout=5)
            assert resumed.returncode==0 and resumed.stdout.strip()=='synthetic-checkpoint'
            return {'killed_exit':rc,'restart_exit':resumed.returncode,'scope':'OS checkpoint only; no Core/C15 recovery claim'}
        finally:
            if child.poll() is None:child.kill();child.wait(timeout=5)
def git_remote():
    with tempfile.TemporaryDirectory(prefix='w59-git-') as d:
        def git(*args):
            r=subprocess.run(['git',*args],capture_output=True,text=True,timeout=10)
            assert r.returncode==0,(args,r.returncode,r.stderr)
            return r.stdout.strip()
        remote=d+'/remote.git';client=d+'/client'
        git('init','--bare',remote);git('init',client)
        git('-C',client,'config','user.name','Window59 capability probe');git('-C',client,'config','user.email','window59@example.invalid')
        Path(client,'probe.txt').write_text('disposable OS preflight\n')
        git('-C',client,'add','probe.txt');git('-C',client,'commit','-m','synthetic preflight')
        git('-C',client,'push',remote,'HEAD:refs/heads/probe')
        head=git('-C',client,'rev-parse','HEAD');actual=git('--git-dir',remote,'rev-parse','refs/heads/probe')
        assert head==actual
        return {'local_bare_remote_push':True,'head':head,'scope':'not C15 CAS validation'}
def tty():
    fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY)
    try:
        assert os.isatty(fd)
        return {'tty':os.ttyname(fd),'foreground_group':os.tcgetpgrp(fd),'session':os.getsid(0),'group':os.getpgrp(),'scope':'availability only; channel isolation NOT proven'}
    finally:os.close(fd)
def memory_boundary():
    # Never dereference another numeric PID when /proc identity is not reliable.
    observed={'self_status':{},'yama_ptrace_scope':None,'actual_live_publisher_probe':'NOT_STARTED_GATE0'}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.split(':')[0] in ('Name','Pid','PPid','Uid','Gid','TracerPid','Seccomp','CapEff','NoNewPrivs'):observed['self_status'][line.split(':')[0]]=line.split(':',1)[1].strip()
    try:observed['yama_ptrace_scope']=Path('/proc/sys/kernel/yama/ptrace_scope').read_text().strip()
    except OSError as e:observed['yama_error']=repr(e)
    results['os_memory_boundary_observations']=observed
    if checks['PROC_START_IDENTITY']['status']!='PASS':
        raise RuntimeError('No trustworthy /proc process identity; cross-process debug/memory target cannot be safely bound to own test child')
    raise RuntimeError('Live Publisher boundary assessment depends on Gate0 and approved runtime; no inference from kernel policy alone')
check('LINUX_X86_64',lambda: platform.system()=='Linux' and platform.machine()=='x86_64' or (_ for _ in ()).throw(AssertionError(platform.uname())))
check('AF_UNIX_REAL_LISTENER_PEERCRED',unix)
check('PROC_START_IDENTITY',proc_identity)
check('PIDFD_LIFECYCLE',pidfd)
check('OS_SIGKILL_RESTART',restart)
check('DISPOSABLE_GIT_REMOTE',git_remote)
check('CONTROLLING_TTY',tty)
check('OS_MEMORY_DEBUG_BOUNDARY',memory_boundary)
results['checks']=checks
results['status']='PASS' if all(c['status']=='PASS' for c in checks.values()) else 'BLOCKED'
print(json.dumps(results,indent=2,sort_keys=True))
sys.exit(0 if results['status']=='PASS' else 78)
