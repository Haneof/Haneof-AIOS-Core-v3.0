"""Evidence recorder. Runtime identity and OS capability probes only, no formal suite."""
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parent.parent
e=root/'evidence';repo=root/'repo'
approved='/home/user/.cache/c002/final-runtime-003/runtime/3.12.14/venv/bin/python'
records=[]
tasks=[('candidate-environment-probe',[approved,'-B',str(repo/'reviews/C15_RERUN005_FORMAL_GATE_CORRECTIVE_WINDOW57/environment_probe.py')]),
       ('independent-approved-os',[approved,'-B',str(e/'independent_os_probe.py')]),
       ('approved-runtime-identity',[approved,'-B',str(repo/'reviews/C15_RERUN005_FORMAL_GATE_CORRECTIVE_WINDOW57/runtime_identity.py'),str(root/'runtime-download/approved-runtime.zip'),str(root/'runtime-download/approved-runtime.tar.gz')])]
for name,argv in tasks:
    started=time.time();r=subprocess.run(argv,cwd=root,capture_output=True,timeout=40,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    (e/(name+'.stdout')).write_bytes(r.stdout);(e/(name+'.stderr')).write_bytes(r.stderr);(e/(name+'.exitcode')).write_text(str(r.returncode)+'\n')
    records.append({'name':name,'argv':argv,'cwd':str(root),'started_unix':started,'exit_code':r.returncode,'duration_s':time.time()-started,'python_binary_sha256':hashlib.sha256(Path(approved).resolve().read_bytes()).hexdigest(),'scope':'Gate0 capability probe / Gate1 identity; no formal security suite'})
(e/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
data=json.loads((e/'independent-approved-os.stdout').read_text())
suite=ET.Element('testsuite',name='Window59_OS_preflight_only',tests=str(len(data['checks'])),errors=str(sum(v['status']!='PASS' for v in data['checks'].values())),failures='0',skipped='0')
for key,val in data['checks'].items():
    case=ET.SubElement(suite,'testcase',classname='IndependentOSPreflight',name=key)
    if val['status']!='PASS':ET.SubElement(case,'error',type='EnvironmentCapabilityBlocked',message=val['error']).text=val['error']
    ET.SubElement(case,'system-out').text=json.dumps(val)
ET.ElementTree(suite).write(e/'os-preflight.xml',encoding='utf-8',xml_declaration=True)
print(json.dumps(records,indent=2));print((e/'independent-approved-os.stdout').read_text())
